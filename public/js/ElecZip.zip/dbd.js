{
    "data": {
        "foundation": {
            "foundation_id": 1,
            "name": "وزارة الكهرباء و الطاقة المتجددة",
            "foundation_desc": "<p>\nأنشئت هيئة كهرباء مصر عام 1976 لتكون مسئولة عن كافة محطات القوى الكهربائية وشبكات نقلها وتوزيعها. وفى عام 2000 صدر القانون 164 بتحويل هيئة كهرباء مصر إلى الشركة القابضة لكهرباء مصر التى صارت تتبعها خمس شركات لإنتاج الكهرباء وسبع شركات لتوزيع الكهرباء وشركة واحدة لنقل الكهرباء والتحكم فيها\n</p>\n<p>\nفى عام 1984 تم إنشاء هيئة القطاع العام لتوزيع القوى االكهربية حيث تولت الإشراف على شركات توزيع الكهرباء . فى عام 1998 تم مرة أخرى نقل تبعية شركات توزيع الكهرباء إلى هيئة كهرباء مصر ، وتم دمج مناطق الكهرباء السبع وشركات توزيع الكهرباء فى سبع شركات مساهمة لإنتاج وتوزيع الطاقة االكهربية.\n</p>\n<p>\nفى يوليو عام 2001 تم إعادة هيكلة الشركة القابضة و الشركات التابعة لها حتى أصبح عدد الشركات التابعة ست عشرة شركة ست شركات إنتاج والشركة المصرية لنقل الكهرباء وتسع شركات توزيع.\n</p>\n<p>\n تعمل الشركة القابضة لكهربــــاء مصر على توفير الطاقة الكهربية لمشروعات التنمية الاقتصاديـــــة والاجتماعية وكافة الاغراض عبر الشبكة الكهربية الموحدة بالقدرات اللازمة وبأعلي مستوى من المواصفات الفنية ، كما تتخـذ كافــــة الضمانـــات لاستقـرار واستمرار التغذية الكهربية بدون انقطاع في كافة الاحوال مع الاستخدام الأمثل لكافة الموارد لتعظيم الربحيه. \n</p>\n<p>\nأنشئت هيئة كهرباء مصر عام 1976 لتكون مسئولة عن كافة محطات القوى الكهربيةوشبكات نقلها وتوزيعها. \n</p>\n<p>\nفى عام 1984 تم إنشاء هيئة القطاع العام لتوزيع القوىاالكهربيةحيث تولت الإشراف على شركات توزيع الكهرباء . . \n</p>\n<p>\nفى عام 1998 تم مرة أخرى نقل تبعية شركات توزيع الكهرباء إلى هيئة كهرباء مصر ، وتم دمج مناطق الكهرباء السبع وشركات توزيع الكهرباء فى سبع شركات مساهمة لإنتاج وتوزيع الطاقة االكهربية. \n</p>\n<p>\nفى عام 2000 صدر القانون 164 بتحويل هيئة كهرباء مصر إلى الشركة القابضة لكهرباء مصر التى صارت تتبعها خمس شركات لإنتاج الكهرباء وسبع شركات لتوزيع الكهرباء وشركة واحدة لنقل الكهرباء \n</p>\n<p>\nفى يوليو عام 2001 تم إعادة هيكلة الشركة القابضة و الشركات التابعة لها حتى أصبح عدد الشركات التابعة ست عشرة شركة ست شركات إنتاج والشركة المصرية لنقل الكهرباء وتسع شركات توزيع وتقوم الشركة القابضة بالتنسيق بينهما كوحدة اقتصادية متكاملة يمكنها تحمل أعباء التمويل الذاتى لخططها المستقبلية \n</p>\nولقد أمكن للشركة القابضة لكهرباء مصر (هيئة كهرباء مصر سابقاً) تحقيق إنجازات ضخمة خلال فترة العشرين عاماً السابقة ، وكانت الكهرباء أساساً للمشروعات الصناعية فى جميع مجالات الصناعة الثقيلة والخفيفة والوسيطة والصناعات الصغيرة ، كما كانت الكهرباء أساساً للمشروعات فى مجالات الزراعة واستصلاح الأراضى والثروة الحيوانية وفى مجال الاسكان والتجارة والخدمات والإعلام والنهضة الاجتماعية والإنسانية عموماً ، وكانت ركيزة للمدن الجديدة والمنتجعات السياحية والأنشطة الاقتصادية والاجتماعية .\n",
            "branchname": "كل الفروع",
            "phone": "1555555",
            "landline": "2525255",
            "website": "sfsf",
            "map": "dfgdf",
            "about": {
                "id": 1,
                "description": "تنويه : \nلغة الاشارة المصورة والمسجلة في البرنامج معتمدة من الاتحاد النوعي لجمعيات الصم بمصر.\n\nمقدمة: \nإيمانا من الشركة القابضه لكهرباء مصر بدورها في خدمة المجتمع وحقوق الأشخاص ذوي الاعاقة من الاندماج في المجتمع وحقهم في المساواة في الحصول على الخدمات والعروض التي تقدمها الشركة فإنها تقدم مشروع وتطبيقات عالية الأتاحة والتقنية لإتاحة التعريف بخدمات الشركة القابضه لكهرباء مصر لذوي الاعاقة البصرية والسمعية والحركية.\n\nهذا البرنامج تقدمه الشركة القابضه لكهرباء مصر للجميع مجانًا بإتاحة عالية للصم بلغة الاشارة وللمكفوفين بالصوت للتسهيل عليهم في التعرف على كآفة الخدمات والعروض التي تقدمها الشركة ومساعدتهم في الحصول على الخدمات والعروض بسهولة واتاحة توصل الصم مع موظف خدمة العملاء في الفروع مباشرة باستخدام لغة الاشارة.\n\nيمكن للجميع الآن مجانًا تحميل التطبيق من خلال متجر التطبيقات والتعرف على كآفة العروض والخدمات، وعند الذهاب لاحد فروع الشركة يمكن لذوي الاعاقة التوجه للشاشة المخصصة بعرض الخدمات للتعرف على الخدمات والعروض.\n\nكما يمكنه التحدث من خلال تابليت في الفرع مع الموظف لطلب الخدمة.\n\nاو استخدام تطبيق الصم في التواصل مع الموظف باستخدام لغةٍ الاشارة .\n\nهذا المشروع جاري تعميمه في كآفة فروع الشركة القابضه لكهرباء مصر في جمهورية مصر العربية.\n\nالمشروع والتطبيقات فكرة وتنفيذ وبرمجة شركات مجموعة خليفة للكمبيوتر وجميع حقوقه محفوظة لمجموعة خليفة \n\nالمشروع تم تنفيذه برعاية وزارة الاتصالات وتكنولوجيا المعلومات.\n",
                "videos": [
                    {
                        "id": 1,
                        "video": "abouts/videos/about_project.webm"
                    }
                ],
                "sounds": [
                    {
                        "id": 1,
                        "sound": "abouts/sounds/about_project.mp3"
                    }
                ]
            },
            "email": "sdsdvsdv@sfgsf.sf",
            "imgs": [],
            "vids": [
                "foundations/videos/1.webm"
            ],
            "sound": [
                "foundations/sounds/1.mp3"
            ],
            "branches": []
        },
        "allservices": [
            {
                "title": "خدمات وزارة الكهرباء",
                "id": "1",
                "has_subservice": 1,
                "desc": "تقدم وزارة الكهرباء العديد من الخدمات",
                "sub_services": [
                    {
                        "id": 2,
                        "title": "شهادة بيانات تعاقد / مصالحة",
                        "has_subservice": 0,
                        "desc": "<p>طلب المشترك الحصول علي شهاده تفيد أنه متعاقد او متصالح مع شركة التوزيع</p>",
                        "sound": [
                            "services/sounds/desc/2.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/2.webm"
                        ],
                        "imgs": [
                            "services/images/2.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 1,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/1.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/1.webm"
                                ],
                                "imgs": [
                                    "documents/images/1.jpg"
                                ]
                            },
                            {
                                "id": 2,
                                "title": "حضور المنتفع او من له صفة قانونية",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/2.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/2.webm"
                                ],
                                "imgs": [
                                    "documents/images/2.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 1,
                                "question": "ما هي الإجراءات المطلوبة لاستخراج شهادة بيانات  تعاقد / مصالحة ؟",
                                "answer": " قيام المشترك باستيفاء نموذج لطلب الشهادة<br>سداد الرسوم المقررة<br>ستلام الشهادة بعد التحقق من المستندات<br>",
                                "sound": [
                                    "faqs/sounds/q_and_a/1.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/1.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 2,
                                "question": "ما هي الفترة الزمنية لاستخراج شهادة بيانات  تعاقد / مصالحة ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها 30 دقيقة",
                                "sound": [
                                    "faqs/sounds/q_and_a/2.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/2.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 1,
                                "title": "خطوة رقم 1",
                                "desc": "قيام المشترك باستيفاء نموذج لطلب الشهادة",
                                "sound": [
                                    "procedures/sounds/desc/1.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/1.webm"
                                ],
                                "imgs": [
                                    "procedures/images/1.jpg"
                                ]
                            },
                            {
                                "id": 2,
                                "title": "خطوة رقم 2",
                                "desc": "سداد الرسوم المقررة",
                                "sound": [
                                    "procedures/sounds/desc/2.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/2.webm"
                                ],
                                "imgs": [
                                    "procedures/images/2.jpg"
                                ]
                            },
                            {
                                "id": 3,
                                "title": "خطوة رقم 3",
                                "desc": "استلام الشهادة بعد التحقق من المستندات",
                                "sound": [
                                    "procedures/sounds/desc/3.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/3.webm"
                                ],
                                "imgs": [
                                    "procedures/images/3.jpg"
                                ]
                            },
                            {
                                "id": 4,
                                "title": "خطوة رقم 4",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها 30 دقيقة",
                                "sound": [
                                    "procedures/sounds/desc/4.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/4.webm"
                                ],
                                "imgs": [
                                    "procedures/images/4.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 3,
                        "title": "شهادة بيانات استهلاك خلال فترة",
                        "has_subservice": 0,
                        "desc": "<p>طلب المشترك الحصول علي شهاده تفيد استهلاكة خلال فترة</p>",
                        "sound": [
                            "services/sounds/desc/3.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/3.webm"
                        ],
                        "imgs": [
                            "services/images/3.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 3,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/3.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/3.webm"
                                ],
                                "imgs": [
                                    "documents/images/3.jpg"
                                ]
                            },
                            {
                                "id": 4,
                                "title": "حضور المنتفع او من له صفة قانونية",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/4.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/4.webm"
                                ],
                                "imgs": [
                                    "documents/images/4.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 3,
                                "question": "ما هي الإجراءات المطلوبة لاستخراج شهادة بيانات استهلاك خلال فترة؟",
                                "answer": " قيام المشترك باستيفاء نموذج لطلب الشهادة<br>سداد الرسوم المقررة<br>ستلام الشهادة بعد التحقق من المستندات<br>",
                                "sound": [
                                    "faqs/sounds/q_and_a/3.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/3.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 4,
                                "question": "ما هي الفترة الزمنية لاستخراج شهادة بيانات استهلاك خلال فترة؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها 30 دقيقة",
                                "sound": [
                                    "faqs/sounds/q_and_a/4.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/4.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 5,
                                "title": "خطوة رقم 1",
                                "desc": "قيام المشترك باستيفاء نموذج لطلب الشهادة",
                                "sound": [
                                    "procedures/sounds/desc/5.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/5.webm"
                                ],
                                "imgs": [
                                    "procedures/images/5.jpg"
                                ]
                            },
                            {
                                "id": 6,
                                "title": "خطوة رقم 2",
                                "desc": "سداد الرسوم المقررة",
                                "sound": [
                                    "procedures/sounds/desc/6.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/6.webm"
                                ],
                                "imgs": [
                                    "procedures/images/6.jpg"
                                ]
                            },
                            {
                                "id": 7,
                                "title": "خطوة رقم 3",
                                "desc": "استلام الشهادة بعد التحقق من المستندات",
                                "sound": [
                                    "procedures/sounds/desc/7.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/7.webm"
                                ],
                                "imgs": [
                                    "procedures/images/7.jpg"
                                ]
                            },
                            {
                                "id": 8,
                                "title": "خطوة رقم 4",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها 30 دقيقة",
                                "sound": [
                                    "procedures/sounds/desc/8.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/8.webm"
                                ],
                                "imgs": [
                                    "procedures/images/8.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 4,
                        "title": "تركيب عداد",
                        "has_subservice": 1,
                        "desc": "<p>طلب المشترك تركيب عداد جديد</p>",
                        "sound": [
                            "services/sounds/desc/4.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/4.webm"
                        ],
                        "imgs": [
                            "services/images/4.jpg"
                        ],
                        "sub_sub_services": [
                            {
                                "id": 5,
                                "title": "تركيب عداد قانوني لأول مرة",
                                "has_subservice": 0,
                                "desc": "<p>طلب المشترك تركيب عداد جديد بالوحدة لاول مرة العقار به وصلة أرضية</p>",
                                "sound": [
                                    "services/sounds/desc/5.mp3"
                                ],
                                "vids": [
                                    "services/videos/desc/5.webm"
                                ],
                                "imgs": [
                                    "services/images/5.jpg"
                                ],
                                "sub_sub_services": [],
                                "docs": [
                                    {
                                        "id": 5,
                                        "title": "بطاقة الرقم القومي",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/5.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/5.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/5.jpg"
                                        ]
                                    },
                                    {
                                        "id": 6,
                                        "title": "سند الحيازه",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/6.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/6.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/6.jpg"
                                        ]
                                    },
                                    {
                                        "id": 7,
                                        "title": "موافقة الحي او الجهة الإدارية المختصة أو مقايسة العقار",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/7.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/7.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/7.jpg"
                                        ]
                                    },
                                    {
                                        "id": 8,
                                        "title": "في حالة النشاط التجاري يضاف البطاقة الضريبيه للسجل - التجاري او اقرار كتابي من العميل بأنه جاري في استخراج التراخيص",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/8.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/8.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/8.jpg"
                                        ]
                                    }
                                ],
                                "faqs": [
                                    {
                                        "id": 5,
                                        "question": "ما هي الإجراءات المطلوبة لتركيب عداد قانوني لأول مرة؟",
                                        "answer": " قيام المشترك باستيفاء نموزج الطلب<br>سداد الرسوم وقيمة المقايسه<br>التعاقد علي نموذج توريد الطاقه وتركيب العداد",
                                        "sound": [
                                            "faqs/sounds/q_and_a/5.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/5.webm"
                                        ],
                                        "imgs": []
                                    },
                                    {
                                        "id": 6,
                                        "question": "ما هي الفترة الزمنية لتركيب عداد قانوني لأول مرة؟",
                                        "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 7 أيام عمل من تاريخ سداد المقاسيه والتعاقد",
                                        "sound": [
                                            "faqs/sounds/q_and_a/6.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/6.webm"
                                        ],
                                        "imgs": []
                                    }
                                ],
                                "procedures": [
                                    {
                                        "id": 9,
                                        "title": "خطوة رقم 1",
                                        "desc": "قيام المشترك باستيفاء نموزج الطلب",
                                        "sound": [
                                            "procedures/sounds/desc/9.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/9.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/9.png"
                                        ]
                                    },
                                    {
                                        "id": 10,
                                        "title": "خطوة رقم 2",
                                        "desc": "سداد الرسوم وقيمة المقايسه",
                                        "sound": [
                                            "procedures/sounds/desc/10.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/10.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/10.jpg"
                                        ]
                                    },
                                    {
                                        "id": 11,
                                        "title": "خطوة رقم 3",
                                        "desc": "التعاقد علي نموذج توريد الطاقه وتركيب العداد",
                                        "sound": [
                                            "procedures/sounds/desc/11.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/11.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/11.png"
                                        ]
                                    },
                                    {
                                        "id": 12,
                                        "title": "خطوة رقم 4",
                                        "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 7 أيام عمل من تاريخ سداد المقاسيه والتعاقد",
                                        "sound": [
                                            "procedures/sounds/desc/12.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/12.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/12.jpg"
                                        ]
                                    }
                                ],
                                "regulations": []
                            },
                            {
                                "id": 6,
                                "title": "تركيب عداد كودي",
                                "has_subservice": 0,
                                "desc": "<p>تركيب عداد كودي للمواطنين الذين يستمدون تيار كهربائي بصورة غير فانونية لمحاسبتهم علي استهلاكهم بدقة العقار به وصلة أرضية</p>",
                                "sound": [
                                    "services/sounds/desc/6.mp3"
                                ],
                                "vids": [
                                    "services/videos/desc/6.webm"
                                ],
                                "imgs": [
                                    "services/images/6.jpg"
                                ],
                                "sub_sub_services": [],
                                "docs": [
                                    {
                                        "id": 9,
                                        "title": "بطاقة الرقم القومي",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/9.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/9.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/9.jpg"
                                        ]
                                    },
                                    {
                                        "id": 10,
                                        "title": "إيصال سداد الممارسة أو محضر المخالفة أو أن يكون مدرجاً بكشوف حصر المخالفين التي تعدها شركات التوزيع",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/10.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/10.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/10.png"
                                        ]
                                    }
                                ],
                                "faqs": [
                                    {
                                        "id": 7,
                                        "question": "ما هي الإجراءات المطلوبة لتركيب عداد كودي؟",
                                        "answer": " قيام المشترك باستيفاء نموزج الطلب\nسداد الرسوم وقيمة المقايسه<br>تركيب العداد",
                                        "sound": [
                                            "faqs/sounds/q_and_a/7.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/7.webm"
                                        ],
                                        "imgs": []
                                    },
                                    {
                                        "id": 8,
                                        "question": "ما هي المستندات المطلوبة لتركيب عداد كودي؟",
                                        "answer": " بطاقة الرقم القومي\nإيصال سداد الممارسة أو محضر المخالفة أو أن يكون مدرجاً بكشوف حصر المخالفين التي تعدها شركات التوزيع",
                                        "sound": [
                                            "faqs/sounds/q_and_a/8.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/8.webm"
                                        ],
                                        "imgs": []
                                    },
                                    {
                                        "id": 9,
                                        "question": "ما هي الفترة الزمنية لتركيب عداد كودي ؟",
                                        "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها<br>7 أيام عمل من تاريخ سداد المقاسيه",
                                        "sound": [
                                            "faqs/sounds/q_and_a/9.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/9.webm"
                                        ],
                                        "imgs": []
                                    }
                                ],
                                "procedures": [
                                    {
                                        "id": 13,
                                        "title": "خطوة رقم 1",
                                        "desc": "قيام المشترك باستيفاء نموزج الطلب",
                                        "sound": [
                                            "procedures/sounds/desc/13.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/13.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/13.png"
                                        ]
                                    },
                                    {
                                        "id": 14,
                                        "title": "خطوة رقم 2",
                                        "desc": "سداد رسوم وقيمة المقايسه",
                                        "sound": [
                                            "procedures/sounds/desc/14.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/14.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/14.jpg"
                                        ]
                                    },
                                    {
                                        "id": 15,
                                        "title": "خطوة رقم 3",
                                        "desc": "تركيب العداد",
                                        "sound": [
                                            "procedures/sounds/desc/15.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/15.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/15.png"
                                        ]
                                    },
                                    {
                                        "id": 16,
                                        "title": "خطوة رقم 4",
                                        "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها 7 أيام عمل من تاريخ سداد المقاسيه",
                                        "sound": [
                                            "procedures/sounds/desc/16.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/16.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/16.jpg"
                                        ]
                                    }
                                ],
                                "regulations": []
                            },
                            {
                                "id": 7,
                                "title": "ترکیب عداد بدل تالف",
                                "has_subservice": 0,
                                "desc": "<p>تركيب عداد جديد بدلا من العداد العداد التالف</p>",
                                "sound": [
                                    "services/sounds/desc/7.mp3"
                                ],
                                "vids": [
                                    "services/videos/desc/7.webm"
                                ],
                                "imgs": [
                                    "services/images/7.jpg"
                                ],
                                "sub_sub_services": [],
                                "docs": [
                                    {
                                        "id": 11,
                                        "title": "بطاقة الرقم القومي",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/11.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/11.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/11.jpg"
                                        ]
                                    },
                                    {
                                        "id": 12,
                                        "title": "طلب من المنتفع او مذكرة من القارئ / المحصل والتأكيد بتقرير المعاينة الفنية",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/12.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/12.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/12.png"
                                        ]
                                    },
                                    {
                                        "id": 13,
                                        "title": "بيانات الحساب",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/13.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/13.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/13.png"
                                        ]
                                    }
                                ],
                                "faqs": [
                                    {
                                        "id": 10,
                                        "question": "ما هي الإجراءات المطلوبة لتركيب عداد بدل تالف ؟",
                                        "answer": " استيفاء الطلب\nسداد الرسوم المقرره والتسويات المستحقة ان وجدت\nتركيب العداد",
                                        "sound": [
                                            "faqs/sounds/q_and_a/10.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/10.webm"
                                        ],
                                        "imgs": []
                                    },
                                    {
                                        "id": 11,
                                        "question": "ما هي الوثائق المطلوبة لتركيب عداد بدل تالف ؟",
                                        "answer": " بطاقة الرقم القومي\nطلب من المنتفع او مذكرة من القارئ / المحصل والتأكيد بتقرير المعاينة الفنية<br>بيانات الحساب",
                                        "sound": [
                                            "faqs/sounds/q_and_a/11.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/11.webm"
                                        ],
                                        "imgs": []
                                    },
                                    {
                                        "id": 12,
                                        "question": "ما هي الفترة الزمنية لتركيب عداد بدل تالف ؟",
                                        "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 3 أيام من تاريخ سداد الرسوم",
                                        "sound": [
                                            "faqs/sounds/q_and_a/12.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/12.webm"
                                        ],
                                        "imgs": []
                                    }
                                ],
                                "procedures": [
                                    {
                                        "id": 17,
                                        "title": "خطوة رقم 1",
                                        "desc": "استيفاء الطلب",
                                        "sound": [
                                            "procedures/sounds/desc/17.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/17.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/17.png"
                                        ]
                                    },
                                    {
                                        "id": 18,
                                        "title": "خطوة رقم 2",
                                        "desc": "سداد الرسوم المقرره والمديونية المستحقة ان وجدت",
                                        "sound": [
                                            "procedures/sounds/desc/18.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/18.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/18.jpg"
                                        ]
                                    },
                                    {
                                        "id": 19,
                                        "title": "خطوة رقم 3",
                                        "desc": "رفع العداد التالف وتركيب العداد الجديد واعداد التسوية النهائية",
                                        "sound": [
                                            "procedures/sounds/desc/19.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/19.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/19.jpg"
                                        ]
                                    },
                                    {
                                        "id": 20,
                                        "title": "خطوة رقم 4",
                                        "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 3 أيام من تاريخ سداد الرسوم",
                                        "sound": [
                                            "procedures/sounds/desc/20.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/20.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/20.jpg"
                                        ]
                                    }
                                ],
                                "regulations": []
                            },
                            {
                                "id": 8,
                                "title": "ترکیب عداد بدل فاقد",
                                "has_subservice": 0,
                                "desc": "<p>تركيب عداد جديد بدلا من العداد المفقود</p>",
                                "sound": [
                                    "services/sounds/desc/8.mp3"
                                ],
                                "vids": [
                                    "services/videos/desc/8.webm"
                                ],
                                "imgs": [
                                    "services/images/8.jpg"
                                ],
                                "sub_sub_services": [],
                                "docs": [
                                    {
                                        "id": 14,
                                        "title": "بطاقة الرقم القومي",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/14.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/14.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/14.jpg"
                                        ]
                                    },
                                    {
                                        "id": 15,
                                        "title": "طلب من المنتفع",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/15.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/15.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/15.png"
                                        ]
                                    },
                                    {
                                        "id": 16,
                                        "title": "محضر شرطة بفقد العداد",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/16.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/16.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/16.jpg"
                                        ]
                                    },
                                    {
                                        "id": 17,
                                        "title": "بيانات الحساب",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/17.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/17.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/17.png"
                                        ]
                                    }
                                ],
                                "faqs": [
                                    {
                                        "id": 13,
                                        "question": "ما هي الإجراءات المطلوبة لتركيب عداد بدل فاقد ؟",
                                        "answer": " استيفاء الطلب\nسداد الرسوم المقرره والتسويات المستحقة ان وجدت\nتركيب العداد",
                                        "sound": [
                                            "faqs/sounds/q_and_a/13.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/13.webm"
                                        ],
                                        "imgs": []
                                    },
                                    {
                                        "id": 14,
                                        "question": "ما هي الوثائق المطلوبة لتركيب عداد بدل فاقد ؟",
                                        "answer": " بطاقة الرقم القومي\nطلب من المنتفع<br>محضر شرطة بفقد العداد\nبيانات الحساب",
                                        "sound": [
                                            "faqs/sounds/q_and_a/14.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/14.webm"
                                        ],
                                        "imgs": []
                                    },
                                    {
                                        "id": 15,
                                        "question": "ما هي الفترة الزمنية لتركيب عداد بدل فاقد ؟",
                                        "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 3 أيام من تاريخ تقديم محضر الشرطة",
                                        "sound": [
                                            "faqs/sounds/q_and_a/15.mp3"
                                        ],
                                        "vids": [
                                            "faqs/videos/q_and_a/15.webm"
                                        ],
                                        "imgs": []
                                    }
                                ],
                                "procedures": [
                                    {
                                        "id": 21,
                                        "title": "خطوة رقم 1",
                                        "desc": "استيفاء الطلب",
                                        "sound": [
                                            "procedures/sounds/desc/21.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/21.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/21.png"
                                        ]
                                    },
                                    {
                                        "id": 22,
                                        "title": "خطوة رقم 2",
                                        "desc": "سداد الرسوم المقرره والتسويات المستحقة ان وجدت",
                                        "sound": [
                                            "procedures/sounds/desc/22.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/22.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/22.jpg"
                                        ]
                                    },
                                    {
                                        "id": 23,
                                        "title": "خطوة رقم 3",
                                        "desc": "تركيب العداد",
                                        "sound": [
                                            "procedures/sounds/desc/23.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/23.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/23.jpg"
                                        ]
                                    },
                                    {
                                        "id": 24,
                                        "title": "خطوة رقم 4",
                                        "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 3 أيام من تاريخ تقديم محضر الشرطة",
                                        "sound": [
                                            "procedures/sounds/desc/24.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/24.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/24.jpg"
                                        ]
                                    }
                                ],
                                "regulations": []
                            }
                        ],
                        "docs": [],
                        "faqs": [],
                        "procedures": [],
                        "regulations": []
                    },
                    {
                        "id": 9,
                        "title": "تغيير اسم صاحب العداد",
                        "has_subservice": 0,
                        "desc": "<p>تغيير إسم المتعاقد علي العداد</p>",
                        "sound": [
                            "services/sounds/desc/9.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/9.webm"
                        ],
                        "imgs": [
                            "services/images/9.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 18,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/18.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/18.webm"
                                ],
                                "imgs": [
                                    "documents/images/18.jpg"
                                ]
                            },
                            {
                                "id": 19,
                                "title": "سند الحيازة",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/19.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/19.webm"
                                ],
                                "imgs": [
                                    "documents/images/19.jpg"
                                ]
                            },
                            {
                                "id": 20,
                                "title": "تنازل رسمي من المشترك السابق أو توكيل",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/20.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/20.webm"
                                ],
                                "imgs": [
                                    "documents/images/20.png"
                                ]
                            },
                            {
                                "id": 21,
                                "title": "بيانات الحساب",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/21.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/21.webm"
                                ],
                                "imgs": [
                                    "documents/images/21.png"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 16,
                                "question": "ما هي الإجراءات المطلوبة لتغيير اسم صاحب العداد ؟",
                                "answer": " قيام المشترك باستيفاء نموذج الطلب\nحضور المنتفع الأصلي وتنازله امام المسؤول المختص\nسداد التسويات المستحقة ان وجدت",
                                "sound": [
                                    "faqs/sounds/q_and_a/16.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/16.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 17,
                                "question": "ما هي الوثائق المطلوبة لتغيير اسم صاحب العداد ؟",
                                "answer": " بطاقة الرقم القومي\nسند الحيازة\nتنازل رسمي من المشترك السابق أو توكيل<br>بيانات الحساب",
                                "sound": [
                                    "faqs/sounds/q_and_a/17.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/17.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 18,
                                "question": "ما هي الفترة الزمنية لتغيير اسم صاحب العداد ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها خلال 60 دقيقة",
                                "sound": [
                                    "faqs/sounds/q_and_a/18.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/18.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 25,
                                "title": "خطوة رقم 1",
                                "desc": "قيام المشترك باستيفاء نموذج الطلب",
                                "sound": [
                                    "procedures/sounds/desc/25.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/25.webm"
                                ],
                                "imgs": [
                                    "procedures/images/25.png"
                                ]
                            },
                            {
                                "id": 26,
                                "title": "خطوة رقم 2",
                                "desc": "حضور المنتفع الأصلي وتنازله امام المسؤول المختص",
                                "sound": [
                                    "procedures/sounds/desc/26.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/26.webm"
                                ],
                                "imgs": [
                                    "procedures/images/26.jpg"
                                ]
                            },
                            {
                                "id": 27,
                                "title": "خطوة رقم 3",
                                "desc": "سداد التسويات المستحقة ان وجدت",
                                "sound": [
                                    "procedures/sounds/desc/27.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/27.webm"
                                ],
                                "imgs": [
                                    "procedures/images/27.jpg"
                                ]
                            },
                            {
                                "id": 28,
                                "title": "خطوة رقم 4",
                                "desc": "سداد الرسوم المقررة والتعاقد علي نموذج عقد توريد الطاقة",
                                "sound": [
                                    "procedures/sounds/desc/28.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/28.webm"
                                ],
                                "imgs": [
                                    "procedures/images/28.jpg"
                                ]
                            },
                            {
                                "id": 29,
                                "title": "خطوة رقم 5",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها خلال 60 دقيقة",
                                "sound": [
                                    "procedures/sounds/desc/29.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/29.webm"
                                ],
                                "imgs": [
                                    "procedures/images/29.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 10,
                        "title": "طلب فحص عداد",
                        "has_subservice": 0,
                        "desc": "<p>فحص عداد مشترك بناء علي طلبه</p>",
                        "sound": [
                            "services/sounds/desc/10.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/10.webm"
                        ],
                        "imgs": [
                            "services/images/10.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 22,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/22.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/22.webm"
                                ],
                                "imgs": [
                                    "documents/images/22.jpg"
                                ]
                            },
                            {
                                "id": 23,
                                "title": "بيانات الحساب",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/23.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/23.webm"
                                ],
                                "imgs": [
                                    "documents/images/23.png"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 19,
                                "question": "ما هي الإجراءات المطلوبة لطلب فحص عداد ؟",
                                "answer": " استيفاء استمارة طلب الفحص\nرفع العداد وفحصه بالمعمل\nعمل اجراءات تصفية الحساب والتسوية وفقا لقراءة رفع العداد وتقرير المعمل\nسداد الرسوم المقرره",
                                "sound": [
                                    "faqs/sounds/q_and_a/19.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/19.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 20,
                                "question": "ما هي الوثائق المطلوبة لطلب فحص عداد ؟",
                                "answer": " بطاقة الرقم القومي\nبيانات الحساب",
                                "sound": [
                                    "faqs/sounds/q_and_a/20.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/20.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 21,
                                "question": "ما هي الفترة الزمنية لطلب فحص عداد ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 3 أيام من سداد رسم الفحص",
                                "sound": [
                                    "faqs/sounds/q_and_a/21.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/21.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 22,
                                "question": "ما هي الإجراءات المطلوبة لطلب رفع عداد ؟",
                                "answer": " استيفاء استمارة طلب الرفع\nسداد الرسوم المقررة وجميع المستحقات علي العداد إن وجدت\nرفع العداد في حالة تمكين الشركة من الرفع",
                                "sound": [
                                    "faqs/sounds/q_and_a/22.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/22.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 23,
                                "question": "ما هي الوثائق المطلوبة لطلب رفع عداد ؟",
                                "answer": " بطاقة الرقم القومي\nبيانات الحساب",
                                "sound": [
                                    "faqs/sounds/q_and_a/23.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/23.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 30,
                                "title": "خطوة رقم 1",
                                "desc": "استيفاء استمارة طلب الفحص",
                                "sound": [
                                    "procedures/sounds/desc/30.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/30.webm"
                                ],
                                "imgs": [
                                    "procedures/images/30.png"
                                ]
                            },
                            {
                                "id": 31,
                                "title": "خطوة رقم 2",
                                "desc": "رفع العداد وفحصه بالمعمل",
                                "sound": [
                                    "procedures/sounds/desc/31.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/31.webm"
                                ],
                                "imgs": [
                                    "procedures/images/31.jpg"
                                ]
                            },
                            {
                                "id": 32,
                                "title": "خطوة رقم 3",
                                "desc": "عمل اجراءات تصفية الحساب والتسوية وفقا لقراءة رفع العداد وتقرير المعمل",
                                "sound": [
                                    "procedures/sounds/desc/32.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/32.webm"
                                ],
                                "imgs": [
                                    "procedures/images/32.jpg"
                                ]
                            },
                            {
                                "id": 33,
                                "title": "خطوة رقم 4",
                                "desc": "سداد الرسوم المقرره",
                                "sound": [
                                    "procedures/sounds/desc/33.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/33.webm"
                                ],
                                "imgs": [
                                    "procedures/images/33.jpg"
                                ]
                            },
                            {
                                "id": 34,
                                "title": "خطوة رقم 5",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 3 أيام من سداد رسم الفحص",
                                "sound": [
                                    "procedures/sounds/desc/34.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/34.webm"
                                ],
                                "imgs": [
                                    "procedures/images/34.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 11,
                        "title": "طلب رفع عداد",
                        "has_subservice": 0,
                        "desc": "<p>طلب رفع العداد من المشترك</p>",
                        "sound": [
                            "services/sounds/desc/11.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/11.webm"
                        ],
                        "imgs": [
                            "services/images/11.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 24,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/24.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/24.webm"
                                ],
                                "imgs": [
                                    "documents/images/24.jpg"
                                ]
                            },
                            {
                                "id": 25,
                                "title": "بيانات الحساب",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/25.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/25.webm"
                                ],
                                "imgs": [
                                    "documents/images/25.png"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 24,
                                "question": "ما هي الفترة الزمنية لطلب رفع عداد ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 3 أيام عمل",
                                "sound": [
                                    "faqs/sounds/q_and_a/24.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/24.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 35,
                                "title": "خطوة رقم 1",
                                "desc": "استيفاء استمارة طلب الرفع",
                                "sound": [
                                    "procedures/sounds/desc/35.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/35.webm"
                                ],
                                "imgs": [
                                    "procedures/images/35.png"
                                ]
                            },
                            {
                                "id": 36,
                                "title": "خطوة رقم 2",
                                "desc": "سداد الرسوم المقررة وجميع المستحقات علي العداد إن وجدت",
                                "sound": [
                                    "procedures/sounds/desc/36.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/36.webm"
                                ],
                                "imgs": [
                                    "procedures/images/36.jpg"
                                ]
                            },
                            {
                                "id": 37,
                                "title": "خطوة رقم 3",
                                "desc": "رفع العداد في حالة تمكين الشركة من الرفع",
                                "sound": [
                                    "procedures/sounds/desc/37.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/37.webm"
                                ],
                                "imgs": [
                                    "procedures/images/37.jpg"
                                ]
                            },
                            {
                                "id": 38,
                                "title": "خطوة رقم 4",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 3 أيام عمل",
                                "sound": [
                                    "procedures/sounds/desc/38.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/38.webm"
                                ],
                                "imgs": [
                                    "procedures/images/38.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 12,
                        "title": "استبدال عداد بقدرة أكبر",
                        "has_subservice": 0,
                        "desc": "<p>طلب المنتفع تركيب عداد بقدرة أكبر يتناسب مع زيادة الاحمال عن القدرة المتعاقد عليها</p>",
                        "sound": [
                            "services/sounds/desc/12.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/12.webm"
                        ],
                        "imgs": [
                            "services/images/12.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 26,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/26.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/26.webm"
                                ],
                                "imgs": [
                                    "documents/images/26.jpg"
                                ]
                            },
                            {
                                "id": 27,
                                "title": "بيانات الحساب",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/27.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/27.webm"
                                ],
                                "imgs": [
                                    "documents/images/27.png"
                                ]
                            },
                            {
                                "id": 28,
                                "title": "بيانات بالأحمال المطلوب تعذيتها",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/28.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/28.webm"
                                ],
                                "imgs": [
                                    "documents/images/28.png"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 25,
                                "question": "ما هي الإجراءات المطلوبة لاستبدال عداد بقدرة أكبر ؟",
                                "answer": " استيفاء النموذج المخصص لزيادة القدرة\nمعاينة الاحمال والتوصيلات علي الطبيعه\nتصفية مديونية العداد القديم\nسداد الرسوم وتكاليف المقايسة المقررة",
                                "sound": [
                                    "faqs/sounds/q_and_a/25.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/25.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 26,
                                "question": "ما هي الوثائق المطلوبة لاستبدال عداد بقدرة أكبر ؟",
                                "answer": " بطاقة الرقم القومي\nبيانات الحساب\nبيانات بالأحمال المطلوب تعذيتها",
                                "sound": [
                                    "faqs/sounds/q_and_a/26.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/26.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 27,
                                "question": "ما هي الفترة الزمنية لاستبدال عداد بقدرة أكبر ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 7 أيام عمل من سداد قيمة المقاسيه",
                                "sound": [
                                    "faqs/sounds/q_and_a/27.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/27.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 39,
                                "title": "خطوة رقم 1",
                                "desc": "استيفاء النموذج المخصص لزيادة القدرة",
                                "sound": [
                                    "procedures/sounds/desc/39.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/39.webm"
                                ],
                                "imgs": [
                                    "procedures/images/39.png"
                                ]
                            },
                            {
                                "id": 40,
                                "title": "خطوة رقم 2",
                                "desc": "معاينة الاحمال والتوصيلات علي الطبيعه",
                                "sound": [
                                    "procedures/sounds/desc/40.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/40.webm"
                                ],
                                "imgs": [
                                    "procedures/images/40.jpg"
                                ]
                            },
                            {
                                "id": 41,
                                "title": "خطوة رقم 3",
                                "desc": "تصفية مديونية العداد القديم",
                                "sound": [
                                    "procedures/sounds/desc/41.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/41.webm"
                                ],
                                "imgs": [
                                    "procedures/images/41.jpg"
                                ]
                            },
                            {
                                "id": 42,
                                "title": "خطوة رقم 4",
                                "desc": "سداد الرسوم وتكاليف المقايسة المقررة",
                                "sound": [
                                    "procedures/sounds/desc/42.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/42.webm"
                                ],
                                "imgs": [
                                    "procedures/images/42.jpg"
                                ]
                            },
                            {
                                "id": 43,
                                "title": "خطوة رقم 5",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 7 أيام عمل من سداد قيمة المقاسيه",
                                "sound": [
                                    "procedures/sounds/desc/43.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/43.webm"
                                ],
                                "imgs": [
                                    "procedures/images/43.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 13,
                        "title": "تعديل توصيلة   داخلية - خارجية",
                        "has_subservice": 0,
                        "desc": "<p>طلب المنتفع تعديل توصيلة الكهرباء الخاصة به</p>",
                        "sound": [
                            "services/sounds/desc/13.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/13.webm"
                        ],
                        "imgs": [
                            "services/images/13.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 29,
                                "title": "طلب تعديل توصيلة",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/29.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/29.webm"
                                ],
                                "imgs": [
                                    "documents/images/29.png"
                                ]
                            },
                            {
                                "id": 30,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/30.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/30.webm"
                                ],
                                "imgs": [
                                    "documents/images/30.jpg"
                                ]
                            },
                            {
                                "id": 31,
                                "title": "التصاريح المطلوبة",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/31.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/31.webm"
                                ],
                                "imgs": [
                                    "documents/images/31.jpg"
                                ]
                            },
                            {
                                "id": 32,
                                "title": "فاتورة كهرباء حديثة في حالة التوصيلة الداخليه",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/32.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/32.webm"
                                ],
                                "imgs": [
                                    "documents/images/32.jpg"
                                ]
                            },
                            {
                                "id": 33,
                                "title": "إيصال سداد المقايسة في حالة التوصيلة الخارجيه",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/33.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/33.webm"
                                ],
                                "imgs": [
                                    "documents/images/33.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 28,
                                "question": "ما هي الإجراءات المطلوبة لتعديل توصيلة ؟",
                                "answer": " إستيفاء الطلب<br>إجراء المعاينه اللازمة علي الطبيعة\nإعداد المقايسة وتكاليفها وسداد الرسوم المقررة\nتنفيذ التعديل وإنهاء الطلب",
                                "sound": [
                                    "faqs/sounds/q_and_a/28.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/28.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 29,
                                "question": "ما هي الوثائق المطلوبة لتعديل توصيلة ؟",
                                "answer": " طلب تعديل توصيلة<br>بطاقة الرقم القومي\nالتصاريح المطلوبة\nفاتورة كهرباء حديثة في حالة التوصيلة الداخليه",
                                "sound": [
                                    "faqs/sounds/q_and_a/29.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/29.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 30,
                                "question": "ما هي الفترة الزمنية لتعديل توصيلة ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 3 أيام عمل من تاريخ سداد قيمة المقاسيه",
                                "sound": [
                                    "faqs/sounds/q_and_a/30.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/30.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 44,
                                "title": "خطوة رقم 1",
                                "desc": "إستيفاء الطلب",
                                "sound": [
                                    "procedures/sounds/desc/44.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/44.webm"
                                ],
                                "imgs": [
                                    "procedures/images/44.png"
                                ]
                            },
                            {
                                "id": 45,
                                "title": "خطوة رقم 2",
                                "desc": "إجراء المعاينه اللازمة علي الطبيعة",
                                "sound": [
                                    "procedures/sounds/desc/45.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/45.webm"
                                ],
                                "imgs": [
                                    "procedures/images/45.jpg"
                                ]
                            },
                            {
                                "id": 46,
                                "title": "خطوة رقم 3",
                                "desc": "إعداد المقايسة وتكاليفها وسداد الرسوم المقررة",
                                "sound": [
                                    "procedures/sounds/desc/46.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/46.webm"
                                ],
                                "imgs": [
                                    "procedures/images/46.jpg"
                                ]
                            },
                            {
                                "id": 47,
                                "title": "خطوة رقم 4",
                                "desc": "تنفيذ التعديل وإنهاء الطلب",
                                "sound": [
                                    "procedures/sounds/desc/47.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/47.webm"
                                ],
                                "imgs": [
                                    "procedures/images/47.png"
                                ]
                            },
                            {
                                "id": 48,
                                "title": "خطوة رقم 5",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها حتي 3 أيام عمل من تاريخ سداد قيمة المقاسيه",
                                "sound": [
                                    "procedures/sounds/desc/48.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/48.webm"
                                ],
                                "imgs": [
                                    "procedures/images/48.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 14,
                        "title": "جدولة مديونية على اقساط شهرية",
                        "has_subservice": 0,
                        "desc": "<p>طلب تقسيط المديونية علي اقساط شهرية عن المديونية المستحقة وليس تراكم الاستهلاك</p>",
                        "sound": [
                            "services/sounds/desc/14.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/14.webm"
                        ],
                        "imgs": [
                            "services/images/14.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 34,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/34.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/34.webm"
                                ],
                                "imgs": [
                                    "documents/images/34.jpg"
                                ]
                            },
                            {
                                "id": 35,
                                "title": "نموذج طلب تقسيط مديونية",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/35.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/35.webm"
                                ],
                                "imgs": [
                                    "documents/images/35.png"
                                ]
                            },
                            {
                                "id": 36,
                                "title": "فاتورة كهرباء حديثة",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/36.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/36.webm"
                                ],
                                "imgs": [
                                    "documents/images/36.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 31,
                                "question": "ما هي الإجراءات المطلوبة لجدولة مديونية علي أقساط شهرية ؟",
                                "answer": " استيفاء نموذج طلب تقسيط مديونية\nدفع مبلغ 30% كدفعة مقدمة كحد  أدني ",
                                "sound": [
                                    "faqs/sounds/q_and_a/31.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/31.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 32,
                                "question": "ما هي الوثائق المطلوبة لجدولة مديونية علي أقساط شهرية ؟",
                                "answer": " بطاقة الرقم القومي\nنموذج طلب تقسيط مديونية\nفاتورة كهرباء حديثة",
                                "sound": [
                                    "faqs/sounds/q_and_a/32.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/32.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 33,
                                "question": "ما هي الفترة الزمنية لجدولة مديونية علي أقساط شهرية ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها خلال 30 دقيقة",
                                "sound": [
                                    "faqs/sounds/q_and_a/33.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/33.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 49,
                                "title": "خطوة رقم 1",
                                "desc": "استيفاء نموذج طلب تقسيط مديونية",
                                "sound": [
                                    "procedures/sounds/desc/49.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/49.webm"
                                ],
                                "imgs": [
                                    "procedures/images/49.png"
                                ]
                            },
                            {
                                "id": 50,
                                "title": "خطوة رقم 2",
                                "desc": "دفع مبلغ 30% كدفعة مقدمة كحد  أدني ",
                                "sound": [
                                    "procedures/sounds/desc/50.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/50.webm"
                                ],
                                "imgs": [
                                    "procedures/images/50.jpg"
                                ]
                            },
                            {
                                "id": 51,
                                "title": "خطوة رقم 3",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها خلال 30 دقيقة",
                                "sound": [
                                    "procedures/sounds/desc/51.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/51.webm"
                                ],
                                "imgs": [
                                    "procedures/images/51.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 15,
                        "title": "توصيل التيار الكهربائي للمباني السكنية القانونية",
                        "has_subservice": 0,
                        "desc": "<p>توصيل التيار الكهربائي للمباني السكنية الصادر لها موافقة من الحي المختص علي التوصيل</p>",
                        "sound": [
                            "services/sounds/desc/15.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/15.webm"
                        ],
                        "imgs": [
                            "services/images/15.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 37,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/37.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/37.webm"
                                ],
                                "imgs": [
                                    "documents/images/37.jpg"
                                ]
                            },
                            {
                                "id": 38,
                                "title": "الرخصة والرسومات المعمارية",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/38.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/38.webm"
                                ],
                                "imgs": [
                                    "documents/images/38.jpg"
                                ]
                            },
                            {
                                "id": 39,
                                "title": "خطاب من الجهة الإداريه المختصة بالموافقة علي التوصيل",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/39.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/39.webm"
                                ],
                                "imgs": [
                                    "documents/images/39.jpg"
                                ]
                            },
                            {
                                "id": 40,
                                "title": "سند الحيازة أو الملكية",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/40.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/40.webm"
                                ],
                                "imgs": [
                                    "documents/images/40.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 34,
                                "question": "ما هي الإجراءات المطلوبة لتوصيل التيار الكهربائي للمباني السكنية القانونية ؟",
                                "answer": " قيام المشترك باستيفاء طلب توصيل الكهرباء<br>إجراء المعاينة على الطبيعة وحساب تكلفة المقايسة و إدراجها للسداد<br>قيام المشترك بسداد قيمة المقايسة واستخراج التصاريح اللازمة للحفر في حالة طلبها<br>تنفيذ المقايسة والانتهاء من الطلب",
                                "sound": [
                                    "faqs/sounds/q_and_a/34.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/34.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 35,
                                "question": "ما هي الوثائق المطلوبة لتوصيل التيار الكهربائي للمباني السكنية القانونية ؟",
                                "answer": " بطاقة الرقم القومي\nالرخصة والرسومات المعمارية<br>خطاب من الجهة الإداريه المختصة بالموافقة علي التوصيل\nسند الحيازة أو الملكية",
                                "sound": [
                                    "faqs/sounds/q_and_a/35.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/35.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 36,
                                "question": "ما هي الفترة الزمنية لتوصيل التيار الكهربائي للمباني السكنية القانونية ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها كما يلي :\nتقديم الطلب - يوم واحد\nعمل المعاينة وإعداد المقاسية وإدراجها للسداد - 8 أيام من تاريخ تقديم الطلب\nتنفيذ المقايسة وتركيب العداد - 9 أيام بعد سداد المقايسة واستخراج تصاريح الحفر\nإجمالي المدة 18 يوم",
                                "sound": [
                                    "faqs/sounds/q_and_a/36.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/36.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 52,
                                "title": "خطوة رقم 1",
                                "desc": "قيام المشترك باستيفاء طلب توصيل الكهرباء",
                                "sound": [
                                    "procedures/sounds/desc/52.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/52.webm"
                                ],
                                "imgs": [
                                    "procedures/images/52.png"
                                ]
                            },
                            {
                                "id": 53,
                                "title": "خطوة رقم 2",
                                "desc": "إجراء المعاينة على الطبيعة وحساب تكلفة المقايسة و إدراجها للسداد",
                                "sound": [
                                    "procedures/sounds/desc/53.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/53.webm"
                                ],
                                "imgs": [
                                    "procedures/images/53.png"
                                ]
                            },
                            {
                                "id": 54,
                                "title": "خطوة رقم 3",
                                "desc": "قيام المشترك بسداد قيمة المقايسة واستخراج التصاريح اللازمة للحفر في حالة طلبها",
                                "sound": [
                                    "procedures/sounds/desc/54.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/54.webm"
                                ],
                                "imgs": [
                                    "procedures/images/54.jpg"
                                ]
                            },
                            {
                                "id": 55,
                                "title": "خطوة رقم 4",
                                "desc": "تنفيذ المقايسة والانتهاء من الطلب",
                                "sound": [
                                    "procedures/sounds/desc/55.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/55.webm"
                                ],
                                "imgs": [
                                    "procedures/images/55.png"
                                ]
                            },
                            {
                                "id": 56,
                                "title": "خطوة رقم 5",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها كما يلي :\nتقديم الطلب - يوم واحد عمل المعاينة وإعداد المقاسية وإدراجها للسداد - 8 أيام من تاريخ تقديم الطلب تنفيذ المقايسة وتركيب العداد - 9 أيام بعد سداد المقايسة واستخراج تصاريح الحفر إجمالي المدة 18 يوم",
                                "sound": [
                                    "procedures/sounds/desc/56.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/56.webm"
                                ],
                                "imgs": [
                                    "procedures/images/56.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 16,
                        "title": "توصيل التيار الكهربائي للمنشآت الاستثمارية",
                        "has_subservice": 0,
                        "desc": "<p>توصيل التيار الكهربي للمشروعات الاستثمارية</p>",
                        "sound": [
                            "services/sounds/desc/16.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/16.webm"
                        ],
                        "imgs": [
                            "services/images/16.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 41,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/41.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/41.webm"
                                ],
                                "imgs": [
                                    "documents/images/41.jpg"
                                ]
                            },
                            {
                                "id": 42,
                                "title": "سند الحيازة",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/42.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/42.webm"
                                ],
                                "imgs": [
                                    "documents/images/42.jpg"
                                ]
                            },
                            {
                                "id": 43,
                                "title": "البطاقة الضريبيه",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/43.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/43.webm"
                                ],
                                "imgs": [
                                    "documents/images/43.jpg"
                                ]
                            },
                            {
                                "id": 44,
                                "title": "السجل التجاري",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/44.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/44.webm"
                                ],
                                "imgs": [
                                    "documents/images/44.jpg"
                                ]
                            },
                            {
                                "id": 45,
                                "title": "خطاب الجهة الإداريه المختصة بالموافقة علي توصيل الكهرباء",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/45.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/45.webm"
                                ],
                                "imgs": [
                                    "documents/images/45.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 37,
                                "question": "ما هي الإجراءات المطلوبة لتوصيل التيار للمنشأت الاستثمارية ؟",
                                "answer": " قيام المشترك باستيفاء طلب توصيل الكهرباء<br>إجراء المعاينة على الطبيعة وحساب تكلفة المقايسة و إدراجها للسداد<br>قيام المشترك بسداد قيمة المقايسة واستخراج التصاريح اللازمة للحفر في حالة طلبها<br>تنفيذ المقايسة والانتهاء من الطلب",
                                "sound": [
                                    "faqs/sounds/q_and_a/37.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/37.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 38,
                                "question": "ما هي الوثائق المطلوبة لتوصيل التيار للمنشأت الاستثمارية ؟",
                                "answer": " بطاقة الرقم القومي\nسند الحيازة<br>البطاقة الضريبيه\nالسجل التجاري\nخطاب الجهة الإداريه المختصة بالموافقة علي توصيل الكهرباء",
                                "sound": [
                                    "faqs/sounds/q_and_a/38.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/38.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 39,
                                "question": "ما هي الفترة الزمنية لتوصيل التيار للمنشأت الاستثمارية ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها كما يلي :\nتقديم الطلب - يوم واحد\nعمل المعاينة وإعداد المقاسية وإدراجها للسداد - 8 أيام من تاريخ تقديم الطلب\nتنفيذ المقايسة وتركيب العداد - 9 أيام بعد سداد المقايسة واستخراج تصاريح الحفر\nإجمالي المدة 18 يوم",
                                "sound": [
                                    "faqs/sounds/q_and_a/39.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/39.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 57,
                                "title": "خطوة رقم 1",
                                "desc": "قيام المشترك باستيفاء طلب توصيل الكهرباء",
                                "sound": [
                                    "procedures/sounds/desc/57.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/57.webm"
                                ],
                                "imgs": [
                                    "procedures/images/57.png"
                                ]
                            },
                            {
                                "id": 58,
                                "title": "خطوة رقم 2",
                                "desc": "إجراء المعاينة على الطبيعة وحساب تكلفة المقايسة و إدراجها للسداد",
                                "sound": [
                                    "procedures/sounds/desc/58.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/58.webm"
                                ],
                                "imgs": [
                                    "procedures/images/58.jpg"
                                ]
                            },
                            {
                                "id": 59,
                                "title": "خطوة رقم 3",
                                "desc": "قيام المشترك بسداد قيمة المقايسة واستخراج التصاريح اللازمة للحفر في حالة طلبها",
                                "sound": [
                                    "procedures/sounds/desc/59.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/59.webm"
                                ],
                                "imgs": [
                                    "procedures/images/59.jpg"
                                ]
                            },
                            {
                                "id": 60,
                                "title": "خطوة رقم 4",
                                "desc": "تنفيذ المقايسة والانتهاء من الطلب",
                                "sound": [
                                    "procedures/sounds/desc/60.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/60.webm"
                                ],
                                "imgs": [
                                    "procedures/images/60.jpg"
                                ]
                            },
                            {
                                "id": 61,
                                "title": "خطوة رقم 5",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها كما يلي :\nتقديم الطلب - يوم واحد عمل المعاينة وإعداد المقاسية وإدراجها للسداد - 8 أيام من تاريخ تقديم الطلب تنفيذ المقايسة وتركيب العداد - 9 أيام بعد سداد المقايسة واستخراج تصاريح الحفر إجمالي المدة 18 يوم",
                                "sound": [
                                    "procedures/sounds/desc/61.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/61.webm"
                                ],
                                "imgs": [
                                    "procedures/images/61.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 17,
                        "title": "توصيل تيار مؤقت",
                        "has_subservice": 0,
                        "desc": "<p>توصيل الكهرباء بصفة مؤقتة لحين استكمال الإنشاءات</p>",
                        "sound": [
                            "services/sounds/desc/17.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/17.webm"
                        ],
                        "imgs": [
                            "services/images/17.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 46,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/46.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/46.webm"
                                ],
                                "imgs": [
                                    "documents/images/46.jpg"
                                ]
                            },
                            {
                                "id": 47,
                                "title": "طلب العميل بتركيب عداد بصفة مؤقتة",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/47.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/47.webm"
                                ],
                                "imgs": [
                                    "documents/images/47.png"
                                ]
                            },
                            {
                                "id": 48,
                                "title": "موافقة الجهة الادارية المختصة علي التوصيل المؤقت",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/48.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/48.webm"
                                ],
                                "imgs": [
                                    "documents/images/48.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 40,
                                "question": "ما هي الإجراءات المطلوبة لتوصيل تيار مؤقت ؟",
                                "answer": " قيام المشترك باستيفاء طلب توصيل الكهرباء.<br>\nإجراء المعاينة على الطبيعة وحساب تكلفة المقايسة و إدراجها للسداد<br>قيام المشترك بسداد قيمة المقايسة واستخراج التصاريح اللازمة للحفر في حالة طلبها\nتنفيذ المقايسة وتركيب العداد والانتهاء من الطلب",
                                "sound": [
                                    "faqs/sounds/q_and_a/40.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/40.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 41,
                                "question": "ما هي الوثائق المطلوبة لتوصيل تيار مؤقت ؟",
                                "answer": " بطاقة الرقم القومي<br>طلب العميل بتركيب عداد بصفة مؤقتة\nموافقة الجهة الادارية المختصة علي التوصيل المؤقت",
                                "sound": [
                                    "faqs/sounds/q_and_a/41.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/41.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 42,
                                "question": "ما هي الفترة الزمنية لتوصيل تيار مؤقت ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها 3 أيام من تاريخ سداد المقايسة واستخراج التصاريح اللازمة",
                                "sound": [
                                    "faqs/sounds/q_and_a/42.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/42.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 62,
                                "title": "خطوة رقم 1",
                                "desc": "قيام المشترك باستيفاء طلب توصيل الكهرباء.<br>",
                                "sound": [
                                    "procedures/sounds/desc/62.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/62.webm"
                                ],
                                "imgs": [
                                    "procedures/images/62.png"
                                ]
                            },
                            {
                                "id": 63,
                                "title": "خطوة رقم 2",
                                "desc": "إجراء المعاينة على الطبيعة وحساب تكلفة المقايسة و إدراجها للسداد",
                                "sound": [
                                    "procedures/sounds/desc/63.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/63.webm"
                                ],
                                "imgs": [
                                    "procedures/images/63.jpg"
                                ]
                            },
                            {
                                "id": 64,
                                "title": "خطوة رقم 3",
                                "desc": "قيام المشترك بسداد قيمة المقايسة واستخراج التصاريح اللازمة للحفر في حالة طلبها",
                                "sound": [
                                    "procedures/sounds/desc/64.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/64.webm"
                                ],
                                "imgs": [
                                    "procedures/images/64.jpg"
                                ]
                            },
                            {
                                "id": 65,
                                "title": "خطوة رقم 4",
                                "desc": "تنفيذ المقايسة وتركيب العداد والانتهاء من الطلب",
                                "sound": [
                                    "procedures/sounds/desc/65.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/65.webm"
                                ],
                                "imgs": [
                                    "procedures/images/65.jpg"
                                ]
                            },
                            {
                                "id": 66,
                                "title": "خطوة رقم 5",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها 3 أيام من تاريخ سداد المقايسة واستخراج التصاريح اللازمة",
                                "sound": [
                                    "procedures/sounds/desc/66.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/66.webm"
                                ],
                                "imgs": [
                                    "procedures/images/66.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 18,
                        "title": "توصيل التيار الكهربائي للمباني غير القانونية",
                        "has_subservice": 0,
                        "desc": "<p>اتخاذ الاجراءات الفنية اللازمة لتأهيل المبني لتركيب العدادات الكودية المؤقته لقياس استهلاك الكهرباء الموصل بوسائل غير قانونية</p>",
                        "sound": [
                            "services/sounds/desc/18.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/18.webm"
                        ],
                        "imgs": [
                            "services/images/18.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 49,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/49.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/49.webm"
                                ],
                                "imgs": [
                                    "documents/images/49.jpg"
                                ]
                            }
                        ],
                        "faqs": [],
                        "procedures": [
                            {
                                "id": 67,
                                "title": "خطوة رقم 1",
                                "desc": "قيام المشترك باستيفاء نموذج طلب تركيب عداد كودي مؤقت  طبقا لكشوف حصر تعدها شركات التوزيع أو من خلال محاضر المخالفات والممارسات المحررة عن طريق الجهة المختصة ",
                                "sound": [
                                    "procedures/sounds/desc/67.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/67.webm"
                                ],
                                "imgs": [
                                    "procedures/images/67.png"
                                ]
                            },
                            {
                                "id": 68,
                                "title": "خطوة رقم 2",
                                "desc": "إجــراء المعاينة على الطبيعة وحساب تكلفة المقايسة و إدراجها للسداد",
                                "sound": [
                                    "procedures/sounds/desc/68.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/68.webm"
                                ],
                                "imgs": [
                                    "procedures/images/68.jpg"
                                ]
                            },
                            {
                                "id": 69,
                                "title": "خطوة رقم 3",
                                "desc": "قيام المشترك بسداد قيمة المقايسة واستخراج التصاريح اللازمة لتأهيل الشبكة في حال طلبها",
                                "sound": [
                                    "procedures/sounds/desc/69.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/69.webm"
                                ],
                                "imgs": [
                                    "procedures/images/69.jpg"
                                ]
                            },
                            {
                                "id": 70,
                                "title": "خطوة رقم 4",
                                "desc": "تنفيذ المقايسة والانتهاء من الطلب",
                                "sound": [
                                    "procedures/sounds/desc/70.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/70.webm"
                                ],
                                "imgs": [
                                    "procedures/images/70.png"
                                ]
                            },
                            {
                                "id": 71,
                                "title": "خطوة رقم 5",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها كما يلي :\nتقديم الطلب - يوم واحد عمل المعاينة وإعداد المقاسية وإدراجها للسداد - 8 أيام من تاريخ تقديم الطلب تنفيذ المقايسة وتركيب العداد - 9 أيام بعد سداد المقايسة واستخراج تصاريح الحفر إجمالي المدة 18 يوم",
                                "sound": [
                                    "procedures/sounds/desc/71.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/71.webm"
                                ],
                                "imgs": [
                                    "procedures/images/71.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 19,
                        "title": "سداد دفعة مقدمة تحت الحساب",
                        "has_subservice": 0,
                        "desc": "<p>قيام المشترك بسداد دفعة مقدمة تحت حساب استهلاك الكهرباء نظرا لتغيبه عن المكان أو رغبته في السداد مقدما</p>",
                        "sound": [
                            "services/sounds/desc/19.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/19.webm"
                        ],
                        "imgs": [
                            "services/images/19.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 50,
                                "title": "بيانات الحساب",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/50.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/50.webm"
                                ],
                                "imgs": [
                                    "documents/images/50.png"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 43,
                                "question": "ما هي الإجراءات المطلوبة لسداد دفعه مقدمة تحت الحساب ؟",
                                "answer": " توريد قيمة الدفعة المقدمة للخزينه\nاستلام ايصال بما تم سدادة",
                                "sound": [
                                    "faqs/sounds/q_and_a/43.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/43.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 44,
                                "question": "ما هي الوثائق المطلوبة لسداد دفعه مقدمة تحت الحساب ؟",
                                "answer": " بيانات الحساب",
                                "sound": [
                                    "faqs/sounds/q_and_a/44.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/44.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 45,
                                "question": "ما هي الفترة الزمنية لسداد دفعه مقدمة تحت الحساب ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "faqs/sounds/q_and_a/45.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/45.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 72,
                                "title": "خطوة رقم 1",
                                "desc": "توريد قيمة الدفعة المقدمة للخزينه",
                                "sound": [
                                    "procedures/sounds/desc/72.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/72.webm"
                                ],
                                "imgs": [
                                    "procedures/images/72.jpg"
                                ]
                            },
                            {
                                "id": 73,
                                "title": "خطوة رقم 2",
                                "desc": "استلام ايصال بما تم سدادة",
                                "sound": [
                                    "procedures/sounds/desc/73.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/73.webm"
                                ],
                                "imgs": [
                                    "procedures/images/73.jpg"
                                ]
                            },
                            {
                                "id": 74,
                                "title": "خطوة رقم 3",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "procedures/sounds/desc/74.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/74.webm"
                                ],
                                "imgs": [
                                    "procedures/images/74.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 20,
                        "title": "مبيعات لمبات LED",
                        "has_subservice": 0,
                        "desc": "<p>طلب شراء لمبات LED نقدا أو بالتقسيط</p>",
                        "sound": [
                            "services/sounds/desc/20.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/20.webm"
                        ],
                        "imgs": [
                            "services/images/20.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 51,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/51.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/51.webm"
                                ],
                                "imgs": [
                                    "documents/images/51.jpg"
                                ]
                            },
                            {
                                "id": 52,
                                "title": "بيانات الحساب في حالة التقسيط",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/52.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/52.webm"
                                ],
                                "imgs": [
                                    "documents/images/52.png"
                                ]
                            },
                            {
                                "id": 53,
                                "title": "طلب شراء لمبات",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/53.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/53.webm"
                                ],
                                "imgs": [
                                    "documents/images/53.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 46,
                                "question": "ما هي الإجراءات المطلوبة لشراء لمبات LED ؟",
                                "answer": " استيفاء طلب شراء لمبات LED\nسداد المديونية المتاخرة في حالة التقسيط",
                                "sound": [
                                    "faqs/sounds/q_and_a/46.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/46.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 47,
                                "question": "ما هي الوثائق المطلوبة لسداد دفعه مقدمة تحت الحساب ؟",
                                "answer": " بطاقة الرقم القومي<br>بيانات الحساب في حالة التقسيط\nطلب شراء لمبات",
                                "sound": [
                                    "faqs/sounds/q_and_a/47.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/47.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 48,
                                "question": "ما هي الفترة الزمنية لسداد دفعه مقدمة تحت الحساب ؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها 15 دقيقة",
                                "sound": [
                                    "faqs/sounds/q_and_a/48.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/48.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 75,
                                "title": "خطوة رقم 1",
                                "desc": "استيفاء طلب شراء لمبات LED",
                                "sound": [
                                    "procedures/sounds/desc/75.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/75.webm"
                                ],
                                "imgs": [
                                    "procedures/images/75.jpg"
                                ]
                            },
                            {
                                "id": 76,
                                "title": "خطوة رقم 2",
                                "desc": "سداد المديونية المتاخرة في حالة التقسيط",
                                "sound": [
                                    "procedures/sounds/desc/76.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/76.webm"
                                ],
                                "imgs": [
                                    "procedures/images/76.jpg"
                                ]
                            },
                            {
                                "id": 77,
                                "title": "خطوة رقم 3",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها 15 دقيقة",
                                "sound": [
                                    "procedures/sounds/desc/77.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/77.webm"
                                ],
                                "imgs": [
                                    "procedures/images/77.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 21,
                        "title": "تغيير نوع النشاط المتعاقد عليه",
                        "has_subservice": 0,
                        "desc": "<p>رغبة المشترك في تغيير نوع النشاط المتعاقد عليه</p>",
                        "sound": [
                            "services/sounds/desc/21.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/21.webm"
                        ],
                        "imgs": [
                            "services/images/21.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 54,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/54.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/54.webm"
                                ],
                                "imgs": [
                                    "documents/images/54.jpg"
                                ]
                            },
                            {
                                "id": 55,
                                "title": "إيصال كهرباء حديث",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/55.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/55.webm"
                                ],
                                "imgs": [
                                    "documents/images/55.jpg"
                                ]
                            },
                            {
                                "id": 56,
                                "title": "البطاقة الضريبيه الخاصة به في حالة النشاط التجاري والصناعي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/56.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/56.webm"
                                ],
                                "imgs": [
                                    "documents/images/56.jpg"
                                ]
                            },
                            {
                                "id": 57,
                                "title": "موافقة الجهة الادارية المختصة",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/57.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/57.webm"
                                ],
                                "imgs": [
                                    "documents/images/57.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 49,
                                "question": "ما هي الإجراءات<br>لتغيير نوع النشاط المتعاقد عليه ؟",
                                "answer": " استيفاء نموذج الطلب\nالمعاينة علي الطبيعة\nسداد الرسوم المقررة",
                                "sound": [
                                    "faqs/sounds/q_and_a/49.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/49.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 50,
                                "question": "ما هي الوثائق المطلوبة لتغيير نوع النشاط المتعاقد عليه<br>؟",
                                "answer": " بطاقة الرقم القومي\nإيصال كهرباء حديث\nالبطاقة الضريبيه الخاصة به في حالة النشاط التجاري والصناعي\nموافقة الجهة الادارية المختصة",
                                "sound": [
                                    "faqs/sounds/q_and_a/50.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/50.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 51,
                                "question": "ما هي الفترة الزمنية لتغيير نوع النشاط المتعاقد عليه<br>؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها 30 دقيقة",
                                "sound": [
                                    "faqs/sounds/q_and_a/51.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/51.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 78,
                                "title": "خطوة رقم 1",
                                "desc": "استيفاء نموذج الطلب",
                                "sound": [
                                    "procedures/sounds/desc/78.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/78.webm"
                                ],
                                "imgs": [
                                    "procedures/images/78.jpg"
                                ]
                            },
                            {
                                "id": 79,
                                "title": "خطوة رقم 2",
                                "desc": "المعاينة علي الطبيعة",
                                "sound": [
                                    "procedures/sounds/desc/79.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/79.webm"
                                ],
                                "imgs": [
                                    "procedures/images/79.jpg"
                                ]
                            },
                            {
                                "id": 80,
                                "title": "خطوة رقم 3",
                                "desc": "سداد الرسوم المقررة",
                                "sound": [
                                    "procedures/sounds/desc/80.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/80.webm"
                                ],
                                "imgs": [
                                    "procedures/images/80.jpg"
                                ]
                            },
                            {
                                "id": 81,
                                "title": "خطوة رقم 4",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها 30 دقيقة",
                                "sound": [
                                    "procedures/sounds/desc/81.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/81.webm"
                                ],
                                "imgs": [
                                    "procedures/images/81.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 22,
                        "title": "تصحيح قراءة خاطئة",
                        "has_subservice": 0,
                        "desc": "<p>تصحيح القراءة الخاطئة بالإيصال</p>",
                        "sound": [
                            "services/sounds/desc/22.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/22.webm"
                        ],
                        "imgs": [
                            "services/images/22.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 58,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/58.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/58.webm"
                                ],
                                "imgs": [
                                    "documents/images/58.jpg"
                                ]
                            },
                            {
                                "id": 59,
                                "title": "الايصال الخاطئ",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/59.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/59.webm"
                                ],
                                "imgs": [
                                    "documents/images/59.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 52,
                                "question": "ما هي الإجراءات<br>لتصحيح قراءة خاطئة ؟",
                                "answer": " المعاينة علي الطبيعة لفحص العداد ظاهريا\nتعديل القراءة طبقا للقراءة علي الطبيعة\nفي حالة الخطأ يتم إلغاء الإيصالات الخاطئة وتعديلها",
                                "sound": [
                                    "faqs/sounds/q_and_a/52.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/52.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 53,
                                "question": "ما هي الوثائق المطلوبة لتصحيح قراءة خاطئة<br>؟",
                                "answer": " بطاقة الرقم القومي\nالايصال الخاطئ",
                                "sound": [
                                    "faqs/sounds/q_and_a/53.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/53.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 54,
                                "question": "ما هي الفترة الزمنية لتصحيح قراءة خاطئة<br>؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "faqs/sounds/q_and_a/54.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/54.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 82,
                                "title": "خطوة رقم 1",
                                "desc": "المعاينة علي الطبيعة لفحص العداد ظاهريا",
                                "sound": [
                                    "procedures/sounds/desc/82.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/82.webm"
                                ],
                                "imgs": [
                                    "procedures/images/82.jpg"
                                ]
                            },
                            {
                                "id": 83,
                                "title": "خطوة رقم 2",
                                "desc": "تعديل القراءة طبقا للقراءة علي الطبيعة",
                                "sound": [
                                    "procedures/sounds/desc/83.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/83.webm"
                                ],
                                "imgs": [
                                    "procedures/images/83.jpg"
                                ]
                            },
                            {
                                "id": 84,
                                "title": "خطوة رقم 3",
                                "desc": "في حالة الخطأ يتم إلغاء الإيصالات الخاطئة وتعديلها",
                                "sound": [
                                    "procedures/sounds/desc/84.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/84.webm"
                                ],
                                "imgs": [
                                    "procedures/images/84.png"
                                ]
                            },
                            {
                                "id": 85,
                                "title": "خطوة رقم 4",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "procedures/sounds/desc/85.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/85.webm"
                                ],
                                "imgs": [
                                    "procedures/images/85.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 23,
                        "title": "إبلاغ عن قراءة العداد",
                        "has_subservice": 0,
                        "desc": "<p>يمكن للمواطن إبلاغ قراءة العداد بنفسه من خلال قنوات متعددة من ضمنها : - الخط الساخن 121 الذي يعمل علي مدار الساعة - الموقع الإلكتروني لشركات التوزيع</p>",
                        "sound": [
                            "services/sounds/desc/23.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/23.webm"
                        ],
                        "imgs": [
                            "services/images/23.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 60,
                                "title": "بيانات الحساب",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/60.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/60.webm"
                                ],
                                "imgs": [
                                    "documents/images/60.png"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 55,
                                "question": "ما هي الإجراءات المطلوبة للإبلاغ عن قراءة العداد ؟",
                                "answer": " يمكن للمواطن إبلاغ قراءة العداد بنفسه من خلال قنوات متعدده من ضمنها :\n- الخط الساخن 121 الذي يعمل علي مدار الساعة\n- الموقع الألكتروني لشركات التوزيع",
                                "sound": [
                                    "faqs/sounds/q_and_a/55.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/55.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 56,
                                "question": "ما هي الوثائق المطلوبة المطلوبة للإبلاغ عن قراءة العداد<br>؟",
                                "answer": " بيانات الحساب",
                                "sound": [
                                    "faqs/sounds/q_and_a/56.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/56.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 57,
                                "question": "ما هي الفترة الزمنية المطلوبة للإبلاغ عن قراءة العداد<br>؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "faqs/sounds/q_and_a/57.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/57.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 86,
                                "title": "خطوة رقم 1",
                                "desc": "يمكن للمواطن إبلاغ قراءة العداد بنفسه من خلال قنوات متعدده من ضمنها : - الخط الساخن 121 الذي يعمل علي مدار الساعة - الموقع الألكتروني لشركات التوزيع",
                                "sound": [
                                    "procedures/sounds/desc/86.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/86.webm"
                                ],
                                "imgs": [
                                    "procedures/images/86.jpg"
                                ]
                            },
                            {
                                "id": 87,
                                "title": "خطوة رقم 2",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "procedures/sounds/desc/87.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/87.webm"
                                ],
                                "imgs": [
                                    "procedures/images/87.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 24,
                        "title": "سداد الفواتير عن طريق منافذ السداد الالكتروني",
                        "has_subservice": 0,
                        "desc": "<p>اتاحة السداد النقدي وغير النقدي لقيمة فواتير الكهرباء عبر منافذ السداد الإلكتروني في انحاء الجمهورية</p>",
                        "sound": [
                            "services/sounds/desc/24.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/24.webm"
                        ],
                        "imgs": [
                            "services/images/24.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 61,
                                "title": "بيانات الحساب",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/61.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/61.webm"
                                ],
                                "imgs": [
                                    "documents/images/61.png"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 58,
                                "question": "ما هي الوثائق المطلوبة المطلوبة لسداد الفواتير عن طريق منافذ السداد الالكتروني ؟",
                                "answer": " بيانات الحساب",
                                "sound": [
                                    "faqs/sounds/q_and_a/58.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/58.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 59,
                                "question": "ما هي الفترة الزمنية المطلوبة<br>لسداد الفواتير عن طريق منافذ السداد الالكتروني<br>؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "faqs/sounds/q_and_a/59.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/59.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 88,
                                "title": "خطوة رقم 1",
                                "desc": "اتاحة السداد النقدي وغير النقدي لقيمة فواتير الكهرباء عبر منافذ السداد الألكتروني في أنحاء الجمهورية",
                                "sound": [
                                    "procedures/sounds/desc/88.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/88.webm"
                                ],
                                "imgs": [
                                    "procedures/images/88.png"
                                ]
                            },
                            {
                                "id": 89,
                                "title": "خطوة رقم 2",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "procedures/sounds/desc/89.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/89.webm"
                                ],
                                "imgs": [
                                    "procedures/images/89.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 25,
                        "title": "شحن کارت مسبق الدفع",
                        "has_subservice": 0,
                        "desc": "<p>شحن كارت عداد مسبق الدفع من خلال مراكز تقديم الخدمة بشركات توزيع الكهرباء أو منافذ السداد الإلكتروني في انحاء الجمهورية</p>",
                        "sound": [
                            "services/sounds/desc/25.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/25.webm"
                        ],
                        "imgs": [
                            "services/images/25.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 62,
                                "title": "كارت شحن",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/62.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/62.webm"
                                ],
                                "imgs": [
                                    "documents/images/62.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 60,
                                "question": "ما هي الإجراءات المطلوبة لشحن كارت مسبق الدفع ؟",
                                "answer": " تقديم كارت الشحن\nشحن الكارت بالقيمة المسددة طبقا للإيصال",
                                "sound": [
                                    "faqs/sounds/q_and_a/60.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/60.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 61,
                                "question": "ما هي الوثائق المطلوبة المطلوبة لشحن كارت مسبق الدفع<br>؟",
                                "answer": " كارت شحن",
                                "sound": [
                                    "faqs/sounds/q_and_a/61.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/61.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 62,
                                "question": "ما هي الفترة الزمنية المطلوبة لشحن كارت مسبق الدفع<br>؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "faqs/sounds/q_and_a/62.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/62.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 90,
                                "title": "خطوة رقم 1",
                                "desc": "تقديم كارت الشحن",
                                "sound": [
                                    "procedures/sounds/desc/90.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/90.webm"
                                ],
                                "imgs": [
                                    "procedures/images/90.jpg"
                                ]
                            },
                            {
                                "id": 91,
                                "title": "خطوة رقم 2",
                                "desc": "شحن الكارت بالقيمة المسددة طبقا للإيصال",
                                "sound": [
                                    "procedures/sounds/desc/91.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/91.webm"
                                ],
                                "imgs": [
                                    "procedures/images/91.jpg"
                                ]
                            },
                            {
                                "id": 92,
                                "title": "خطوة رقم 3",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "procedures/sounds/desc/92.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/92.webm"
                                ],
                                "imgs": [
                                    "procedures/images/92.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 26,
                        "title": "استخراج کارت شحن بدل تالف او بدل فاقد",
                        "has_subservice": 0,
                        "desc": "<p>طلب استخراج كارت شحن بدل تالف او بدل فاقد</p>",
                        "sound": [
                            "services/sounds/desc/26.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/26.webm"
                        ],
                        "imgs": [
                            "services/images/26.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 63,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/63.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/63.webm"
                                ],
                                "imgs": [
                                    "documents/images/63.jpg"
                                ]
                            },
                            {
                                "id": 64,
                                "title": "ايصال شحن سابق او كود المشترك",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/64.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/64.webm"
                                ],
                                "imgs": [
                                    "documents/images/64.png"
                                ]
                            },
                            {
                                "id": 65,
                                "title": "اقرار كتابي بفقد الكارت",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/65.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/65.webm"
                                ],
                                "imgs": [
                                    "documents/images/65.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 63,
                                "question": "ما هي الإجراءات المطلوبة لاستخراج کارت شحن بدل تالف او بدل فاقد ؟",
                                "answer": " استيفاء طلب استخراج كارت شحن بدل تالف او بدل فاقد\nسداد الرسوم المقررة",
                                "sound": [
                                    "faqs/sounds/q_and_a/63.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/63.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 64,
                                "question": "ما هي الوثائق المطلوبة المطلوبة لاستخراج کارت شحن بدل تالف او بدل فاقد<br>؟",
                                "answer": " بطاقة الرقم القومي\nايصال شحن سابق او كود المشترك<br>اقرار كتابي بفقد الكارت",
                                "sound": [
                                    "faqs/sounds/q_and_a/64.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/64.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 65,
                                "question": "ما هي الفترة الزمنية المطلوبة لاستخراج کارت شحن بدل تالف او بدل فاقد<br>؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها 25 دقيقة",
                                "sound": [
                                    "faqs/sounds/q_and_a/65.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/65.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 93,
                                "title": "خطوة رقم 1",
                                "desc": "استيفاء طلب استخراج كارت شحن بدل تالف او بدل فاقد",
                                "sound": [
                                    "procedures/sounds/desc/93.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/93.webm"
                                ],
                                "imgs": [
                                    "procedures/images/93.jpg"
                                ]
                            },
                            {
                                "id": 94,
                                "title": "خطوة رقم 2",
                                "desc": "سداد الرسوم المقررة",
                                "sound": [
                                    "procedures/sounds/desc/94.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/94.webm"
                                ],
                                "imgs": [
                                    "procedures/images/94.jpg"
                                ]
                            },
                            {
                                "id": 95,
                                "title": "خطوة رقم 3",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها 25 دقيقة",
                                "sound": [
                                    "procedures/sounds/desc/95.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/95.webm"
                                ],
                                "imgs": [
                                    "procedures/images/95.png"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 27,
                        "title": "تصحيح اسم وبيانات مشترك",
                        "has_subservice": 0,
                        "desc": "<p>طلب تصحيح اسم او بيانات بايصال استهلاك الكهرباء</p>",
                        "sound": [
                            "services/sounds/desc/27.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/27.webm"
                        ],
                        "imgs": [
                            "services/images/27.jpg"
                        ],
                        "sub_sub_services": [],
                        "docs": [
                            {
                                "id": 66,
                                "title": "بطاقة الرقم القومي",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/66.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/66.webm"
                                ],
                                "imgs": [
                                    "documents/images/66.jpg"
                                ]
                            },
                            {
                                "id": 67,
                                "title": "فاتورة كهرباء حديثة",
                                "desc": null,
                                "sound": [
                                    "documents/sounds/title/67.mp3"
                                ],
                                "vids": [
                                    "documents/videos/title/67.webm"
                                ],
                                "imgs": [
                                    "documents/images/67.jpg"
                                ]
                            }
                        ],
                        "faqs": [
                            {
                                "id": 66,
                                "question": "ما هي الإجراءات المطلوبة لتصحيح اسم وبيانات مشترك ؟",
                                "answer": " طلب من المنتفع بالتعديل المطلوب\nمراجعة الملف",
                                "sound": [
                                    "faqs/sounds/q_and_a/66.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/66.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 67,
                                "question": "ما هي الوثائق المطلوبة المطلوبة لتصحيح اسم وبيانات مشترك<br>؟",
                                "answer": " بطاقة الرقم القومي\nفاتورة كهرباء حديثة",
                                "sound": [
                                    "faqs/sounds/q_and_a/67.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/67.webm"
                                ],
                                "imgs": []
                            },
                            {
                                "id": 68,
                                "question": "ما هي الفترة الزمنية المطلوبة لتصحيح اسم وبيانات مشترك<br>؟",
                                "answer": " الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "faqs/sounds/q_and_a/68.mp3"
                                ],
                                "vids": [
                                    "faqs/videos/q_and_a/68.webm"
                                ],
                                "imgs": []
                            }
                        ],
                        "procedures": [
                            {
                                "id": 96,
                                "title": "خطوة رقم 1",
                                "desc": "طلب من المنتفع بالتعديل المطلوب",
                                "sound": [
                                    "procedures/sounds/desc/96.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/96.webm"
                                ],
                                "imgs": [
                                    "procedures/images/96.png"
                                ]
                            },
                            {
                                "id": 97,
                                "title": "خطوة رقم 2",
                                "desc": "مراجعة الملف",
                                "sound": [
                                    "procedures/sounds/desc/97.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/97.webm"
                                ],
                                "imgs": [
                                    "procedures/images/97.jpg"
                                ]
                            },
                            {
                                "id": 98,
                                "title": "خطوة رقم 3",
                                "desc": "الفترة الزمنية من طلب الخدمة حتي الوصول إليها فورا",
                                "sound": [
                                    "procedures/sounds/desc/98.mp3"
                                ],
                                "vids": [
                                    "procedures/videos/desc/98.webm"
                                ],
                                "imgs": [
                                    "procedures/images/98.jpg"
                                ]
                            }
                        ],
                        "regulations": []
                    },
                    {
                        "id": 28,
                        "title": "تلقي الشكاوي والبلاغات",
                        "has_subservice": 1,
                        "desc": "<p>يتم تلقي الشكاوي الواردة عبر قنوات التواصل وإحالتها إلكترونيا إلي الجهات المختصة ومتابعة الرد عليها</p>",
                        "sound": [
                            "services/sounds/desc/28.mp3"
                        ],
                        "vids": [
                            "services/videos/desc/28.webm"
                        ],
                        "imgs": [
                            "services/images/28.jpg"
                        ],
                        "sub_sub_services": [
                            {
                                "id": 29,
                                "title": "تلقي الشكاوي عن طريق الخط الساخن",
                                "has_subservice": 0,
                                "desc": "<p>تقديم شكوي من خلال الخط الساخن 121</p>",
                                "sound": [
                                    "services/sounds/desc/29.mp3"
                                ],
                                "vids": [
                                    "services/videos/desc/29.webm"
                                ],
                                "imgs": [
                                    "services/images/29.jpg"
                                ],
                                "sub_sub_services": [],
                                "docs": [
                                    {
                                        "id": 68,
                                        "title": "بيانات الحساب",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/68.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/68.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/68.png"
                                        ]
                                    }
                                ],
                                "faqs": [],
                                "procedures": [
                                    {
                                        "id": 99,
                                        "title": "خطوة رقم 1",
                                        "desc": "الاتصال بالخط الساخن 121",
                                        "sound": [
                                            "procedures/sounds/desc/99.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/99.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/99.jpg"
                                        ]
                                    },
                                    {
                                        "id": 100,
                                        "title": "خطوة رقم 2",
                                        "desc": "يتم استقبال شكاوي المشتركين من انقطاعات وجودة التغذية الكهربائية او الشكاوي التجارية علي مدار اليوم  24/7  من خلال الاتصال علي الرقم الموحد علي مستوي الجمهورية",
                                        "sound": [
                                            "procedures/sounds/desc/100.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/100.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/100.jpg"
                                        ]
                                    }
                                ],
                                "regulations": []
                            },
                            {
                                "id": 30,
                                "title": "تلقي الشكاوي عن طريق تطبيق المحمول",
                                "has_subservice": 0,
                                "desc": "<p>تقديم شكوي من خلال تطبيق المحمول</p>",
                                "sound": [
                                    "services/sounds/desc/30.mp3"
                                ],
                                "vids": [
                                    "services/videos/desc/30.webm"
                                ],
                                "imgs": [
                                    "services/images/30.jpg"
                                ],
                                "sub_sub_services": [],
                                "docs": [
                                    {
                                        "id": 69,
                                        "title": "بيانات الحساب",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/69.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/69.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/69.png"
                                        ]
                                    }
                                ],
                                "faqs": [],
                                "procedures": [
                                    {
                                        "id": 101,
                                        "title": "خطوة رقم 1",
                                        "desc": "تحميل تطبيق بإسم شكاوي فواتير الكهرباء من Google Play Store أو App Store",
                                        "sound": [
                                            "procedures/sounds/desc/101.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/101.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/101.jpg"
                                        ]
                                    },
                                    {
                                        "id": 102,
                                        "title": "خطوة رقم 2",
                                        "desc": "اختيار الجهه  شركة النقل أو التوزيع  من واقع فاتورة الكهرباء حتي يتسني الرد علي الشكوي بسرعه",
                                        "sound": [
                                            "procedures/sounds/desc/102.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/102.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/102.jpg"
                                        ]
                                    },
                                    {
                                        "id": 103,
                                        "title": "خطوة رقم 3",
                                        "desc": "إدخال رقم الموبايل الذي سيتم التواصل من خلاله مع المواطن",
                                        "sound": [
                                            "procedures/sounds/desc/103.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/103.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/103.jpg"
                                        ]
                                    },
                                    {
                                        "id": 104,
                                        "title": "خطوة رقم 4",
                                        "desc": "تصوير الفاتورة التي يشتكي منها المواطن من خلال كاميرا الموبايل",
                                        "sound": [
                                            "procedures/sounds/desc/104.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/104.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/104.jpg"
                                        ]
                                    },
                                    {
                                        "id": 105,
                                        "title": "خطوة رقم 5",
                                        "desc": "تحميل صورة الفاتورة - إضغط علي زر تحميل الفاتورة لتحميلها علي التطبيق",
                                        "sound": [
                                            "procedures/sounds/desc/105.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/105.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/105.jpg"
                                        ]
                                    },
                                    {
                                        "id": 106,
                                        "title": "خطوة رقم 6",
                                        "desc": "تحميل صورة العداد  أختياري  يتم تحميل صورة عداد الكهرباء أو الأستمرار بدون تحميل.<br>",
                                        "sound": [
                                            "procedures/sounds/desc/106.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/106.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/106.jpg"
                                        ]
                                    },
                                    {
                                        "id": 107,
                                        "title": "خطوة رقم 7",
                                        "desc": "تم استلام الشكوي - ستظهر رسالة باستلام الشكوي وجاري العمل علي حلها",
                                        "sound": [
                                            "procedures/sounds/desc/107.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/107.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/107.jpg"
                                        ]
                                    },
                                    {
                                        "id": 108,
                                        "title": "خطوة رقم 8",
                                        "desc": "سيتم الاتصال بمقدم الشكوي واستكمال الشكوي والرد عليه",
                                        "sound": [
                                            "procedures/sounds/desc/108.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/108.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/108.jpg"
                                        ]
                                    }
                                ],
                                "regulations": []
                            },
                            {
                                "id": 31,
                                "title": "تلقي الشكاوي عن طريق الرسائل القصيرة",
                                "has_subservice": 0,
                                "desc": "<p>تقديم شكوي من خلال الرسائل النصية</p>",
                                "sound": [
                                    "services/sounds/desc/31.mp3"
                                ],
                                "vids": [
                                    "services/videos/desc/31.webm"
                                ],
                                "imgs": [
                                    "services/images/31.jpg"
                                ],
                                "sub_sub_services": [],
                                "docs": [
                                    {
                                        "id": 70,
                                        "title": "بيانات الحساب",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/70.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/70.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/70.png"
                                        ]
                                    },
                                    {
                                        "id": 71,
                                        "title": "رقم السداد الألكتروني",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/71.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/71.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/71.png"
                                        ]
                                    }
                                ],
                                "faqs": [],
                                "procedures": [
                                    {
                                        "id": 109,
                                        "title": "خطوة رقم 1",
                                        "desc": "إرسال رسالة نصية إلي رقم 91121",
                                        "sound": [
                                            "procedures/sounds/desc/109.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/109.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/109.jpg"
                                        ]
                                    },
                                    {
                                        "id": 110,
                                        "title": "خطوة رقم 2",
                                        "desc": "سيتم استقبال رسالة بأنه تم استقبال الشكوي وجاري حلها",
                                        "sound": [
                                            "procedures/sounds/desc/110.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/110.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/110.jpg"
                                        ]
                                    },
                                    {
                                        "id": 111,
                                        "title": "خطوة رقم 3",
                                        "desc": "في حالة وصول الرسالة بدون رقم السداد الألكتروني ستستلم رسالة لتصحيح تنسيق الرسالة",
                                        "sound": [
                                            "procedures/sounds/desc/111.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/111.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/111.jpg"
                                        ]
                                    },
                                    {
                                        "id": 112,
                                        "title": "خطوة رقم 4",
                                        "desc": "سيتم استكمال بيانات الشكوي للرد عليك",
                                        "sound": [
                                            "procedures/sounds/desc/112.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/112.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/112.jpg"
                                        ]
                                    }
                                ],
                                "regulations": []
                            },
                            {
                                "id": 32,
                                "title": "تلقي الشكاوي عن طريق الموقع الألكتروني",
                                "has_subservice": 0,
                                "desc": "<p>تقديم شكوي من خلال الموقع الألكتروني</p>",
                                "sound": [
                                    "services/sounds/desc/32.mp3"
                                ],
                                "vids": [
                                    "services/videos/desc/32.webm"
                                ],
                                "imgs": [
                                    "services/images/32.jpg"
                                ],
                                "sub_sub_services": [],
                                "docs": [
                                    {
                                        "id": 72,
                                        "title": "بيانات الحساب",
                                        "desc": null,
                                        "sound": [
                                            "documents/sounds/title/72.mp3"
                                        ],
                                        "vids": [
                                            "documents/videos/title/72.webm"
                                        ],
                                        "imgs": [
                                            "documents/images/72.png"
                                        ]
                                    }
                                ],
                                "faqs": [],
                                "procedures": [
                                    {
                                        "id": 113,
                                        "title": "خطوة رقم 1",
                                        "desc": "تسجيل شكوي علي الموقع مع تحديد نوع الشكوي والجهه المستقبلة للشكوي",
                                        "sound": [
                                            "procedures/sounds/desc/113.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/113.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/113.jpg"
                                        ]
                                    },
                                    {
                                        "id": 114,
                                        "title": "خطوة رقم 2",
                                        "desc": "سيتم مراجعة الشكوي والتأكد من صحة الجهه المختصه ومراجعة تصنيف نوع الشكوي",
                                        "sound": [
                                            "procedures/sounds/desc/114.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/114.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/114.jpg"
                                        ]
                                    },
                                    {
                                        "id": 115,
                                        "title": "خطوة رقم 3",
                                        "desc": "سيتم الرد علي الشكوي من خلال إتخاذ الأجراء المناسب لها",
                                        "sound": [
                                            "procedures/sounds/desc/115.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/115.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/115.jpg"
                                        ]
                                    },
                                    {
                                        "id": 116,
                                        "title": "خطوة رقم 4",
                                        "desc": "يمكنك معرفة الرد من خلال البحث بالرقم وكود الشكوي",
                                        "sound": [
                                            "procedures/sounds/desc/116.mp3"
                                        ],
                                        "vids": [
                                            "procedures/videos/desc/116.webm"
                                        ],
                                        "imgs": [
                                            "procedures/images/116.jpg"
                                        ]
                                    }
                                ],
                                "regulations": []
                            }
                        ],
                        "docs": [],
                        "faqs": [],
                        "procedures": [],
                        "regulations": []
                    }
                ]
            }
        ],
        "branches_contacts": [
            {
                "id": 826,
                "gov": "القاهرة",
                "branch": "السلام",
                "description": null,
                "note": null,
                "address": "مساكن الصعيد بجوار مدرسة BBC وتخدم منطقة السلام",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "222809449",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/1.mp3"
                ]
            },
            {
                "id": 827,
                "gov": "القاهرة",
                "branch": "العباسية والظاهر",
                "description": null,
                "note": null,
                "address": "1 ميدان الظاهر أمام مسجد الظاهر بيبرس  وتخدم منطقة العباسية والظاهر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "225898904",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/2.mp3"
                ]
            },
            {
                "id": 828,
                "gov": "القاهرة",
                "branch": "المرج وعزبة النخل",
                "description": null,
                "note": null,
                "address": "أمام مستشفى جراحة اليوم الواحد بالمرج  وتخدم منطقة المرج وعزبة النخل وقباء",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "228702825",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/3.mp3"
                ]
            },
            {
                "id": 829,
                "gov": "القاهرة",
                "branch": "النهض",
                "description": null,
                "note": null,
                "address": "بلوك 6 شارع سوق السنترال أمام النقطة القديمة  وتخدم منطقة النهضة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "226570609",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/4.mp3"
                ]
            },
            {
                "id": 830,
                "gov": "القاهرة",
                "branch": "حلمية الزيتون",
                "description": null,
                "note": null,
                "address": "22ش ابن الحكم - بجوار نادي 6 أكتوبر  وتخدم منطقة الزيتون وعين شمس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "222401943",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/5.mp3"
                ]
            },
            {
                "id": 831,
                "gov": "القاهرة",
                "branch": "المطرية",
                "description": null,
                "note": null,
                "address": "22ش ابن الحكم - بجوار نادي 6 أكتوبر  وتخدم منطقة المطرية وحدائق القبة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "226433925",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/6.mp3"
                ]
            },
            {
                "id": 832,
                "gov": "القاهرة",
                "branch": "روض الفرج",
                "description": null,
                "note": null,
                "address": "كورنيش النيل - أسفل كوبري الساحل - روض الفرج  وتخدم منطقة روض الفرج",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "224589476",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/7.mp3"
                ]
            },
            {
                "id": 833,
                "gov": "القاهرة",
                "branch": "الشرابية",
                "description": null,
                "note": null,
                "address": "كورنيش النيل - أسفل كوبري الساحل - روض الفرج  وتخدم منطقة الزاوية الحمراء",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "224587713",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/8.mp3"
                ]
            },
            {
                "id": 834,
                "gov": "القاهرة",
                "branch": "شبرا مصر",
                "description": null,
                "note": null,
                "address": "كورنيش النيل - أسفل كوبري الساحل - روض الفرج  وتخدم منطقة شبرا مصر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "224579190",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/9.mp3"
                ]
            },
            {
                "id": 835,
                "gov": "القاهرة",
                "branch": "مدينة نصر شرق",
                "description": null,
                "note": null,
                "address": " 2طريق النصر بجوار قسم أول مدينة نصر  وتخدم منطقة حي شرق مدينة نصر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "226716362",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/10.mp3"
                ]
            },
            {
                "id": 836,
                "gov": "القاهرة",
                "branch": "مدينة نصر غرب",
                "description": null,
                "note": null,
                "address": " 2طريق النصر بجوار قسم أول مدينة نصر  وتخدم منطقة حي غرب مدينة نصر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "226716362",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/11.mp3"
                ]
            },
            {
                "id": 837,
                "gov": "القاهرة",
                "branch": "شروق مدينة نصر",
                "description": null,
                "note": null,
                "address": " 2طريق النصر بجوار قسم أول مدينة نصر  وتخدم منطقة حي شرق مدينة نصر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "222875937",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/12.mp3"
                ]
            },
            {
                "id": 838,
                "gov": "القاهرة",
                "branch": "مصر الجديدة والنزهة",
                "description": null,
                "note": null,
                "address": "31شارع نبيل الوقاد - مصر الجديدة  وتخدم منطقة مصر الجديددة والنزهة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "226907685",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/13.mp3"
                ]
            },
            {
                "id": 839,
                "gov": "القاهرة",
                "branch": "جمعية أحمد عرابي",
                "description": null,
                "note": null,
                "address": "جمعية أحمد عرابي وتخدم منطقة جمعية أحمد عرابي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "224699311",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/14.mp3"
                ]
            },
            {
                "id": 840,
                "gov": "القاهرة",
                "branch": "كبار المشتركين",
                "description": null,
                "note": null,
                "address": " 2ش النصر بجوار قسم أول مدينة نصر وتخدم منطقة كبار المشتركين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "222747453",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/15.mp3"
                ]
            },
            {
                "id": 841,
                "gov": "القاهرة",
                "branch": "البساتين (1)",
                "description": null,
                "note": null,
                "address": "شر البساتين العمومي خلف مساكن الكلحة وتخدم منطقة عرب المعادي وفايدة كامل وأرض البصري ,السد العالي ومساكن أطلس ومقابر اليهود",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "227037937",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/16.mp3"
                ]
            },
            {
                "id": 842,
                "gov": "القاهرة",
                "branch": "البساتين (2)",
                "description": null,
                "note": null,
                "address": "شر البساتين العمومي خلف مساكن الكلحة وتخدم منطقة عزبة الخيرالله وبئر أم سلطان وعزبة الطحاوي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "227037937",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/17.mp3"
                ]
            },
            {
                "id": 843,
                "gov": "القاهرة",
                "branch": "السيدة زينب",
                "description": null,
                "note": null,
                "address": "8ش علي حسن السيدة زينب وتخدم منقطة المنيل وجاردن سيتي والقصر العيني والسيدة زنب والفسطاط ومساكن زينهم والمدبح",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "223630225",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/18.mp3"
                ]
            },
            {
                "id": 844,
                "gov": "القاهرة",
                "branch": "القلعة",
                "description": null,
                "note": null,
                "address": "ميدان صلاح الدين أمام القلعة وتخدم منطقة الجمالية والدرب الأحمر والأمام الشافعي والإمام الليثي ومنشية ناصر والدويقة والحلمية ودرب سعادة وشارع الأزهر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "225117002",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/19.mp3"
                ]
            },
            {
                "id": 845,
                "gov": "القاهرة",
                "branch": "المعادي (1)",
                "description": null,
                "note": null,
                "address": "3ش وادي النيل المعادي وتخدم منقطة كورنيش المعادي وحدائق المعادي والمعصرة وكوتسيكا وطرة وطرة الأسمنت",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "227513329",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/20.mp3"
                ]
            },
            {
                "id": 846,
                "gov": "القاهرة",
                "branch": "المعادي (2)",
                "description": null,
                "note": null,
                "address": "3ش وادي النيل المعادي وتخدم منطقة سرايات المعادي وزهراء المعادي وجلة والمعراج ودار السلام",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "223585398",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/21.mp3"
                ]
            },
            {
                "id": 847,
                "gov": "القاهرة",
                "branch": "المطعم (أ)",
                "description": null,
                "note": null,
                "address": "16مساكن الجزيرة بالهضبة الوطيى وتخدم منطقة مساكن الإيواء وتحيا مصر والاسمرات ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "228450362",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/22.mp3"
                ]
            },
            {
                "id": 848,
                "gov": "القاهرة",
                "branch": "المعطم (ب)",
                "description": null,
                "note": null,
                "address": " 16مساكن الجيزيرة بالهضبة الوسطى وتخدم منطقة ال 70 فدان وأرض المباحث وكومباوند النخيل والبارون وسما ومعادي جاردن عباد الرحمنة ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "228450237",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/23.mp3"
                ]
            },
            {
                "id": 849,
                "gov": "القاهرة",
                "branch": "حلوان",
                "description": null,
                "note": null,
                "address": "ش أحمد أنس أمام مكتب بريد حلوان وتخدم منطقة حلوان",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "227070494",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/24.mp3"
                ]
            },
            {
                "id": 850,
                "gov": "القاهرة",
                "branch": "غرب القاهرة",
                "description": null,
                "note": null,
                "address": "60شارع السبتية - السبتية وتخدم منقطة وسط البلد والسبتية وعابدين والموسكي وباب الشعرية وبولاق والزمالك والعتبة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "227739023",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/25.mp3"
                ]
            },
            {
                "id": 851,
                "gov": "الجيزة",
                "branch": "الجيزة",
                "description": null,
                "note": null,
                "address": "3شارع استوديو الأهرام وتخدمة منطقة الجيزة وشارع البحر الأعظم وشارع ربيع الجيزي ويمين شارع الهرم حتى الطالبية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "235868265",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/26.mp3"
                ]
            },
            {
                "id": 852,
                "gov": "الجيزة",
                "branch": "العمرانية (1)",
                "description": null,
                "note": null,
                "address": "3شارع استوديو الأهرام وتخدم منطقة يسار شارع الهرم حتى الطالبية والعمرانية الشرقية والعمرانية الغربية يمين شارع مستشفى الصدر وخاتم المرسلين والثلاثيني",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "235868265",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/27.mp3"
                ]
            },
            {
                "id": 853,
                "gov": "الجيزة",
                "branch": "العمرانية (2)",
                "description": null,
                "note": null,
                "address": "3شارع استوديو الأهرام وتخدم منطقة العمرانية الغربية يسار شارع مستشفى الصدر وزهراء العمرانية وشارع الطكتور محمد فؤاد سعيد وجسر الكنيسة وشارع المدبح والمنيب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "235868265",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/28.mp3"
                ]
            },
            {
                "id": 854,
                "gov": "الجيزة",
                "branch": "الطالبية (1)",
                "description": null,
                "note": null,
                "address": "3شارع استوديو الأهرام وتخدم منطقة الطالبية وفكيهة والأندلس والكوم الأخضر والعروبة والثلاثيني الجديد وعز الدين عمر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "235868265",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/29.mp3"
                ]
            },
            {
                "id": 855,
                "gov": "الجيزة",
                "branch": "الطالبية (2)",
                "description": null,
                "note": null,
                "address": "3شارع استوديو الأهرام وتخدم منطقة الطالبية وكفر الجبل وشبرامنت والحرانية وزاوية أبو مسلم ونزلة السيسي والمنصورية والمريوطية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "235852088",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/30.mp3"
                ]
            },
            {
                "id": 856,
                "gov": "الجيزة",
                "branch": "نصر الدين",
                "description": null,
                "note": null,
                "address": "3شارع استوديو الأهرام وتخدم منطقة أول الطريق الصحراوي ويمين شارع الهرم من الطالبية وحدائق الأهرام ومساكن الرماية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "235852088",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/31.mp3"
                ]
            },
            {
                "id": 857,
                "gov": "الجيزة",
                "branch": "الدقي",
                "description": null,
                "note": null,
                "address": "شارع نوال بالعجوزة وتخدم منطقة الدقي والعجوزة وبين السريات",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "233365472",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/32.mp3"
                ]
            },
            {
                "id": 858,
                "gov": "الجيزة",
                "branch": "المهندسين ",
                "description": null,
                "note": null,
                "address": "شارع نوال بالعجوزة وتخدم منطقة المهندسين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "233358063",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/33.mp3"
                ]
            },
            {
                "id": 859,
                "gov": "الجيزة",
                "branch": "امبابة",
                "description": null,
                "note": null,
                "address": "شارع نوال بالعجوزة وتخدم منطقة  امبابة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "233358063",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/34.mp3"
                ]
            },
            {
                "id": 860,
                "gov": "الجيزة",
                "branch": "الوراق (1)",
                "description": null,
                "note": null,
                "address": "شارع كورنيش النيل أمام قسم الوراق وتخدم منطقة طناش وسقيل من الكورنيش الي مصنع الكراسي ومن إدارة الوراق إلى أرض الجمعية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "235408814",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/35.mp3"
                ]
            },
            {
                "id": 861,
                "gov": "الجيزة",
                "branch": "الوراق (2)",
                "description": null,
                "note": null,
                "address": "شارع كورنيش النيل أمام قسم الوراق وتخدم منطقة القومية شمال الدائري إلى موقف وراق العرب وشارع السنترال ووراق العرب وكفر السليمانية وعزبة الخلايفة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "235453229",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/36.mp3"
                ]
            },
            {
                "id": 862,
                "gov": "الجيزة",
                "branch": "المنيرة الغربية",
                "description": null,
                "note": null,
                "address": "شارع بشتيل المحطة بجوار سكة حديد بشتيل وتخدم منطقة المنيرة الغربية والبصراوي وأرض الحداد وشارع المطار والإمام الغزالي وشار الأقصر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "233554557",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/37.mp3"
                ]
            },
            {
                "id": 863,
                "gov": "الجيزة",
                "branch": "بشتيل (1)",
                "description": null,
                "note": null,
                "address": "شارع بشتيل المحطة بجوار سكة حديد بشتيل وتخدم منطقة بشتيل القديمة والحديدة ومدينة الأمل وعزبة المفتي وعزبة المطار",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "233500737",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/38.mp3"
                ]
            },
            {
                "id": 864,
                "gov": "الجيزة",
                "branch": "بشتيل (2)",
                "description": null,
                "note": null,
                "address": "شارع بشتيل المحطة بجوار سكة حديد بشتيل وتخدم منطقة غرب السكة الحديد ولعبة وشارع الجمعية الزراعية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "233500767",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/39.mp3"
                ]
            },
            {
                "id": 865,
                "gov": "الجيزة",
                "branch": "بولاق (1)",
                "description": null,
                "note": null,
                "address": "أمام محطة مترو فيصل وتخدم منطقة زنين والرشاح والثلاجة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "233307086",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/40.mp3"
                ]
            },
            {
                "id": 866,
                "gov": "الجيزة",
                "branch": "بولاق (2)",
                "description": null,
                "note": null,
                "address": "أمام محطة مترو فيصل وتخدم منطقة ناهيا وهمفرس والطريق الأبيض",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "233307086",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/41.mp3"
                ]
            },
            {
                "id": 867,
                "gov": "الجيزة",
                "branch": "فيصل (1)",
                "description": null,
                "note": null,
                "address": "أمام محطة مترو فيصل وتخدم منطقة المطبعة والطوابق والمريوطية وعزبة جبريل",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "237343024",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/42.mp3"
                ]
            },
            {
                "id": 868,
                "gov": "الجيزة",
                "branch": "فيصل (2)",
                "description": null,
                "note": null,
                "address": "أمام محطة مترو فيصل وتخدم منطقة العشرين والملكة وحسن محمد وكفر طهرمس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "237343024",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/43.mp3"
                ]
            },
            {
                "id": 869,
                "gov": "الجيزة",
                "branch": "الصف",
                "description": null,
                "note": null,
                "address": "شارع الجيش أمام مساكن أبو بكر الصديق وتخدم منطقة الصف وعرب أبو ساعد والعطيات وكفر طرخان والأخصاص وغمازة كبري والمنيا والشرفا وعرب أبو عريضة وعرب الشيخ صالح",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238620883",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/44.mp3"
                ]
            },
            {
                "id": 870,
                "gov": "الجيزة",
                "branch": "العياط",
                "description": null,
                "note": null,
                "address": "ش شكري عمارة 9 شقة 1 بجوار محطة السكة الحديد ويخدم منطقة العياط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238600113",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/45.mp3"
                ]
            },
            {
                "id": 871,
                "gov": "الجيزة",
                "branch": "المنصورية",
                "description": null,
                "note": null,
                "address": "شارع معهد الفتيات أمام مسجد الحسينية ويخدم منطقة المنصورية وبرقاش ومساكن نكله وقرية عبد الصمد وصليبه وعزبة العقباوي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238724445",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/46.mp3"
                ]
            },
            {
                "id": 872,
                "gov": "الجيزة",
                "branch": "الواحات",
                "description": null,
                "note": null,
                "address": "الباويطي البرني عمارة 1 مدخل 1 وتخدم منطقة الواحات البحرة والحاره ومنديشه والزبو والباويطي والقصر والعجوز",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238472318",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/47.mp3"
                ]
            },
            {
                "id": 873,
                "gov": "الجيزة",
                "branch": "أطفيح",
                "description": null,
                "note": null,
                "address": "الطريق الرئيسي بجوار مركز شركة أطيح من القبلي وخدم منطقة أطفيح والقبابات وكفر الوصلين وعزبة المصرية ومنيل السلطان والصالحية ومنشية الرقة وكفر قنديل والبرومبل والكريمات ودير الميمون ومسجد موسى",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238410356",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/48.mp3"
                ]
            },
            {
                "id": 874,
                "gov": "الجيزة",
                "branch": "أوسيم (1)",
                "description": null,
                "note": null,
                "address": "شارع القاضي بجوار مدرسة الفصل الواحد أوسيم وتخدم منطقة أوسيم والقيراطين وبرطس والزيدية والزاوية والأبعدية وشنباري والكوم الأحمر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238703115",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/49.mp3"
                ]
            },
            {
                "id": 875,
                "gov": "الجيزة",
                "branch": "أوسيم (2)",
                "description": null,
                "note": null,
                "address": "شارع القاضي بجوار مدرسة الفصل الواحد أوسيم وتخدم منطقة أرض اللواء يمين المحور والبراجيل وعزبة خيزة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238703115",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/50.mp3"
                ]
            },
            {
                "id": 876,
                "gov": "الجيزة",
                "branch": "كرداسة",
                "description": null,
                "note": null,
                "address": "شارع سعد زغلول بجوار موع كهرباء السلخانة وتخدم منطقة كرداسة بضواحيها وأبو روش بضواحيها وكفر غطااطي وبني مجدول وكفر أبو حميدة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "237980373",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/51.mp3"
                ]
            },
            {
                "id": 877,
                "gov": "الجيزة",
                "branch": "منشاة القناطر",
                "description": null,
                "note": null,
                "address": "بجوار قسم شرطة منشأة القناطروتخدم منطقة منشأة القناطر والجلاتنه ومناشي البلد وجرزاية ونكل والأخصاص وبهرمس وذات الكوم وأم دينار والرهاوي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238940260",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/52.mp3"
                ]
            },
            {
                "id": 878,
                "gov": "الجيزة",
                "branch": "وردان",
                "description": null,
                "note": null,
                "address": "بجوار التأمين الصحي وردان وتخدم منطقة وردان والقطة وأبو غالب والحاجر وأتريس وكفر أبو الحديد وحدود نكلة والقطة حتى حدود الخطاطية بحيرة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238760824",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/53.mp3"
                ]
            },
            {
                "id": 879,
                "gov": "الأسكندرية",
                "branch": "البياطاش",
                "description": null,
                "note": null,
                "address": "شارع البيطاش الرئيسي  وتخدم منطقة البيطاش",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "33085919",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/54.mp3"
                ]
            },
            {
                "id": 880,
                "gov": "الأسكندرية",
                "branch": "بيانكى",
                "description": null,
                "note": null,
                "address": "نهاية شارع الحنفية بجوار بيانكى 480 وتخدم منطقة  بيانكى",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34042360",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/55.mp3"
                ]
            },
            {
                "id": 881,
                "gov": "الأسكندرية",
                "branch": "الساحل الشمالي",
                "description": null,
                "note": null,
                "address": "مساكن 21 الكيلو 21 بعد مكتب البريد وتخدم منطقة الساحل الشمالي من الكيلو 21 للكيلو 40",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "33026950",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/56.mp3"
                ]
            },
            {
                "id": 882,
                "gov": "الأسكندرية",
                "branch": "برج العرب القديم",
                "description": null,
                "note": null,
                "address": "برج العرب القديم أمام المجلس المحلي وتخدم منطقة مركز ومدينة برج العرب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34650360",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/57.mp3"
                ]
            },
            {
                "id": 883,
                "gov": "الأسكندرية",
                "branch": "الحمام",
                "description": null,
                "note": null,
                "address": "مدينة الحمام أمام قسم شركة الحمام وتخدم منطقة  الحمام",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464752563",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/58.mp3"
                ]
            },
            {
                "id": 884,
                "gov": "الأسكندرية",
                "branch": "الهانوفيل",
                "description": null,
                "note": null,
                "address": "طريق اسكندرية مطروح الهانوفيل أمام فتح الله جملة ماركت وتخدم منطقة الهانوفيل",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34382171",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/59.mp3"
                ]
            },
            {
                "id": 885,
                "gov": "الأسكندرية",
                "branch": "خورشيد البحيرة",
                "description": null,
                "note": null,
                "address": "عمارة الحاج فاروق الزين الزوايدة خورشيد وتخدم منطقة  الزوايدة وخورشيد والمراغي وعزبة كردون ومحسن والمهاجرين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "351818654",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/60.mp3"
                ]
            },
            {
                "id": 886,
                "gov": "الأسكندرية",
                "branch": "خورشيد القبلية",
                "description": null,
                "note": null,
                "address": "تقاطع ش القاهرة مع ش الفضالي بجوار مسجد الفضالي وتخدم منطقة الفلكي والراس السوداء والمنشية البحرية واسكود وحوض 10 والرنس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "35308695",
                "tel2": "35308696",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/61.mp3"
                ]
            },
            {
                "id": 887,
                "gov": "الأسكندرية",
                "branch": "أبو قير",
                "description": null,
                "note": null,
                "address": "نهاية شارع بورسعيد أمام الميناء البحري وتخدم منطقة  أبو قير",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "35623158",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/62.mp3"
                ]
            },
            {
                "id": 888,
                "gov": "الأسكندرية",
                "branch": "سيدي بشر",
                "description": null,
                "note": null,
                "address": "تقاطع شارع مسجد سيدي بشر مع العيسوي وتخدم منطقة سيدي بشر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "35710457",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/63.mp3"
                ]
            },
            {
                "id": 889,
                "gov": "الأسكندرية",
                "branch": " المندرة",
                "description": null,
                "note": null,
                "address": "عمارة 40 مساكن مدينة فيص سيدي بشر وتخدم منطقة المندرة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "35332148",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/64.mp3"
                ]
            },
            {
                "id": 890,
                "gov": "الأسكندرية",
                "branch": "الإبراهيمية",
                "description": null,
                "note": null,
                "address": "1شارع عبد المنعم سند وتخدم منطقة  الابراهمية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "35930579",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/65.mp3"
                ]
            },
            {
                "id": 891,
                "gov": "الأسكندرية",
                "branch": "النصر",
                "description": null,
                "note": null,
                "address": "14شارع النصر الجمرك أمام الضرائب وتخدمة منطقة  النصر شمال قصر رأس التين غرب منشية اللبان ومينا البصل شرق كرموز",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34806453",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/66.mp3"
                ]
            },
            {
                "id": 892,
                "gov": "الأسكندرية",
                "branch": "محرم بك",
                "description": null,
                "note": null,
                "address": "99شارع محرم بك أمام محطة زين العابدين الرصافة وتخدم منطقة محرم بك",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "33926358",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/67.mp3"
                ]
            },
            {
                "id": 893,
                "gov": "الأسكندرية",
                "branch": "وسط المدينة",
                "description": null,
                "note": null,
                "address": "9شارع سيدي المتولي العطارين وتخدم منطقة ش السبع بنات وش عامود السواري امتداد مدينة العرائس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34966930",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/68.mp3"
                ]
            },
            {
                "id": 894,
                "gov": "الأسكندرية",
                "branch": "سموحة",
                "description": null,
                "note": null,
                "address": "شارع ادمون فريمون سموحة وتخدم منطقة  سموحة من كوبري الابراهيمة لترعة المحمودية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34274369",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/69.mp3"
                ]
            },
            {
                "id": 895,
                "gov": "الأسكندرية",
                "branch": "أبيس",
                "description": null,
                "note": null,
                "address": "سموحة خلف الشهر العقاري وتخدم منطقة  أبيس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34298873",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/70.mp3"
                ]
            },
            {
                "id": 896,
                "gov": "الأسكندرية",
                "branch": "باكوس",
                "description": null,
                "note": null,
                "address": "تقاطع ش 20 مع ش محطة السوق أعلى أستوديو كرنفال وتخدم منطقة باكوس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "35015604",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/71.mp3"
                ]
            },
            {
                "id": 897,
                "gov": "الأسكندرية",
                "branch": "السيوف",
                "description": null,
                "note": null,
                "address": "عمارة 10 غرناطة شارع أديب معقد السيوف وتخدم منطقة السوف من كوبري العوايد لمنطقة الساعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "33306694",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/72.mp3"
                ]
            },
            {
                "id": 898,
                "gov": "الأسكندرية",
                "branch": "سابا باشا",
                "description": null,
                "note": null,
                "address": "9شارع محمد صالح أبو يوسف أمام قسم الرمل أول وتخدم منطقة سابا باشا وكفر عبدة ولوران وزيزنيا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "35854688",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/73.mp3"
                ]
            },
            {
                "id": 899,
                "gov": "الأسكندرية",
                "branch": "الجلاء",
                "description": null,
                "note": null,
                "address": "عمارة 86 مساكن مدينة فيصل وسيدي بشر وتخدم منطقة الجلاء",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "35370031",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/74.mp3"
                ]
            },
            {
                "id": 900,
                "gov": "الأسكندرية",
                "branch": "الدخيلة",
                "description": null,
                "note": null,
                "address": "الدخيلة بحري طرييق مطروح خلف المحكمة وتخدم منطقة الدخيلة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "32202328",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/75.mp3"
                ]
            },
            {
                "id": 901,
                "gov": "الأسكندرية",
                "branch": "العامرية",
                "description": null,
                "note": null,
                "address": "شارع قسم العامرية أمام  القسم وتخدم منطقة العامرية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34480068",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/76.mp3"
                ]
            },
            {
                "id": 902,
                "gov": "الأسكندرية",
                "branch": "القبارى",
                "description": null,
                "note": null,
                "address": "شارع السلطان شاة على الترام القباري وتخدم منطقة منطقة القباري وكفر عشري والمكس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34404211",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/77.mp3"
                ]
            },
            {
                "id": 903,
                "gov": "الأسكندرية",
                "branch": "مرغم",
                "description": null,
                "note": null,
                "address": "الكيلو 24.5 طريق السريع أمام شركة العامرية للأدوية وتخدم منطقة مرغم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34700323",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/78.mp3"
                ]
            },
            {
                "id": 904,
                "gov": "القليوبية",
                "branch": "الخانكة",
                "description": null,
                "note": null,
                "address": "الخانكة بجوار مستشفى الأمراض النفسية وتخدم منطقة مدينة الخانكة والقلج",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "244685590",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/79.mp3"
                ]
            },
            {
                "id": 905,
                "gov": "القليوبية",
                "branch": "الخصوص",
                "description": null,
                "note": null,
                "address": "مساكن الأمل بجوار نادي المساعيد وتخدم منطقةالخصوص",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "229254657",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/80.mp3"
                ]
            },
            {
                "id": 906,
                "gov": "القليوبية",
                "branch": "العبور",
                "description": null,
                "note": null,
                "address": "الحي الثامن بجوار المرور وتخدم منطقة العبور",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "244798160",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/81.mp3"
                ]
            },
            {
                "id": 907,
                "gov": "القليوبية",
                "branch": "القناطر الخيرة",
                "description": null,
                "note": null,
                "address": "التقسيم السياحي بجوار مدرسة تجارة بنات وتخدم منطقة القناطر الخيرية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "242188673",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/82.mp3"
                ]
            },
            {
                "id": 908,
                "gov": "القليوبية",
                "branch": "بهتيم",
                "description": null,
                "note": null,
                "address": "نهاية شارع 135 أمام عزبة إبراهيم بك شرا الخية وتخدم منطقة بهتيم ومنشية الحرية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "246042206",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/83.mp3"
                ]
            },
            {
                "id": 909,
                "gov": "القليوبية",
                "branch": "شبرا الخيمة",
                "description": null,
                "note": null,
                "address": "أسفل كوبري عرابي شبرا الخية وتخدم منطقة شبرا الخيمة وبيجام",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "246131450",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/84.mp3"
                ]
            },
            {
                "id": 910,
                "gov": "القليوبية",
                "branch": "قرى الخانكة",
                "description": null,
                "note": null,
                "address": "أبو زعبل البلد بجوار الوحدة المحلية وتخدم منطقة قرى الخانكة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "244674646",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/85.mp3"
                ]
            },
            {
                "id": 911,
                "gov": "القليوبية",
                "branch": "شبين القناطر",
                "description": null,
                "note": null,
                "address": "شارع وابور النور بجوار كوبري عبد العال وتخدم منطقة شبين القناطر والقرى  والعزب التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": null,
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/86.mp3"
                ]
            },
            {
                "id": 912,
                "gov": "القليوبية",
                "branch": "طوخ",
                "description": null,
                "note": null,
                "address": "أول شارع مصرف الحصة كوبري الحدادين وتخدم منطقة  مركز طوخ والقرى والعزب التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": null,
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/87.mp3"
                ]
            },
            {
                "id": 913,
                "gov": "القليوبية",
                "branch": "قها",
                "description": null,
                "note": null,
                "address": "شارع بورسعيد بجوار محطجة محولات قها 66 وتخدم منطقة  مدينة قها والقرى والعزب التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": null,
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/88.mp3"
                ]
            },
            {
                "id": 914,
                "gov": "القليوبية",
                "branch": "كفر شكر",
                "description": null,
                "note": null,
                "address": "شارع طراد النيل وتخدم منطقة  مدينة كفر شكر والقرى والعزب التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": null,
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/89.mp3"
                ]
            },
            {
                "id": 915,
                "gov": "القليوبية",
                "branch": "مدينة بنها ",
                "description": null,
                "note": null,
                "address": "طريق الرملة أمام مشتل مجلس المدينة وتخدم منطقة  مدينة بنها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": null,
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/90.mp3"
                ]
            },
            {
                "id": 916,
                "gov": "القليوبية",
                "branch": "مركز بنها",
                "description": null,
                "note": null,
                "address": "طريق الرملة أمام مشتل مجلس المدينة وتخدم منطقة  مدينة قليوب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": null,
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/91.mp3"
                ]
            },
            {
                "id": 917,
                "gov": "القليوبية",
                "branch": "قليوب",
                "description": null,
                "note": null,
                "address": "أول شارع سيدي عواض بجوار مجلس المدينة وتخدم منطقة  مدينة قليوب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": null,
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/92.mp3"
                ]
            },
            {
                "id": 918,
                "gov": "القليوبية",
                "branch": "مركز قليوب",
                "description": null,
                "note": null,
                "address": "أول شارع سيدي عواض بجوار مجلس المدينة وتخدم منطقة  قرى وعزب مركز قليوب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": null,
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/93.mp3"
                ]
            },
            {
                "id": 919,
                "gov": "سوهاج",
                "branch": "العسيرات",
                "description": null,
                "note": null,
                "address": "أولاد حمزة مساكن طوخ بجار بنك التنمية وتخدم منطقة  قرى العسيرات",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "934931200",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/94.mp3"
                ]
            },
            {
                "id": 920,
                "gov": "سوهاج",
                "branch": "مدينة المراغة",
                "description": null,
                "note": null,
                "address": "النزلة طريق أسيوط سوهاج وتخدم منطقة  المراغة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "932530420",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/95.mp3"
                ]
            },
            {
                "id": 921,
                "gov": "سوهاج",
                "branch": "المنشأة",
                "description": null,
                "note": null,
                "address": "شارع سيف النصر بجوار مدرسة الثانوية الجديدة وتخدم منطقة  المنشأة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "932184427",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/96.mp3"
                ]
            },
            {
                "id": 922,
                "gov": "سوهاج",
                "branch": "أخميم",
                "description": null,
                "note": null,
                "address": "شارع الفردوس ميدان است عزيزة وتخدم منطقة  قرى اخميم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "932580196",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/97.mp3"
                ]
            },
            {
                "id": 923,
                "gov": "سوهاج",
                "branch": "شمال البلينا",
                "description": null,
                "note": null,
                "address": "شارع عبد المولى الفاوية وتخدم منطقة  قرى شمال البلينا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "934800847",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/98.mp3"
                ]
            },
            {
                "id": 924,
                "gov": "سوهاج",
                "branch": "جنوب البلينا",
                "description": null,
                "note": null,
                "address": "شارع عبد المولى الفاوية وتخدم منطقة  قرى جنوب البلينا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "934806655",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/99.mp3"
                ]
            },
            {
                "id": 925,
                "gov": "سوهاج",
                "branch": "جهينة",
                "description": null,
                "note": null,
                "address": "شارع الجمهورية قبلي مركة الشركة وتخدم منطقة قرى جهينة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "934703350",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/100.mp3"
                ]
            },
            {
                "id": 926,
                "gov": "سوهاج",
                "branch": "دار السلام",
                "description": null,
                "note": null,
                "address": "بجوار مركز شرطة دار السلام وتخدم منطقة قرى جهينة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "934910582",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/101.mp3"
                ]
            },
            {
                "id": 927,
                "gov": "سوهاج",
                "branch": "ساقلته ",
                "description": null,
                "note": null,
                "address": "شارع الشبكة وتخدم منطقة مدينة ساقلته",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "932511616",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/102.mp3"
                ]
            },
            {
                "id": 928,
                "gov": "سوهاج",
                "branch": "طما",
                "description": null,
                "note": null,
                "address": "شارع أحمد عرابي طريق أسيوط سوهاج وتخدم منطقة مدينة طما",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "932797679",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/103.mp3"
                ]
            },
            {
                "id": 929,
                "gov": "سوهاج",
                "branch": "مدينة جرجا",
                "description": null,
                "note": null,
                "address": "شارع بركات خلف البوستة وتخدم منطقة مدينة جرجا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "934676776",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/104.mp3"
                ]
            },
            {
                "id": 930,
                "gov": "سوهاج",
                "branch": "مركز جرجا ",
                "description": null,
                "note": null,
                "address": "شارع بركات خلف البوستة وتخدم منطقة قرى جرجا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "934654641",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/105.mp3"
                ]
            },
            {
                "id": 931,
                "gov": "سوهاج",
                "branch": "مدينة سوهاج شرق",
                "description": null,
                "note": null,
                "address": "شارع الخبز الآلي بجوار مديرية الأوقاف وتخدم منطقة  شرق سوهاج",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "932345763",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/106.mp3"
                ]
            },
            {
                "id": 932,
                "gov": "سوهاج",
                "branch": "مدينة سوهاج غرب",
                "description": null,
                "note": null,
                "address": "شارع المخبز الآلي بجوار مديرية الأوقاف وتخدم منطقة  غرب سوهاج",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "932359918",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/107.mp3"
                ]
            },
            {
                "id": 933,
                "gov": "سوهاج",
                "branch": "مركز سوهاج جنوب",
                "description": null,
                "note": null,
                "address": "شارع الجرجاوية الغربي بجوار مضرب الأرز وتخدم منطقة  قرى جنوب سوهاج",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "932156230",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/108.mp3"
                ]
            },
            {
                "id": 934,
                "gov": "سوهاج",
                "branch": "مركز سوهاج شمال",
                "description": null,
                "note": null,
                "address": "شارع الجرجاوية الغربي بجوار مضرب الأرز وتخدم منطقة  قرى شمال سوهاج",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "932156639",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/109.mp3"
                ]
            },
            {
                "id": 935,
                "gov": "سوهاج",
                "branch": "مدينة طهطا",
                "description": null,
                "note": null,
                "address": "شارع صلاح سالم وتخدم منطقة مدينة طهطا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "934770487",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/110.mp3"
                ]
            },
            {
                "id": 936,
                "gov": "سوهاج",
                "branch": "مركز طهطا",
                "description": null,
                "note": null,
                "address": "شارع صلاح سالم وتخدم منطقة  قرى طهطا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "934768602",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/111.mp3"
                ]
            },
            {
                "id": 937,
                "gov": "كفر الشيخ",
                "branch": "الحامول مدينة",
                "description": null,
                "note": null,
                "address": "الحامول شارع مبارك بجوار السجل المدني وتخدم منطقة  مدينة الحامول",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "473800379",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/112.mp3"
                ]
            },
            {
                "id": 938,
                "gov": "كفر الشيخ",
                "branch": "الرياض",
                "description": null,
                "note": null,
                "address": "الرياض شرع الترعة بجوار إدارة الشباب والرياضة وتخدم منطقة  مدينة الرياض",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "473860863",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/113.mp3"
                ]
            },
            {
                "id": 939,
                "gov": "كفر الشيخ",
                "branch": "بلطيم",
                "description": null,
                "note": null,
                "address": "بطيم شارع المستشفى ناحية طريق البرج وتخدم منطقة  مدينة بلطيم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "472510475",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/114.mp3"
                ]
            },
            {
                "id": 940,
                "gov": "كفر الشيخ",
                "branch": "بيلا",
                "description": null,
                "note": null,
                "address": "بيلا شارع الثورة بجوار المركز الطبي وتخدم منطقة  مدينة بيلا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "473605110",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/115.mp3"
                ]
            },
            {
                "id": 941,
                "gov": "كفر الشيخ",
                "branch": "سيدي سالم قرى",
                "description": null,
                "note": null,
                "address": "سيدي سالم العبايدة بجوار المعهد الديني وتخدم منطقة  قرى سيدي سالم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "472700982",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/116.mp3"
                ]
            },
            {
                "id": 942,
                "gov": "كفر الشيخ",
                "branch": "فوة",
                "description": null,
                "note": null,
                "address": "فوة شارع البحر وتخدم منطقة  مدينة فوة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "472976886",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/117.mp3"
                ]
            },
            {
                "id": 943,
                "gov": "كفر الشيخ",
                "branch": "كفر الشيخ مدينة",
                "description": null,
                "note": null,
                "address": "كفر الشيخ شارع المحكمة بجوار مجلس مدينة كفر الشيخ وتخدم منطقة  مدينة كفر الشيخ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "473232993",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/118.mp3"
                ]
            },
            {
                "id": 944,
                "gov": "كفر الشيخ",
                "branch": "الحامول قرى",
                "description": null,
                "note": null,
                "address": "الحامول شارع مبارك بجوار السجل المدني وتخدم منطقة قرى الحامول",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "473800755",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/119.mp3"
                ]
            },
            {
                "id": 945,
                "gov": "كفر الشيخ",
                "branch": "الكراكات",
                "description": null,
                "note": null,
                "address": "طريق كفر الشيخ الحامول بجوار طريق عزبة يوسف وتخدم منطقة مدينة بيلا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": null,
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/120.mp3"
                ]
            },
            {
                "id": 946,
                "gov": "كفر الشيخ",
                "branch": "برج البرلس",
                "description": null,
                "note": null,
                "address": "الطريق الدولي كفر الشيخ بلطيم برج البرلس وتخدم منطقة  مدينة برج البرلس وقرى بر بحري",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "472496663",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/121.mp3"
                ]
            },
            {
                "id": 947,
                "gov": "كفر الشيخ",
                "branch": "دسوق قرى جنوب",
                "description": null,
                "note": null,
                "address": "دسوق شارع سيدي إبراهيم الدسوقي بجوار محطة المياة وتخدم منطقة قرى جنوب دسوق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "472568839",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/122.mp3"
                ]
            },
            {
                "id": 948,
                "gov": "كفر الشيخ",
                "branch": "دسوق قرى شمال",
                "description": null,
                "note": null,
                "address": "دسوق شارع سيدي إبراهيم الدسوقي بجوار محطة المياة وتخدم منطقة قرى شمال دسوق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "472551509",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/123.mp3"
                ]
            },
            {
                "id": 949,
                "gov": "كفر الشيخ",
                "branch": "دسوق مدينة",
                "description": null,
                "note": null,
                "address": "دسوق شارع سيدي إبراهيم الدسوقي بجوار محطة المياة وتخدم منطقة مدينة دسوق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "472562278",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/124.mp3"
                ]
            },
            {
                "id": 950,
                "gov": "كفر الشيخ",
                "branch": "سيدي سالم مدينة",
                "description": null,
                "note": null,
                "address": "سيدي سالم شارع السادات وتخدم منطقة  مدينة سيدي سالم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "472700796",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/125.mp3"
                ]
            },
            {
                "id": 951,
                "gov": "كفر الشيخ",
                "branch": "قلين",
                "description": null,
                "note": null,
                "address": "قلين شارع جمال عبد الناصر وتخدم منطقة مدينة قلين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "473400841",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/126.mp3"
                ]
            },
            {
                "id": 952,
                "gov": "كفر الشيخ",
                "branch": "كفر الشيخ قرى شرق",
                "description": null,
                "note": null,
                "address": "سخا بجوار دار مناسبات سخا وتخدم منطقة  شرق مدينة كفر الشيخ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "473234605",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/127.mp3"
                ]
            },
            {
                "id": 953,
                "gov": "كفر الشيخ",
                "branch": "كفر الشيخ قرى غرب",
                "description": null,
                "note": null,
                "address": "المدينة التجارية عمارات الأوقاف وتخدم منطقة غرب مدينة كفر الشيخ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "473234833",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/128.mp3"
                ]
            },
            {
                "id": 954,
                "gov": "كفر الشيخ",
                "branch": "مطوبس",
                "description": null,
                "note": null,
                "address": "مطوبس عمارات بنك الإسكان بجوار مركز شرطة سندوب وتخدم منطقة  مدينة مطوبس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "472711932",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/129.mp3"
                ]
            },
            {
                "id": 955,
                "gov": "المنوفية",
                "branch": "الباجور",
                "description": null,
                "note": null,
                "address": "شارع السوق الكبير أمام شرطة الباجور وتخدم منطقة مدينة الباجور",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "483884117",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/130.mp3"
                ]
            },
            {
                "id": 956,
                "gov": "المنوفية",
                "branch": "الشهداء",
                "description": null,
                "note": null,
                "address": "شارع بور سعيد بجوار المستشفى العام وتخدم منطقة مدينة الشهداء",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "482750583",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/131.mp3"
                ]
            },
            {
                "id": 957,
                "gov": "المنوفية",
                "branch": "بركة السبع",
                "description": null,
                "note": null,
                "address": "بركة السبع غرب بجوار وحدة مرور بركة السبع وتخدم منطقة مدينة بركة السبع",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "482993151",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/132.mp3"
                ]
            },
            {
                "id": 958,
                "gov": "المنوفية",
                "branch": "تلا",
                "description": null,
                "note": null,
                "address": "شارع التربية البتاانونية وتخدم منطقة مدينة تلا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "483792371",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/133.mp3"
                ]
            },
            {
                "id": 959,
                "gov": "المنوفية",
                "branch": "سرس الليان",
                "description": null,
                "note": null,
                "address": "شارع ميدان سيدي سعيد بجوار مدرسة النصر وتخدم منطقة مدينة سرس الليان",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "483351521",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/134.mp3"
                ]
            },
            {
                "id": 960,
                "gov": "المنوفية",
                "branch": "قويسنا شرق",
                "description": null,
                "note": null,
                "address": "شارع شرف الدين وتخدم منطقة مدينة قويسنا شرق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "482573031",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/135.mp3"
                ]
            },
            {
                "id": 961,
                "gov": "المنوفية",
                "branch": "قويسنا غرب",
                "description": null,
                "note": null,
                "address": "شارع شرف الدين وتخدم منطقة مدينة قويسنا غرب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "482573582",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/136.mp3"
                ]
            },
            {
                "id": 962,
                "gov": "المنوفية",
                "branch": "أشمون",
                "description": null,
                "note": null,
                "address": "بجوار مسجد عمر بن عبد العزيز وتخدم منطقة مدينة أشمون",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "483443775",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/137.mp3"
                ]
            },
            {
                "id": 963,
                "gov": "المنوفية",
                "branch": "شبين الكو",
                "description": null,
                "note": null,
                "address": "شارع وابور النور بجوار السكة الحديد وتخدم منطقة مدينة شبين الكوم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "482327359",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/138.mp3"
                ]
            },
            {
                "id": 964,
                "gov": "المنوفية",
                "branch": "مركز أشمون",
                "description": null,
                "note": null,
                "address": "بجوار مسجد عمر بن عبد العزيز وتخدم منطقة قرى مركز أشمون",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "483443185",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/139.mp3"
                ]
            },
            {
                "id": 965,
                "gov": "المنوفية",
                "branch": "مركز شبين الكوم",
                "description": null,
                "note": null,
                "address": "شارع وأبور النور بجوار السكة الحديد وتخدم منطقة قرى مركز شبين الكوم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "482222268",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/140.mp3"
                ]
            },
            {
                "id": 966,
                "gov": "المنوفية",
                "branch": "منوف",
                "description": null,
                "note": null,
                "address": "شارع مصطفى كامل بجوار مسجد الأشعتي وتخدم منطقة مدينة منوف",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "483660405",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/141.mp3"
                ]
            },
            {
                "id": 967,
                "gov": "اسوان",
                "branch": "أدفو",
                "description": null,
                "note": null,
                "address": "شارع 23 يوليو وتخدم منطقة مركز أدفو",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "974711047",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/142.mp3"
                ]
            },
            {
                "id": 968,
                "gov": "اسوان",
                "branch": "أسوان جنوب",
                "description": null,
                "note": null,
                "address": "أسوان بجوار مسجد الطابية وتخدم منطقة قرى جنوب أسوان",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "972458109",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/143.mp3"
                ]
            },
            {
                "id": 969,
                "gov": "اسوان",
                "branch": "أسوان شرق",
                "description": null,
                "note": null,
                "address": "أسوان السيل الجديد بجوار الوحدة المحلية وتخدم منطقة قرى شرق أسوان",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "972205044",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/144.mp3"
                ]
            },
            {
                "id": 970,
                "gov": "اسوان",
                "branch": "أسوان شمال",
                "description": null,
                "note": null,
                "address": "أسوان بجوار مبنى المخابرات وتخدم منطقة قرى شمال أسون",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "972467461",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/145.mp3"
                ]
            },
            {
                "id": 971,
                "gov": "اسوان",
                "branch": "أبو سمبل السياحية",
                "description": null,
                "note": null,
                "address": "أسوان شارع أبو سمبل وتخدم منطقة مركز أبو سمبل",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "973400260",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/146.mp3"
                ]
            },
            {
                "id": 972,
                "gov": "اسوان",
                "branch": "دراو",
                "description": null,
                "note": null,
                "address": "طريق مصر أسوان وتخدم منطقة مركز دراو",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "974730467",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/147.mp3"
                ]
            },
            {
                "id": 973,
                "gov": "اسوان",
                "branch": "كوم امبو",
                "description": null,
                "note": null,
                "address": "شارع بور سعيد بجوار مبنى الأوقاف وتخدم منطقة مركز كوم امبو",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "973621544",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/148.mp3"
                ]
            },
            {
                "id": 974,
                "gov": "اسوان",
                "branch": "نصر النوبة",
                "description": null,
                "note": null,
                "address": "شارع السوق التجاري وتخدم منطقة مركز نصر النوبة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "972853266",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/149.mp3"
                ]
            },
            {
                "id": 975,
                "gov": "جنوب سيناء",
                "branch": "قطاع شبكات جنوب سيناء",
                "description": null,
                "note": null,
                "address": "الديوان العام الطور وتخدم منطقة جنوب سيناء المركز الرئيسي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "693771449",
                "tel2": "693771146",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/150.mp3"
                ]
            },
            {
                "id": 976,
                "gov": "جنوب سيناء",
                "branch": "هندسة أبورديس",
                "description": null,
                "note": null,
                "address": "أبورديس خلف سنترال ابورديس وتخدم منطقةأبورديس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "693440151",
                "tel2": "693441697",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/151.mp3"
                ]
            },
            {
                "id": 977,
                "gov": "جنوب سيناء",
                "branch": "هندسة دهب",
                "description": null,
                "note": null,
                "address": "دهب وسط المدينة وتخدم منطقة دهب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "693640280",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/152.mp3"
                ]
            },
            {
                "id": 978,
                "gov": "جنوب سيناء",
                "branch": "هندسة رأس سدر",
                "description": null,
                "note": null,
                "address": "رأس سدر خلف مستشفى رأس سدر العام وتخدم منطقةرأس سدر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "693400274",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/153.mp3"
                ]
            },
            {
                "id": 979,
                "gov": "جنوب سيناء",
                "branch": "هندسة شرم الشيخ",
                "description": null,
                "note": null,
                "address": "شرم الشيخ أمام قرية دلتا شرم وتخدم منطقة شرم الشيخ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "693661027",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/154.mp3"
                ]
            },
            {
                "id": 980,
                "gov": "جنوب سيناء",
                "branch": "هندسة طابا",
                "description": null,
                "note": null,
                "address": "جنبو سيناء طابا وتخدم منطقة طابا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "693530225",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/155.mp3"
                ]
            },
            {
                "id": 981,
                "gov": "جنوب سيناء",
                "branch": "هندسة طور سيناء",
                "description": null,
                "note": null,
                "address": "طور سيناء مساكن اللوتس خلف مجلس المدينة وتخدم منطقةطور سيناء",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "693770248",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/156.mp3"
                ]
            },
            {
                "id": 982,
                "gov": "جنوب سيناء",
                "branch": "هندسة كاترين",
                "description": null,
                "note": null,
                "address": "سانت كاترين وسط المدينة وتخدم منطقة كاترين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "693470375",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/157.mp3"
                ]
            },
            {
                "id": 983,
                "gov": "جنوب سيناء",
                "branch": "هندسة نوبيع",
                "description": null,
                "note": null,
                "address": "نوبيع بجوار فندق هلنان نوبيع وتخدم منطقة نوبيع",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "693500258",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/158.mp3"
                ]
            },
            {
                "id": 984,
                "gov": "بورسعيد",
                "branch": "قطاع شبكات بوريسعيد",
                "description": null,
                "note": null,
                "address": "شارع محمد علي بورسعيد 100 وتخدم منطقة بورسعيد المركز الرئيسي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "663341798",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/159.mp3"
                ]
            },
            {
                "id": 985,
                "gov": "بورسعيد",
                "branch": "هندسة بورسعيد",
                "description": null,
                "note": null,
                "address": "شارع أوجينيه بجوار صيدلية الأسعاف وتخدم منطقة بورسعيد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "663220735",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/160.mp3"
                ]
            },
            {
                "id": 986,
                "gov": "بورسعيد",
                "branch": "هندسة الجنوب والضواحي",
                "description": null,
                "note": null,
                "address": "الجنوب زرزارة منطقة A20 بجوار مساكن شباب الخرجيين وتخدم منطقة الجنوب والضواحي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "663723723",
                "tel2": "663237205",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/161.mp3"
                ]
            },
            {
                "id": 987,
                "gov": "بورسعيد",
                "branch": "هندسة الزهور",
                "description": null,
                "note": null,
                "address": "الزهور م.عثمان بن عفان امتداد شارع عادل الشربيني وتخدم منطقة الزهور",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "663601090",
                "tel2": "663683090",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/162.mp3"
                ]
            },
            {
                "id": 988,
                "gov": "بورسعيد",
                "branch": "هندسة المناخ",
                "description": null,
                "note": null,
                "address": "حي المناخ شارع النصر منطقة اللنش القديم وتخدم منطقة المناخ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "663334083",
                "tel2": "663219083",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/163.mp3"
                ]
            },
            {
                "id": 989,
                "gov": "بورسعيد",
                "branch": "هندسة بورفوؤاد",
                "description": null,
                "note": null,
                "address": "شارع 10 رئيسي خلف كلية  الهندسة ببور فؤاد وتخدم منطقة بورفؤاد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "663400369",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/164.mp3"
                ]
            },
            {
                "id": 990,
                "gov": "الوادي الجديد",
                "branch": "الخارجة",
                "description": null,
                "note": null,
                "address": "مركز الخارجة وتخدم منطقة قرى الخارجة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "9222933631",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/165.mp3"
                ]
            },
            {
                "id": 991,
                "gov": "الوادي الجديد",
                "branch": "الداخلة",
                "description": null,
                "note": null,
                "address": "مركة الداخلة وتخدم منطقة قرى الداخلة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "9222820433",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/166.mp3"
                ]
            },
            {
                "id": 992,
                "gov": "الوادي الجديد",
                "branch": "العوينات",
                "description": null,
                "note": null,
                "address": "العوينات وتخدم منطقة قرى العوينات",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "9222932085",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/167.mp3"
                ]
            },
            {
                "id": 993,
                "gov": "الوادي الجديد",
                "branch": "باريس",
                "description": null,
                "note": null,
                "address": "مركز الخارجة قرة باريس وتخدم منطقة قرى باريس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "9222975036",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/168.mp3"
                ]
            },
            {
                "id": 994,
                "gov": "الوادي الجديد",
                "branch": "بلاط",
                "description": null,
                "note": null,
                "address": "مركز الداخلة قرية بلاط وتخدم منطقة قرى بلاط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "9222703184",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/169.mp3"
                ]
            },
            {
                "id": 995,
                "gov": "الوادي الجديد",
                "branch": "الفرافره",
                "description": null,
                "note": null,
                "address": "مركز وقرية الفرافره وتخدم منطقة قرى الفرافره",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "9222528688",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/170.mp3"
                ]
            },
            {
                "id": 996,
                "gov": "الإسماعلية",
                "branch": "قطاع شبكات الإسماعيلية",
                "description": null,
                "note": null,
                "address": "مجمع المصالح الحكومية خلف نقابة المهندسين وتخدم منطقة الإسماعيلية المركز الرئيسي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643228520",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/171.mp3"
                ]
            },
            {
                "id": 997,
                "gov": "الإسماعلية",
                "branch": "هندسة الإسماعيلية أول",
                "description": null,
                "note": null,
                "address": "مدينة التل الكبير المحطة الجديدة ش محطة الانارة وتخدم منطقة الإسماعيلية أول",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643911448",
                "tel2": "643505448",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/172.mp3"
                ]
            },
            {
                "id": 998,
                "gov": "الإسماعلية",
                "branch": "هندسة الإسماعيلية ثاني",
                "description": null,
                "note": null,
                "address": "عرايشية مصر ش البحري بجوار حي ثان وتخدم منطقة الإسماعيلية ثاني",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "6433317610",
                "tel2": "643104098",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/173.mp3"
                ]
            },
            {
                "id": 999,
                "gov": "الإسماعلية",
                "branch": "هندسة أبو صوير",
                "description": null,
                "note": null,
                "address": "مدينة ابوصوير نجيب محفوظ طريق أبو خروع 81 وتخدم منطقةابوصوير",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643470139",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/174.mp3"
                ]
            },
            {
                "id": 1000,
                "gov": "الإسماعلية",
                "branch": " هندسة أبو عطوة",
                "description": null,
                "note": null,
                "address": "أمام مصنع الترانزستور وتخدم منطقة أبو عطوة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643451667",
                "tel2": "643938075",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/175.mp3"
                ]
            },
            {
                "id": 1001,
                "gov": "الإسماعلية",
                "branch": "هندسة التل الكبير",
                "description": null,
                "note": null,
                "address": "مدينة التل الكبير بجوار المستشفى المركزي وتخدم منطقة التل الكبير",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643961995",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/176.mp3"
                ]
            },
            {
                "id": 1002,
                "gov": "الإسماعلية",
                "branch": "هندسة الشيخ زايد",
                "description": null,
                "note": null,
                "address": "طريق التمليك بجوار مستشفى علي خليل وتخدم منطقة الشيخ زايد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "6432115310",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/177.mp3"
                ]
            },
            {
                "id": 1003,
                "gov": "الإسماعلية",
                "branch": "هندسة الفردان",
                "description": null,
                "note": null,
                "address": "ك 11 طريق معدية افردان",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643850018",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/178.mp3"
                ]
            },
            {
                "id": 1004,
                "gov": "الإسماعلية",
                "branch": "هندسة القصاصين",
                "description": null,
                "note": null,
                "address": "مدينة القصاصين بجوار مركز الأسعاف وتخدم منطقة القصاصين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "6434401200",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/179.mp3"
                ]
            },
            {
                "id": 1005,
                "gov": "الإسماعلية",
                "branch": "هندسة القنطرة غرب",
                "description": null,
                "note": null,
                "address": "مدينة القنطرة غرب منطقة السوق التجاري وتخدم منطقة القنطرة غرب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643561343",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/180.mp3"
                ]
            },
            {
                "id": 1006,
                "gov": "الإسماعلية",
                "branch": "هندسة القنطرة شرق",
                "description": null,
                "note": null,
                "address": "مدينة القنطرة شرق 21ش مدرسة العبور وتخدم منطقة القنطرة شرق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643750585",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/181.mp3"
                ]
            },
            {
                "id": 1007,
                "gov": "الإسماعلية",
                "branch": "هندسة المستقبل",
                "description": null,
                "note": null,
                "address": "مدينة المستقبل وتخدم منطقة المستقبل",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643482030",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/182.mp3"
                ]
            },
            {
                "id": 1008,
                "gov": "الإسماعلية",
                "branch": "هندسة الملاك",
                "description": null,
                "note": null,
                "address": "طريق الملاك من التل الكبير وتخدم منطقة الملاك",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "649200181",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/183.mp3"
                ]
            },
            {
                "id": 1009,
                "gov": "الإسماعلية",
                "branch": "هندسة شرق البحيرات",
                "description": null,
                "note": null,
                "address": "معدية سرابيوم بجوار مركز الإنذار الموجه وتخدم منطقة شرق البحيرات",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643270231",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/184.mp3"
                ]
            },
            {
                "id": 1010,
                "gov": "الإسماعلية",
                "branch": "هندسة فايد",
                "description": null,
                "note": null,
                "address": "41ش المعاهدة بجوار مجلس المدينة وتخدم منطقة فايد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "643661443",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/185.mp3"
                ]
            },
            {
                "id": 1011,
                "gov": "البحيرة",
                "branch": "بنجر السكر",
                "description": null,
                "note": null,
                "address": "بنجر السكرر وتخدم منطقة بنجر السكر والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "33921759",
                "tel2": "39571293",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/186.mp3"
                ]
            },
            {
                "id": 1012,
                "gov": "البحيرة",
                "branch": "البستان",
                "description": null,
                "note": null,
                "address": "البستان وتخدم منطقة على ابن طالب والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452663139",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/187.mp3"
                ]
            },
            {
                "id": 1013,
                "gov": "البحيرة",
                "branch": "التحدي",
                "description": null,
                "note": null,
                "address": "التحدي وتخدم منطقة التحدي والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "453750113",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/188.mp3"
                ]
            },
            {
                "id": 1014,
                "gov": "البحيرة",
                "branch": "التحرير بدر",
                "description": null,
                "note": null,
                "address": "التحرير بدر وتخدم منطقة التحرير بدر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "453621801",
                "tel2": "453620430",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/189.mp3"
                ]
            },
            {
                "id": 1015,
                "gov": "البحيرة",
                "branch": "الدلنجات",
                "description": null,
                "note": null,
                "address": "الدلنجات وتخدم منطقة الدلنجات والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "453607633",
                "tel2": "453600358",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/190.mp3"
                ]
            },
            {
                "id": 1016,
                "gov": "البحيرة",
                "branch": "الدواجن",
                "description": null,
                "note": null,
                "address": "الدواجن وتخدم منطقة الدواجن والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452315476",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/191.mp3"
                ]
            },
            {
                "id": 1017,
                "gov": "البحيرة",
                "branch": "الرحمانية",
                "description": null,
                "note": null,
                "address": "الرحمانية وتخدم منطقة الرحمانية والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452854520",
                "tel2": "452856477",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/192.mp3"
                ]
            },
            {
                "id": 1018,
                "gov": "البحيرة",
                "branch": "الصفا والمروة",
                "description": null,
                "note": null,
                "address": "الصفا والمروة وتخدم منطقة الإمام مالك والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452632214",
                "tel2": "452632215",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/193.mp3"
                ]
            },
            {
                "id": 1019,
                "gov": "البحيرة",
                "branch": "المحمودية",
                "description": null,
                "note": null,
                "address": "المحمودية وتخدم منطقة المحمودية والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452502031",
                "tel2": "452500326",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/194.mp3"
                ]
            },
            {
                "id": 1020,
                "gov": "البحيرة",
                "branch": "النصر 3",
                "description": null,
                "note": null,
                "address": "النصر 3 وتخدم منطقة النصر 3 وحسن علام",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452350845",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/195.mp3"
                ]
            },
            {
                "id": 1021,
                "gov": "البحيرة",
                "branch": "إدفينا",
                "description": null,
                "note": null,
                "address": "إدفينا وتخدم منطقة إدفينا والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452961992",
                "tel2": "452960466",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/196.mp3"
                ]
            },
            {
                "id": 1022,
                "gov": "البحيرة",
                "branch": "إدكو",
                "description": null,
                "note": null,
                "address": "إدكو وتخدم منطقة إدكو والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452916775",
                "tel2": "452910377",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/197.mp3"
                ]
            },
            {
                "id": 1023,
                "gov": "البحيرة",
                "branch": "إيتاي البارود",
                "description": null,
                "note": null,
                "address": "إيتاي البارود وتخدم منطقة إيتاي البارود والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "453388945",
                "tel2": "453388736",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/198.mp3"
                ]
            },
            {
                "id": 1024,
                "gov": "البحيرة",
                "branch": "أبو المطامير",
                "description": null,
                "note": null,
                "address": "أبو المطامير وتخدم منطقة أبو المطامير والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452405700",
                "tel2": "452400148",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/199.mp3"
                ]
            },
            {
                "id": 1025,
                "gov": "البحيرة",
                "branch": "أبو بكر",
                "description": null,
                "note": null,
                "address": "أبو بكر وتخدم منطقة أبو بكر والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452632214",
                "tel2": "459155146",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/200.mp3"
                ]
            },
            {
                "id": 1026,
                "gov": "البحيرة",
                "branch": "أبو حمص شرق",
                "description": null,
                "note": null,
                "address": "أبو حمص شرق وتخدم منطقة بسنتواى والنخلة وشرق أبو حمص",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452565001",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/201.mp3"
                ]
            },
            {
                "id": 1027,
                "gov": "البحيرة",
                "branch": "أبو حمص غرب",
                "description": null,
                "note": null,
                "address": "أبو حمص غرب وتخدم منطقة بلقتر وجواد حسني وغرب أبو حمص",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452560102",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/202.mp3"
                ]
            },
            {
                "id": 1028,
                "gov": "البحيرة",
                "branch": "أحمد بدوي",
                "description": null,
                "note": null,
                "address": "أحمد بدوي وتخدم منطقة أحمد بدوي وأدم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452432215",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/203.mp3"
                ]
            },
            {
                "id": 1029,
                "gov": "البحيرة",
                "branch": "بندر دمنهور شرق",
                "description": null,
                "note": null,
                "address": "بندر دمنهور شرق وتخدم منطقة أبو الريش والساعة ودمنهور الجديدة وعزبة سعد بحري ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "453318046",
                "tel2": "453312902",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/204.mp3"
                ]
            },
            {
                "id": 1030,
                "gov": "البحيرة",
                "branch": "بندر دمنهور غرب",
                "description": null,
                "note": null,
                "address": "بندر دمنهور غرب وتخدم منطقة شبرا وأرض ادمون والدفراوي والسريع وعزبة شعير",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "453344604",
                "tel2": "453358536",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/205.mp3"
                ]
            },
            {
                "id": 1031,
                "gov": "البحيرة",
                "branch": "بندر كفر الدوار شرق",
                "description": null,
                "note": null,
                "address": "بندر كفر الدوار شرق وتخدم منطقة شرق كفر الدوار وانطونيادس والسناهرة والحدائق والعكريشة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452213351",
                "tel2": "452220977",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/206.mp3"
                ]
            },
            {
                "id": 1032,
                "gov": "البحيرة",
                "branch": "بندر كفر الدوار غرب",
                "description": null,
                "note": null,
                "address": "بندر كفر الدوار غرب وتخدم منطقة غرب كفر الدوار والسريع وكفر الدوار القديم البلد والزرقة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452213317",
                "tel2": "452212013",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/207.mp3"
                ]
            },
            {
                "id": 1033,
                "gov": "البحيرة",
                "branch": "حوش عيسى",
                "description": null,
                "note": null,
                "address": "حوش عيسى وتخدم منطقة حوش عيسى والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452710054",
                "tel2": "452710617",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/208.mp3"
                ]
            },
            {
                "id": 1034,
                "gov": "البحيرة",
                "branch": "رشيد",
                "description": null,
                "note": null,
                "address": "رشيد وتخدم منطقةرشيد والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452921155",
                "tel2": "452921999",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/209.mp3"
                ]
            },
            {
                "id": 1035,
                "gov": "البحيرة",
                "branch": "سيدي غازي",
                "description": null,
                "note": null,
                "address": "سدي غازي وتخدم منطقة شيدي غازي والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452594501",
                "tel2": "452594989",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/210.mp3"
                ]
            },
            {
                "id": 1036,
                "gov": "البحيرة",
                "branch": "شبراخيت",
                "description": null,
                "note": null,
                "address": "شراخيت وتخدم منطقة شبراخيت والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "453800176",
                "tel2": "453804868",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/211.mp3"
                ]
            },
            {
                "id": 1037,
                "gov": "البحيرة",
                "branch": "شمال التحرير",
                "description": null,
                "note": null,
                "address": "شمال التحرير وتخدم منطقة الناصر وفلسطين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452360637",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/212.mp3"
                ]
            },
            {
                "id": 1038,
                "gov": "البحيرة",
                "branch": "غرب النوبارية",
                "description": null,
                "note": null,
                "address": "غرب النوبارية وتخدم منطقة العشرة الاف والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452370561",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/213.mp3"
                ]
            },
            {
                "id": 1039,
                "gov": "البحيرة",
                "branch": "كفر داود",
                "description": null,
                "note": null,
                "address": "كفر داود وتخدم منطقة كفر داوود والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "482698015",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/214.mp3"
                ]
            },
            {
                "id": 1040,
                "gov": "البحيرة",
                "branch": "كوم حمادة",
                "description": null,
                "note": null,
                "address": "كوم حمادة وتخدم منطقة كوم حمادة والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "453680053",
                "tel2": "453680156",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/215.mp3"
                ]
            },
            {
                "id": 1041,
                "gov": "البحيرة",
                "branch": "مركز دمنهور",
                "description": null,
                "note": null,
                "address": "مركز دمنهور وتخدم منطقةالقرى التابعة لمركز دمنهور",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "453335188",
                "tel2": "453305823",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/216.mp3"
                ]
            },
            {
                "id": 1042,
                "gov": "البحيرة",
                "branch": "مركز كفر الدوار",
                "description": null,
                "note": null,
                "address": "مركز كفر الدوار وتخدم منطقة القرى التابعة لمركز كفر الدوار",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452174033",
                "tel2": "452174034",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/217.mp3"
                ]
            },
            {
                "id": 1043,
                "gov": "البحيرة",
                "branch": "مريوط",
                "description": null,
                "note": null,
                "address": "مريوط وتخدم منطقة الناصرية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34514134",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/218.mp3"
                ]
            },
            {
                "id": 1044,
                "gov": "البحيرة",
                "branch": "وادي النطرون",
                "description": null,
                "note": null,
                "address": "وادي النطرون وتخدم منطقة وادي النطرون والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "453550019",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/219.mp3"
                ]
            },
            {
                "id": 1045,
                "gov": "الغربية",
                "branch": "السنطة",
                "description": null,
                "note": null,
                "address": "عزبة الحوشة خلف مستشفى السنطة الكبرى وتخدم منطقة مدينة السنطة والقرى التابعة لها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "404470098",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/220.mp3"
                ]
            },
            {
                "id": 1046,
                "gov": "الغربية",
                "branch": "أول المحلة",
                "description": null,
                "note": null,
                "address": "وابور النور ش طريق محطة زفتى وتخدم منطقة مدينة المحلة أول",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "402224616",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/221.mp3"
                ]
            },
            {
                "id": 1047,
                "gov": "الغربية",
                "branch": "أول طنطا",
                "description": null,
                "note": null,
                "address": "شارع البحر أمام الري وتخدم منطقة مدينة طنطا أول",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "403333977",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/222.mp3"
                ]
            },
            {
                "id": 1048,
                "gov": "الغربية",
                "branch": "بسيون",
                "description": null,
                "note": null,
                "address": "شارع 23 يوليو بجوار مدرسة الصنايع وتخدم منطقةمدينة بسيون والقرى التابعة لها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "402731217",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/223.mp3"
                ]
            },
            {
                "id": 1049,
                "gov": "الغربية",
                "branch": "بشبيش",
                "description": null,
                "note": null,
                "address": "بشبيش مركز المحلة الكبرى وتخدم منطقة القرى التابعة لقرية بشبيش بالمحلة الكبرى",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "4020250066",
                "tel2": "4020232230",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/224.mp3"
                ]
            },
            {
                "id": 1050,
                "gov": "الغربية",
                "branch": "ثاني المحلة",
                "description": null,
                "note": null,
                "address": "وابور النور ش طريق محطة زفتى وتخدم منطقة مدينة زفتى والقرى التابعة لها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "402223260",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/225.mp3"
                ]
            },
            {
                "id": 1051,
                "gov": "الغربية",
                "branch": "ثاني طنطا",
                "description": null,
                "note": null,
                "address": "شارع الشهيد مصطفى أبو زهرة أمام شركة الزيوت وتخدم منطقة مدينة طنطا ثاني",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "403299451",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/226.mp3"
                ]
            },
            {
                "id": 1052,
                "gov": "الغربية",
                "branch": "زفتى",
                "description": null,
                "note": null,
                "address": "شارع كورنيش النيل طريق مصنع نسيج زفتى  وتخدم منطقة مدينة زفتى والقرى التابعة لها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "405710839",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/227.mp3"
                ]
            },
            {
                "id": 1053,
                "gov": "الغربية",
                "branch": "سمنود",
                "description": null,
                "note": null,
                "address": "وأبور النور ش ترعة الساحل وتخدم منطقة مدينة سمنود والقرى التابعة لها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "402970144",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/228.mp3"
                ]
            },
            {
                "id": 1054,
                "gov": "الغربية",
                "branch": "قطور",
                "description": null,
                "note": null,
                "address": "شارع عامر الدلتوني أمام المحكمة وتخدم منطقة مدينة قطور والقرى التابعة لها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "402760542",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/229.mp3"
                ]
            },
            {
                "id": 1055,
                "gov": "الغربية",
                "branch": "كفر الزيات",
                "description": null,
                "note": null,
                "address": "شارع جراهم أمام المستشفى القديم وتخدم منطقة مدينة كفر الزيات والقرى التابعة لها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "402548812",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/230.mp3"
                ]
            },
            {
                "id": 1056,
                "gov": "الغربية",
                "branch": "مركز المحلة",
                "description": null,
                "note": null,
                "address": "وابور النور ش طريق محطة زفتى وتخدم منطقة القرى التابعة لمدينة المحلة الكبرى",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "402214891",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/231.mp3"
                ]
            },
            {
                "id": 1057,
                "gov": "الغربية",
                "branch": "مركز طنطا",
                "description": null,
                "note": null,
                "address": "شارع الشهيد مصطفى أبو زهرة أمام شركة الزيوت وتخدم منطقة القرى التابعة لمدينة طنطا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "403304973",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/232.mp3"
                ]
            },
            {
                "id": 1058,
                "gov": "الشرقية",
                "branch": "قطاع شبكات شمال الشرقية",
                "description": null,
                "note": null,
                "address": "شارع النقراشي بجوار مدرسة صلاح سالم أبو كبير وتخدم منطقة شمال الشرقية المركز الرئيسي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553943121",
                "tel2": "553504792",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/233.mp3"
                ]
            },
            {
                "id": 1059,
                "gov": "الشرقية",
                "branch": "هندسة أبو كبير",
                "description": null,
                "note": null,
                "address": "أبوكبير شوق الشركة حي سوارس أبو كبير وتخدم منطقة أبوكبير",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553500196",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/234.mp3"
                ]
            },
            {
                "id": 1060,
                "gov": "الشرقية",
                "branch": "هندسة الحسينية",
                "description": null,
                "note": null,
                "address": "الحسينية شارع الشبكة منشأة شارة الحسينية وتخدم منطقة الحسينية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552778608",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/235.mp3"
                ]
            },
            {
                "id": 1061,
                "gov": "الشرقية",
                "branch": "هندسة الخطارة",
                "description": null,
                "note": null,
                "address": "شارع السيد حسين فاقوس وتخدم منطقة  الخطارة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553943121",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/236.mp3"
                ]
            },
            {
                "id": 1062,
                "gov": "الشرقية",
                "branch": "هندسة أولاد صقر",
                "description": null,
                "note": null,
                "address": "أولاد صقر شارع المحكمة أولاد صقر وتخدم منطقة  أولاد صقر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553464520",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/237.mp3"
                ]
            },
            {
                "id": 1063,
                "gov": "الشرقية",
                "branch": "هندسة صان الحجر",
                "description": null,
                "note": null,
                "address": "الحسينية صان الحجر وتخدم منطقة صان الحجر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552992357",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/238.mp3"
                ]
            },
            {
                "id": 1064,
                "gov": "الشرقية",
                "branch": "هندسة فاقوس",
                "description": null,
                "note": null,
                "address": "شارع السيد حسين فاقوس وتخدم منطقة فاقوس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "555397321",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/239.mp3"
                ]
            },
            {
                "id": 1065,
                "gov": "الشرقية",
                "branch": "هندسة كفر سقر",
                "description": null,
                "note": null,
                "address": "شارع البحر حي النصر كفر سقر وتخدم منطقة كفر سقر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553183806",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/240.mp3"
                ]
            },
            {
                "id": 1066,
                "gov": "الشرقية",
                "branch": "هندسة ههيا",
                "description": null,
                "note": null,
                "address": "ههيا شارع البحر مساكن العساكرة بلوك 2 ههيا وتخدم منطقة  ههيا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552564303",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/241.mp3"
                ]
            },
            {
                "id": 1067,
                "gov": "الشرقية",
                "branch": "قطاع شبكات وسط الشرقية",
                "description": null,
                "note": null,
                "address": "أوسط الزقازيق خلف مبنى الديوان العام للمحافظة وتخدم منطقة وسط الشرقية المركز الرئيسي ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552314398",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/242.mp3"
                ]
            },
            {
                "id": 1068,
                "gov": "الشرقية",
                "branch": "هندسة أبو حماد",
                "description": null,
                "note": null,
                "address": "أبوحماد طريق أبو حماد الإسماعيلية وتخدم منطقة أبو حماد ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553402790",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/243.mp3"
                ]
            },
            {
                "id": 1069,
                "gov": "الشرقية",
                "branch": "هندسة القرين",
                "description": null,
                "note": null,
                "address": "مدينة القرين بجوار مجلس المدينة ومدرسة الصنايع وتخدم منطقة  القرين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553440897",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/244.mp3"
                ]
            },
            {
                "id": 1070,
                "gov": "الشرقية",
                "branch": "هندسة القنايات",
                "description": null,
                "note": null,
                "address": "القنيات بجوار قسم الشرطة وتخدم منطقة  القنايات",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552630217",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/245.mp3"
                ]
            },
            {
                "id": 1071,
                "gov": "الشرقية",
                "branch": "هندسة جامعة الزقازيق",
                "description": null,
                "note": null,
                "address": "وسط الزقازيق حي الزهور خلف مديرية الإسكان وتخدم منطقة جامعة الزقازيق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552312673",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/246.mp3"
                ]
            },
            {
                "id": 1072,
                "gov": "الشرقية",
                "branch": "هندسة شرق الزقازيق",
                "description": null,
                "note": null,
                "address": "وسط الزقازيق الحسينية ش الشهيد طيار الزقازيق وتخدم منطقة  شرق الزقازيق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552335086",
                "tel2": "552334991",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/247.mp3"
                ]
            },
            {
                "id": 1073,
                "gov": "الشرقية",
                "branch": "هندسة غرب الزقازيق",
                "description": null,
                "note": null,
                "address": "وسط الزقازيق القومية خلف المصرية بلازا وتخدم منطقة غرب الزقازيق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552304867",
                "tel2": "552303531",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/248.mp3"
                ]
            },
            {
                "id": 1074,
                "gov": "الشرقية",
                "branch": "هندسة قرى الزقازيق",
                "description": null,
                "note": null,
                "address": "وسط الزقازيق الزراعة بجوار موقف الاتوبيس وتخدم منطقة قرى الزقازيق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552279970",
                "tel2": "552302403",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/249.mp3"
                ]
            },
            {
                "id": 1075,
                "gov": "الشرقية",
                "branch": "هندسة وسط الزقازيق",
                "description": null,
                "note": null,
                "address": "وسط الزقازيق ميدان الصاغة وتخدم منطقة وسط الزقازيق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552302390",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/250.mp3"
                ]
            },
            {
                "id": 1076,
                "gov": "الشرقية",
                "branch": "قطاع شبكات جنوب الشرقية",
                "description": null,
                "note": null,
                "address": "خلف مبنى الديوان العام للمحافظة وتخدم منطقة جنوب الشرقية المركز الرئيسي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552349583",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/251.mp3"
                ]
            },
            {
                "id": 1077,
                "gov": "الشرقية",
                "branch": "هندسة الإبراهيمية",
                "description": null,
                "note": null,
                "address": "الإبراهيمية ش بور سعيد بجوار الإدارة البيطرية وتخدم منطقة الإبراهيمية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552590520",
                "tel2": "552590000",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/252.mp3"
                ]
            },
            {
                "id": 1078,
                "gov": "الشرقية",
                "branch": "هندسة البر الشرقي",
                "description": null,
                "note": null,
                "address": "طريق بلبيس مصر الصحراوي بجوار محطة محولات بلبيس وتخدم منطقة  البر الشرقي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "559580504",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/253.mp3"
                ]
            },
            {
                "id": 1079,
                "gov": "الشرقية",
                "branch": "هندسة أنشاص",
                "description": null,
                "note": null,
                "address": "انشاص بجوار الوحدة المحلية بانشاص وتخدم منطقة  أنشاص",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552823017",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/254.mp3"
                ]
            },
            {
                "id": 1080,
                "gov": "الشرقية",
                "branch": "هندسة بلبيس",
                "description": null,
                "note": null,
                "address": "مدينة بلبيش بجوار مجلس المدينة وتخدم منطقة بلبيس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552847615",
                "tel2": "552850013",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/255.mp3"
                ]
            },
            {
                "id": 1081,
                "gov": "الشرقية",
                "branch": "هندسة ديرب نجم",
                "description": null,
                "note": null,
                "address": "ديرب نجم بجوار مدرسة الإعدادية بنات طريق الإبراهيمية وتخدم منطقة  ديرب نجم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553761694",
                "tel2": "553760952",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/256.mp3"
                ]
            },
            {
                "id": 1082,
                "gov": "الشرقية",
                "branch": "هندسة شرق منيا القمح",
                "description": null,
                "note": null,
                "address": "مينا القمح شارت الدكتور محمد مندور متفرع من ش سعد زغلول وتخدم منطقة  شرق منيا القمح ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553662872",
                "tel2": "553661494",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/257.mp3"
                ]
            },
            {
                "id": 1083,
                "gov": "الشرقية",
                "branch": "هندسة غرب منيا القمح",
                "description": null,
                "note": null,
                "address": "منيا القمح بجوار مجلس المدينة وتخدم منطقة  غرب منيا القمح",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553654240",
                "tel2": "553660621",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/258.mp3"
                ]
            },
            {
                "id": 1084,
                "gov": "الشرقية",
                "branch": "هندسة مشتول السوق",
                "description": null,
                "note": null,
                "address": "مشتول السوق ش المدينة المنورة وتخدم منطقة  مشتول السوق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "552570366",
                "tel2": "552570887",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/259.mp3"
                ]
            },
            {
                "id": 1085,
                "gov": "شمال سيناء",
                "branch": "قطاع شبكات شمال سيناء",
                "description": null,
                "note": null,
                "address": "العريش شارع الجيس العريش وتخدم منطقة شمال سيناء المركز الرئيسي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "683350178",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/260.mp3"
                ]
            },
            {
                "id": 1086,
                "gov": "شمال سيناء",
                "branch": "هندسة الحسنة",
                "description": null,
                "note": null,
                "address": "شمال سيناء الحسنة وتخدم منطقة  الحسنه",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "683570243",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/261.mp3"
                ]
            },
            {
                "id": 1087,
                "gov": "شمال سيناء",
                "branch": "هندسة الشيخ زويد",
                "description": null,
                "note": null,
                "address": "الشيخ زويد الشارع العام بجوار السنترال وتخدم منطقة  الشيخ زويد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "683502821",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/262.mp3"
                ]
            },
            {
                "id": 1088,
                "gov": "شمال سيناء",
                "branch": "هندسة العريش",
                "description": null,
                "note": null,
                "address": "العريش شارع الجيش أمام المستشفى العام وتخدم منطقة  العريش",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "683355004",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/263.mp3"
                ]
            },
            {
                "id": 1089,
                "gov": "شمال سيناء",
                "branch": "هندسة المساعيد",
                "description": null,
                "note": null,
                "address": "المساعيد العريش ش الفاتح أمام قرية ظلال النخيل وتخدم منطقة  المساعيد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "6834341489",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/264.mp3"
                ]
            },
            {
                "id": 1090,
                "gov": "شمال سيناء",
                "branch": "هندسة بئر العبد",
                "description": null,
                "note": null,
                "address": "بئر العبد الشارع الرئيسي بجوار موقف الأتوبيس وتخدم منطقة  بئر العبد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "683540421",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/265.mp3"
                ]
            },
            {
                "id": 1091,
                "gov": "شمال سيناء",
                "branch": "هندسة رفح",
                "description": null,
                "note": null,
                "address": "رفح الشارع العام وتخدم منطقة  رفح",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "683300549",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/266.mp3"
                ]
            },
            {
                "id": 1092,
                "gov": "شمال سيناء",
                "branch": "هندسة رمانة",
                "description": null,
                "note": null,
                "address": "رفح قرية 6 أكتوبر بجوار محطة الديزل وتخدم منطقة  رمانة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "683820476",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/267.mp3"
                ]
            },
            {
                "id": 1093,
                "gov": "شمال سيناء",
                "branch": "هندسة نخل",
                "description": null,
                "note": null,
                "address": "شمال سيناء نخل وتخدم منطقة  نخل",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "683600675",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/268.mp3"
                ]
            },
            {
                "id": 1094,
                "gov": "اسيوط",
                "branch": "الشئون التجارية المركزية",
                "description": null,
                "note": null,
                "address": "الارعين بجوار مستشفى اليامان وتخدم منطقة  مدينة أسيوط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882374431",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/269.mp3"
                ]
            },
            {
                "id": 1095,
                "gov": "اسيوط",
                "branch": "ابنوب",
                "description": null,
                "note": null,
                "address": "شارع بورسعيد بجوار مدرسة ابنوب الصناعية وتخدم منطقة  قرى ابنوب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882500453",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/270.mp3"
                ]
            },
            {
                "id": 1096,
                "gov": "اسيوط",
                "branch": "أبوتيج",
                "description": null,
                "note": null,
                "address": "شارع الجلاء أبو تيج وتخدم منطقة قرى ابوتيج",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882483630",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/271.mp3"
                ]
            },
            {
                "id": 1097,
                "gov": "اسيوط",
                "branch": "البدارى",
                "description": null,
                "note": null,
                "address": "شارع السيما خلف مركز شرطة البداري وتخدم منطقة  قرى البدارى",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882600600",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/272.mp3"
                ]
            },
            {
                "id": 1098,
                "gov": "اسيوط",
                "branch": "الغنايم",
                "description": null,
                "note": null,
                "address": "الغنايم أسيوط وتخدم منطقة  قرى الغنايم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882650044",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/273.mp3"
                ]
            },
            {
                "id": 1099,
                "gov": "اسيوط",
                "branch": "الفتح",
                "description": null,
                "note": null,
                "address": "مركز الفتح أول كوبري بني مر وتخدم منطقة  قرى الفتح",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882401240",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/274.mp3"
                ]
            },
            {
                "id": 1100,
                "gov": "اسيوط",
                "branch": "القوصية",
                "description": null,
                "note": null,
                "address": "شارع المستشفى أمام مستشفى القوصية المركزي وتخدم منطقة  قرى القوصية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "884750900",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/275.mp3"
                ]
            },
            {
                "id": 1101,
                "gov": "اسيوط",
                "branch": "المركز بحري",
                "description": null,
                "note": null,
                "address": "منقباد طريق أسيوط القاهرة الزراعي وتخدم منطقة  قرى بحرى",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882270296",
                "tel2": "882277866",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/276.mp3"
                ]
            },
            {
                "id": 1102,
                "gov": "اسيوط",
                "branch": "المركز جنوب ",
                "description": null,
                "note": null,
                "address": "الأربعين بجوار مستشفى الإيمان وتخدم منطقة  قرى جنوب المركز",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882374431",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/277.mp3"
                ]
            },
            {
                "id": 1103,
                "gov": "اسيوط",
                "branch": "ديروط",
                "description": null,
                "note": null,
                "address": "شارع بورسعيد بجوار محطة المياة وتخدم منطقة قرى ديروط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "884770800",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/278.mp3"
                ]
            },
            {
                "id": 1104,
                "gov": "اسيوط",
                "branch": "ساحل سليم",
                "description": null,
                "note": null,
                "address": "شارع الجمهوري خلف مجلس المدينة وتخدم منطقة قرى ساحل سليم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882630800",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/279.mp3"
                ]
            },
            {
                "id": 1105,
                "gov": "اسيوط",
                "branch": "شرق",
                "description": null,
                "note": null,
                "address": "أسيوط شرق محطة السكة الحديد وتخدم منطقة  قرى شرق المحطة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882385240",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/280.mp3"
                ]
            },
            {
                "id": 1106,
                "gov": "اسيوط",
                "branch": "صدفا",
                "description": null,
                "note": null,
                "address": "شارع أبو العباس صدفا وتخدم منطقة  قرى صدفا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "883630700",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/281.mp3"
                ]
            },
            {
                "id": 1107,
                "gov": "اسيوط",
                "branch": "غرب",
                "description": null,
                "note": null,
                "address": "الأربعين بجوار مستشفى الإيمان وتخدم منطقة قرى غرب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882335069",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/282.mp3"
                ]
            },
            {
                "id": 1108,
                "gov": "اسيوط",
                "branch": "مبنى القطاع ",
                "description": null,
                "note": null,
                "address": "شارع التحكم المركز شرق المحطة أسيوط وتخدم منطقة مدينة أسيوط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882310071",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/283.mp3"
                ]
            },
            {
                "id": 1109,
                "gov": "اسيوط",
                "branch": "منفلوط",
                "description": null,
                "note": null,
                "address": "شارع الجوفار بجوار النادي الرياضي وتخدم منطقة  قرى منفلوط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "884700713",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/284.mp3"
                ]
            },
            {
                "id": 1110,
                "gov": "المنيا",
                "branch": "أبوقرقاس",
                "description": null,
                "note": null,
                "address": "شارع بورسعيد الفكرية بجوار مجلس مدينة أبوقرقاص وتخدم منطقة  قرى أبو قرقاص",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "862420833",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/285.mp3"
                ]
            },
            {
                "id": 1111,
                "gov": "المنيا",
                "branch": "العدوة",
                "description": null,
                "note": null,
                "address": "أمام مستشفى العدوة بجوار السنترال العدوة وتخدم منطقة  قرى العدوة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "863460060",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/286.mp3"
                ]
            },
            {
                "id": 1112,
                "gov": "المنيا",
                "branch": "المنيا شرق",
                "description": null,
                "note": null,
                "address": "شارع طه حسين بجوار شرطة الكهرباء المنيا وتخدم منطقة  قرى شرق المنيا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "863369038",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/287.mp3"
                ]
            },
            {
                "id": 1113,
                "gov": "المنيا",
                "branch": "المنيا غرب",
                "description": null,
                "note": null,
                "address": "ش بين الشواني طريق مصر أسوان الزراعي المنيا وتخدم منطقة  قرى غرب المنيا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "862361506",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/288.mp3"
                ]
            },
            {
                "id": 1114,
                "gov": "المنيا",
                "branch": "بني مزار",
                "description": null,
                "note": null,
                "address": "شارع الجمهورية بجوار النتسرال وتخدم منطقة  قرى نبي مزار",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "863785106",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/289.mp3"
                ]
            },
            {
                "id": 1115,
                "gov": "المنيا",
                "branch": "ديرمواس",
                "description": null,
                "note": null,
                "address": "20شارع صلاح عبد الحكيم ديرمواس وتخدم منطقة قرى ديرومواس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "862014005",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/290.mp3"
                ]
            },
            {
                "id": 1116,
                "gov": "المنيا",
                "branch": "سمالوط",
                "description": null,
                "note": null,
                "address": "طريق مصر أسوان بجوار مركز شرطة سمالوط وتخدم منطقة قرى سمالوط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "863309220",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/291.mp3"
                ]
            },
            {
                "id": 1117,
                "gov": "المنيا",
                "branch": "مدينة ملوي",
                "description": null,
                "note": null,
                "address": "شارع وابور النور خلف حديقة مبارك ملوي وتخدم منطقة  مدينة ملوي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "862639755",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/292.mp3"
                ]
            },
            {
                "id": 1118,
                "gov": "المنيا",
                "branch": "مركز المنيا",
                "description": null,
                "note": null,
                "address": "أرض المولد أبو هلال أمام قوات الأمن المنيا وتخدم منطقة  قرى المنيا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "862346558",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/293.mp3"
                ]
            },
            {
                "id": 1119,
                "gov": "المنيا",
                "branch": "مركز ملوي",
                "description": null,
                "note": null,
                "address": "أخر شارع المجيدي ملوي وتخدم منطقة قرى ملوي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "862584211",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/294.mp3"
                ]
            },
            {
                "id": 1120,
                "gov": "المنيا",
                "branch": "مطاي",
                "description": null,
                "note": null,
                "address": "طريق مصر أسوان بجوار جامع أبو بكر وتخدم منطقة  قرى مطاي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "863920639",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/295.mp3"
                ]
            },
            {
                "id": 1121,
                "gov": "المنيا",
                "branch": "مغاغة",
                "description": null,
                "note": null,
                "address": "طريق مصر أسوان خلف محطة المياة مغاغة وتخدم منطقة  قرى مغافة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "863556675",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/296.mp3"
                ]
            },
            {
                "id": 1122,
                "gov": "مطروح",
                "branch": "الساحل الشمالي 25 يناير",
                "description": null,
                "note": null,
                "address": "الإدارة العامة للساحل الشمالي وتخدم منطقة  قرية 25 يناير",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464106479",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/297.mp3"
                ]
            },
            {
                "id": 1123,
                "gov": "مطروح",
                "branch": "السلوم الشئون التجارية",
                "description": null,
                "note": null,
                "address": "السلوم وتخدم منطقة  السلوم والنجوع التابعة لها ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464800596",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/298.mp3"
                ]
            },
            {
                "id": 1124,
                "gov": "مطروح",
                "branch": "الضبعة",
                "description": null,
                "note": null,
                "address": "الضبعة وتخدم منطقة  الضبعة وفوكة وأولاد علواني",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464670486",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/299.mp3"
                ]
            },
            {
                "id": 1125,
                "gov": "مطروح",
                "branch": "العلمين",
                "description": null,
                "note": null,
                "address": "العلمين وتخدم منطقة مدينة العلمين والنجوع التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464100170",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/300.mp3"
                ]
            },
            {
                "id": 1126,
                "gov": "مطروح",
                "branch": "المنتزة",
                "description": null,
                "note": null,
                "address": "المنتزة وتخدم منطقة  قرية أولاد جبريل والرويسات والقرى السياحية التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464102528",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/301.mp3"
                ]
            },
            {
                "id": 1127,
                "gov": "مطروح",
                "branch": "سيدي راني الشئون التجارية",
                "description": null,
                "note": null,
                "address": "سيدي براني وتخدم منطقة  سيد براني والنجوع التابعة لها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464400127",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/302.mp3"
                ]
            },
            {
                "id": 1128,
                "gov": "مطروح",
                "branch": "سيدي عبد الرحمن ",
                "description": null,
                "note": null,
                "address": "سيدي عبد الرحمن وتخدم منطقة  سيدي عبد الرحمن والنجوع التابعة الها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464680233",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/303.mp3"
                ]
            },
            {
                "id": 1129,
                "gov": "مطروح",
                "branch": "سيوة",
                "description": null,
                "note": null,
                "address": "سيوة وتخدم منطقة  سيوة والنجوع التابعة لها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464601249",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/304.mp3"
                ]
            },
            {
                "id": 1130,
                "gov": "مطروح",
                "branch": "مارينا - موزع (ج) ك 98",
                "description": null,
                "note": null,
                "address": "مارينا - موزع (ج) ك98 وتخدم منطقة  قرية مارينا السياحية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464450749",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/305.mp3"
                ]
            },
            {
                "id": 1131,
                "gov": "مطروح",
                "branch": "مطروح شرق",
                "description": null,
                "note": null,
                "address": "مطروح شرق وتخدم منطقة  شرق مطروح",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464932760",
                "tel2": "464941102",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/306.mp3"
                ]
            },
            {
                "id": 1132,
                "gov": "مطروح",
                "branch": "مطروح غرب",
                "description": null,
                "note": null,
                "address": "مطروح غرب وتخدم منطقة  غرب مطروح",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "464951030",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/307.mp3"
                ]
            },
            {
                "id": 1133,
                "gov": "السويس",
                "branch": "قطاع شبكات السويس",
                "description": null,
                "note": null,
                "address": "كفر أحمد عبده طريق ناصر السويس وتخدم منطقة  السويس المركز الرئيسي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "623338561",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/308.mp3"
                ]
            },
            {
                "id": 1134,
                "gov": "السويس",
                "branch": "هندسة الأربعين",
                "description": null,
                "note": null,
                "address": "شارع الشهداء ومظلوم وابور النور والأربعين وتخدم منطقة الأربعين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "623227366",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/309.mp3"
                ]
            },
            {
                "id": 1135,
                "gov": "السويس",
                "branch": "هندسة الجناين",
                "description": null,
                "note": null,
                "address": "ك 10 طريق الإسماعيلية قرية عامر العمدة الجنايو وتخدم منطقة  الجناين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "623501915",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/310.mp3"
                ]
            },
            {
                "id": 1136,
                "gov": "السويس",
                "branch": "هندسة الخليج",
                "description": null,
                "note": null,
                "address": "الاتكة طريق السخنة أمام ميناء الاتكة عناقة وتخدم منطقة  الخليج",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "623230140",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/311.mp3"
                ]
            },
            {
                "id": 1137,
                "gov": "السويس",
                "branch": "هندسة السويس",
                "description": null,
                "note": null,
                "address": "الخور بجوار الصرف الصحي الغريب السويس وتخدم منطقة السويس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "623194723",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/312.mp3"
                ]
            },
            {
                "id": 1138,
                "gov": "السويس",
                "branch": "هندسة فيصل",
                "description": null,
                "note": null,
                "address": "السويس الحرفين فيصل وتخدم منطقة  فيص",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "623670308",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/313.mp3"
                ]
            },
            {
                "id": 1139,
                "gov": "دمياط",
                "branch": "الزرقا",
                "description": null,
                "note": null,
                "address": "الزرقا بجوار كوبري الزرقا وتخدم منطقة الزرقا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "573850703",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/314.mp3"
                ]
            },
            {
                "id": 1140,
                "gov": "دمياط",
                "branch": "جنوب دمياط",
                "description": null,
                "note": null,
                "address": "دمياط أمام كوبري المعلمين بجوار شركة المياة وتخدم منطقة  دمياط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "572228893",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/315.mp3"
                ]
            },
            {
                "id": 1141,
                "gov": "دمياط",
                "branch": "شمال دمياط",
                "description": null,
                "note": null,
                "address": "دمياط تحت الكوبري العلوي بجوار مجلس حي رابع وتخدم منطقة  دمياط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "572228893",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/316.mp3"
                ]
            },
            {
                "id": 1142,
                "gov": "دمياط",
                "branch": "عزبة البرج",
                "description": null,
                "note": null,
                "address": "عزبة البرج شارع البنك الأهلي بجوار بنزينة عزبة البرج وتخدم منطقة  عزبة البرج",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "572701853",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/317.mp3"
                ]
            },
            {
                "id": 1143,
                "gov": "دمياط",
                "branch": "كفر سعد",
                "description": null,
                "note": null,
                "address": "كفر سعد بجوار سنترال كفر سعد وتخدم منطقة  كفر سعد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "573602206",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/318.mp3"
                ]
            },
            {
                "id": 1144,
                "gov": "دمياط",
                "branch": "الروضة",
                "description": null,
                "note": null,
                "address": "طريق فارسكور وتخدم منطقة  الروضة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "573472967",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/319.mp3"
                ]
            },
            {
                "id": 1145,
                "gov": "دمياط",
                "branch": "الشعراء",
                "description": null,
                "note": null,
                "address": "الشعراء بجوار موقف الشعراء أمام كازينو المهندسين وتخدم منطقة  الشعراء",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "572243272",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/320.mp3"
                ]
            },
            {
                "id": 1146,
                "gov": "دمياط",
                "branch": "فارسكور",
                "description": null,
                "note": null,
                "address": "فارسكور شارع البحر وتخدم منطقة  فارسكور",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "573440967",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/321.mp3"
                ]
            },
            {
                "id": 1147,
                "gov": "دمياط",
                "branch": "كفر البطيخ",
                "description": null,
                "note": null,
                "address": "كفر البطيخ طريق دمياط بجوار الكوبري العلوي وتخدم منطقة كفر البطيخ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "573661870",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/322.mp3"
                ]
            },
            {
                "id": 1148,
                "gov": "دمياط",
                "branch": "رأس البر",
                "description": null,
                "note": null,
                "address": "9ش 49 أمام شارع بور سعيد رأس البر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "572527764",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/323.mp3"
                ]
            },
            {
                "id": 1149,
                "gov": "الدقهلية",
                "branch": "الجمالية",
                "description": null,
                "note": null,
                "address": "شارع الإمام منسي بجوار السنترال وتخدم منقطة مدينة الجمالية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "503743792",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/324.mp3"
                ]
            },
            {
                "id": 1150,
                "gov": "الدقهلية",
                "branch": "فرى السنبلاوين",
                "description": null,
                "note": null,
                "address": "عزبة صقر سوق السمك وتخدم منقطة  قرى السنبلاوين وضواحيها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "504688153",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/325.mp3"
                ]
            },
            {
                "id": 1151,
                "gov": "الدقهلية",
                "branch": "مدينة السنبلاوين",
                "description": null,
                "note": null,
                "address": "عزبة صقر سوق السمك وتخدم منقطة  مدينة السنبلاوين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "504693956",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/326.mp3"
                ]
            },
            {
                "id": 1152,
                "gov": "الدقهلية",
                "branch": "المطرية",
                "description": null,
                "note": null,
                "address": "شارع الشرقية والأمين أمام مدرسة أحمد ماهر وتخدم منقطة  مدينة المطرية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "503750091",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/327.mp3"
                ]
            },
            {
                "id": 1153,
                "gov": "الدقهلية",
                "branch": "قرى المنزلة",
                "description": null,
                "note": null,
                "address": "شارع الجلاء ومطلوم بجوار سوق السمك وتخدم منقطة قرى المنزلة وضواحيها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "503710774",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/328.mp3"
                ]
            },
            {
                "id": 1154,
                "gov": "الدقهلية",
                "branch": "مدينة المنزلة",
                "description": null,
                "note": null,
                "address": "شارع الجلاء ومظلوم بجارو سوق السمك وتخدم منقطة  مدينة المنزلة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "503705500",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/329.mp3"
                ]
            },
            {
                "id": 1155,
                "gov": "الدقهلية",
                "branch": "مدينة أجا",
                "description": null,
                "note": null,
                "address": "شارع الجلاء وتخدم منقطة  مدينة أجا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "506456222",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/330.mp3"
                ]
            },
            {
                "id": 1156,
                "gov": "الدقهلية",
                "branch": "بني عبيد",
                "description": null,
                "note": null,
                "address": "مدخل مدينة بني عبيد بجوار المعهد الديني وتخدم منقطة  مدينة بني عبيد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502640400",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/331.mp3"
                ]
            },
            {
                "id": 1157,
                "gov": "الدقهلية",
                "branch": "تمي الأمديد",
                "description": null,
                "note": null,
                "address": "شارع هشام المسري بجوار الإدارة التعليمية وتخدم منقطة  مدينة تمى الأمديد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "504852702",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/332.mp3"
                ]
            },
            {
                "id": 1158,
                "gov": "الدقهلية",
                "branch": "جمصة",
                "description": null,
                "note": null,
                "address": "المنطقة الصناعية 15 مايو وتخدم منقطة  مدينة جمصة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502740816",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/333.mp3"
                ]
            },
            {
                "id": 1159,
                "gov": "الدقهلية",
                "branch": "قرى شربين",
                "description": null,
                "note": null,
                "address": "شارع البحر بجوار مجلس مدينة شربين وتخدم منقطة قرى شربين وضواحيها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "503932485",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/334.mp3"
                ]
            },
            {
                "id": 1160,
                "gov": "الدقهلية",
                "branch": "شرق المنصورة",
                "description": null,
                "note": null,
                "address": "المختلط 1 شارع فريدة حسان وتخدم منقطة  شرق مدينة المنصورة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502314012",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/335.mp3"
                ]
            },
            {
                "id": 1161,
                "gov": "الدقهلية",
                "branch": "غرب المنصورة",
                "description": null,
                "note": null,
                "address": "المنصورة ميدان مشعل وتخدم منقطة  غرب مدينة المنصورة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502257229",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/336.mp3"
                ]
            },
            {
                "id": 1162,
                "gov": "الدقهلية",
                "branch": "خلطا ",
                "description": null,
                "note": null,
                "address": "شارع فريدة حسان خلف قسم شرطة طلخا وتخدم منقطة مدينة طلخا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502526912",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/337.mp3"
                ]
            },
            {
                "id": 1163,
                "gov": "الدقهلية",
                "branch": "ميت سلسيل",
                "description": null,
                "note": null,
                "address": "شارع طريق المنصورة بجوار محكمة ميت سلسسل وتخدم منقطة  مدينة ميت سلسيل",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502710710",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/338.mp3"
                ]
            },
            {
                "id": 1164,
                "gov": "الدقهلية",
                "branch": "قرى ميت غمر",
                "description": null,
                "note": null,
                "address": "شارع جسر النيل أمام محطة المحولات القديمة وتخدم منقطة  قرى ميت غمر وضواحيها ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "504902342",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/339.mp3"
                ]
            },
            {
                "id": 1165,
                "gov": "الدقهلية",
                "branch": "مدينة ميت غمر",
                "description": null,
                "note": null,
                "address": "شارع جسر النيل أمام محطة المحولات القديمة وتخدم منقطة  مدينة ميت غمر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "504909474",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/340.mp3"
                ]
            },
            {
                "id": 1166,
                "gov": "الدقهلية",
                "branch": "نبروة",
                "description": null,
                "note": null,
                "address": "شارع الجمهورية خلف النادي الرياضي وتخدم منقطة  مدينة نبروة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502401217",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/341.mp3"
                ]
            },
            {
                "id": 1167,
                "gov": "الدقهلية",
                "branch": "الستاموني",
                "description": null,
                "note": null,
                "address": "عزبة أبو عشري شارع البنك وتخدم منقطة  مدينة الستاموني",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502967593",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/342.mp3"
                ]
            },
            {
                "id": 1168,
                "gov": "الدقهلية",
                "branch": "قرى بلقاس",
                "description": null,
                "note": null,
                "address": "شارع مجلس المدينة وتخدم منقطة  قرى بلقاس وضواحيها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502795203",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/343.mp3"
                ]
            },
            {
                "id": 1169,
                "gov": "الدقهلية",
                "branch": "مدينة بلقاس",
                "description": null,
                "note": null,
                "address": "شارع مجلس المدينة وتخدم منقطة  مدينة بلقاس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502797672",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/344.mp3"
                ]
            },
            {
                "id": 1170,
                "gov": "الدقهلية",
                "branch": "دكرنس",
                "description": null,
                "note": null,
                "address": "شارع مجلس المدينة بجوار مستشفى الحميات وتخدم منقطة  مدينة دكرنس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "503475196",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/345.mp3"
                ]
            },
            {
                "id": 1171,
                "gov": "الدقهلية",
                "branch": "مدينة شربين",
                "description": null,
                "note": null,
                "address": "شارع البحر بجوار مجلس مدينة شربين وتخدم منقطة  مدينة شربين",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "503920184",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/346.mp3"
                ]
            },
            {
                "id": 1172,
                "gov": "الدقهلية",
                "branch": "قرى المنصورة 1",
                "description": null,
                "note": null,
                "address": "طريق المنصورة اجا بجوار مصنع الراتنجات وتخدم منقطة  قرى المنصورة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502359654",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/347.mp3"
                ]
            },
            {
                "id": 1173,
                "gov": "الدقهلية",
                "branch": "قرى المنصورة 2",
                "description": null,
                "note": null,
                "address": "شارع عبد السلام عارف خلف الاستاد الرياضي وتخدم منقطة قرى المنصورة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "502604248",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/348.mp3"
                ]
            },
            {
                "id": 1174,
                "gov": "الدقهلية",
                "branch": "كوم النور",
                "description": null,
                "note": null,
                "address": "شارع جسر النيل أمام محطة المحولات القديمة وتخدم منقطة مدينة كوم النور التابعة لمدينة ميت غمر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "504980452",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/349.mp3"
                ]
            },
            {
                "id": 1175,
                "gov": "البحر الأحمر",
                "branch": "مينة النصر",
                "description": null,
                "note": null,
                "address": "شارع المستشفى العام طريق منية النصر البجلات وتخدم منقطة  منية النصر والقرى التابعة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "503501121",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/350.mp3"
                ]
            },
            {
                "id": 1176,
                "gov": "البحر الأحمر",
                "branch": "قطاع شبكات البحر الأحمر",
                "description": null,
                "note": null,
                "address": "بجوار مبنى ديوان عام المحافظة الغردقة  وتخدم منقطة البحر الأحمر المركز الرئيسي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "653441165",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/351.mp3"
                ]
            },
            {
                "id": 1177,
                "gov": "البحر الأحمر",
                "branch": "هندسة جنوب الغردقة المدارس",
                "description": null,
                "note": null,
                "address": "الغردقة السقاله شارع المدارس خلف السنترال السياحي وتخدم منقطة  الغردقة المدارس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "653441164",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/352.mp3"
                ]
            },
            {
                "id": 1178,
                "gov": "البحر الأحمر",
                "branch": "هندسة القصير",
                "description": null,
                "note": null,
                "address": "القصير شارع العاشر من رمضان وتخدم منقطة  القصير",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "655369900",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/353.mp3"
                ]
            },
            {
                "id": 1179,
                "gov": "البحر الأحمر",
                "branch": "هندسة رأس غارب الزعفرانه",
                "description": null,
                "note": null,
                "address": "غارب شارع الملك سعود وتخدم منقطة  رأس غارب الزعفرانه",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "653252189",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/354.mp3"
                ]
            },
            {
                "id": 1180,
                "gov": "البحر الأحمر",
                "branch": "هندسة سفاجا",
                "description": null,
                "note": null,
                "address": "سفاجا شارع مجلس المدينة وتخدم منقطة سفاجا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "653251226",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/355.mp3"
                ]
            },
            {
                "id": 1181,
                "gov": "البحر الأحمر",
                "branch": "هندسة شمال الغرقة",
                "description": null,
                "note": null,
                "address": "الغردقة شارع الشهر العقاري حفر الباطن وتخدم منقطة  شمال الغردقة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "653548974",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/356.mp3"
                ]
            },
            {
                "id": 1182,
                "gov": "البحر الأحمر",
                "branch": "هندسة مرى علم",
                "description": null,
                "note": null,
                "address": "مرى علم بجوار موقف البيجو وتخدم منقطة  مرسى علم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "653720362",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/357.mp3"
                ]
            },
            {
                "id": 1183,
                "gov": "قنا",
                "branch": "هندسة وسط الغردقة الاستاد ",
                "description": null,
                "note": null,
                "address": "الغردقة الدهار شارع المصالح وتخدم منقطة  وسط الغردقة الاستاد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "653547119",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/358.mp3"
                ]
            },
            {
                "id": 1184,
                "gov": "قنا",
                "branch": "أبوتشت",
                "description": null,
                "note": null,
                "address": "شارع عرابي وتخدم منقطة  مدينة أبو تشت وقراها",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "966710523",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/359.mp3"
                ]
            },
            {
                "id": 1185,
                "gov": "قنا",
                "branch": "قوص شرق",
                "description": null,
                "note": null,
                "address": "شارع مدرسة الشهداء وتخدم منقطة  قرى شرق قوص",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "962834239",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/360.mp3"
                ]
            },
            {
                "id": 1186,
                "gov": "قنا",
                "branch": "فقط",
                "description": null,
                "note": null,
                "address": "شارع الثورة وتخدم منقطة  مدينة فقط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "962864269",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/361.mp3"
                ]
            },
            {
                "id": 1187,
                "gov": "قنا",
                "branch": "قنا غرب",
                "description": null,
                "note": null,
                "address": "شارع كوبري دنرة وتخدم منقطة  مدن غرب قنا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "963360388",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/362.mp3"
                ]
            },
            {
                "id": 1188,
                "gov": "قنا",
                "branch": "قنا شرق",
                "description": null,
                "note": null,
                "address": "شارع طريق مصنع الغزل وتخدم منقطة  مدن شرق قنا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "965220279",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/363.mp3"
                ]
            },
            {
                "id": 1189,
                "gov": "قنا",
                "branch": "الوقف",
                "description": null,
                "note": null,
                "address": "شارع طراد النيل بجوار مجلس المدينة وتخدم منقطة  مدينة الوقف",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "965443363",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/364.mp3"
                ]
            },
            {
                "id": 1190,
                "gov": "قنا",
                "branch": "فرشوط",
                "description": null,
                "note": null,
                "address": "شارع الشهيد أحمد بدوي وتخدم منقطة  مدينة فرشوط",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "966510313",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/365.mp3"
                ]
            },
            {
                "id": 1191,
                "gov": "قنا",
                "branch": "نجع حمادي شمال",
                "description": null,
                "note": null,
                "address": "بجوار كوبري السكة الحديد  وتخدم منقطة قرى شمال نجع حمادي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "966574691",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/366.mp3"
                ]
            },
            {
                "id": 1192,
                "gov": "قنا",
                "branch": "منجع حمادي جنوب",
                "description": null,
                "note": null,
                "address": "شارع الترعة الضمرانيه وتخدم منقطة  قرى جنوب نجع حمادي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "966594509",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/367.mp3"
                ]
            },
            {
                "id": 1193,
                "gov": "قنا",
                "branch": "نقادة",
                "description": null,
                "note": null,
                "address": "شارع 23 يوليو وتخدم منقطة  مدينة نقادة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "966601828",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/368.mp3"
                ]
            },
            {
                "id": 1194,
                "gov": "قنا",
                "branch": "دشنا",
                "description": null,
                "note": null,
                "address": "شارع كورنيش النيل وتخدم منقطة  مدينة دشنا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "966740473",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/369.mp3"
                ]
            },
            {
                "id": 1195,
                "gov": "بني سويف",
                "branch": "قوص غرب",
                "description": null,
                "note": null,
                "address": "شارع دقيق العيد وتخدم منقطة  مدينة قوص",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "966842082",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/370.mp3"
                ]
            },
            {
                "id": 1196,
                "gov": "بني سويف",
                "branch": "الفشن",
                "description": null,
                "note": null,
                "address": "شارع الجبالة وتخدم منقطة  قرى الفشن",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "824385051",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/371.mp3"
                ]
            },
            {
                "id": 1197,
                "gov": "بني سويف",
                "branch": "الواسطى",
                "description": null,
                "note": null,
                "address": "خلف مجلس المدينة وتخدم منقطة  قرى الوسطى",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "822538369",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/372.mp3"
                ]
            },
            {
                "id": 1198,
                "gov": "بني سويف",
                "branch": "اهناسيا",
                "description": null,
                "note": null,
                "address": "شارع بنك القاهرة بجوار التأمينات الاجتماعية وتخدم منقطة  قرى اهناسيا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "829221255",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/373.mp3"
                ]
            },
            {
                "id": 1199,
                "gov": "بني سويف",
                "branch": "ببا",
                "description": null,
                "note": null,
                "address": "شارع الإبراهيمية خلف مركز الشباب وتخدم منقطة  قرى ببا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "824400891",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/374.mp3"
                ]
            },
            {
                "id": 1200,
                "gov": "بني سويف",
                "branch": "ديوان عام قطاع بني سويف",
                "description": null,
                "note": null,
                "address": "شارع عبد السلام عارف بجوار إدارة الحماية المدنية وتخدم منقطة  ديوان عام قطاع بني سويف",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "822322949",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/375.mp3"
                ]
            },
            {
                "id": 1201,
                "gov": "بني سويف",
                "branch": "سمسطا",
                "description": null,
                "note": null,
                "address": "شارع الجلاء وتخدم منقطة  قرى سمسطا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "822279032",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/376.mp3"
                ]
            },
            {
                "id": 1202,
                "gov": "بني سويف",
                "branch": "شرق النيل",
                "description": null,
                "note": null,
                "address": "عمارة (و) الحي السكني الثاني وتخدم منقطة  قرى شرق النيل",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "82280433",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/377.mp3"
                ]
            },
            {
                "id": 1203,
                "gov": "بني سويف",
                "branch": "مدينة بني سويف",
                "description": null,
                "note": null,
                "address": "ميدان المديرية وتخدم منقطة  مدينة بني سويف",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "822322949",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/378.mp3"
                ]
            },
            {
                "id": 1204,
                "gov": "بني سويف",
                "branch": "مركز بني سويف",
                "description": null,
                "note": null,
                "address": "شارع عبد السلام عارف أمام مدرسة سان مارك وتخدم منقطة  قرى بني سويف",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "822330647",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/379.mp3"
                ]
            },
            {
                "id": 1205,
                "gov": "الفيوم",
                "branch": "ناصر",
                "description": null,
                "note": null,
                "address": "الطريق السريع بجوار بنزينة هشام وتخدم منقطة  قرى ناصر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "823813163",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/380.mp3"
                ]
            },
            {
                "id": 1206,
                "gov": "الفيوم",
                "branch": "ابشواي",
                "description": null,
                "note": null,
                "address": "ابسواي شارع الجمهورية وتخدم منقطة  قرى ابسواي",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842710632",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/381.mp3"
                ]
            },
            {
                "id": 1207,
                "gov": "الفيوم",
                "branch": "اطسا شرق",
                "description": null,
                "note": null,
                "address": "أطسا شارع عمر بن الخطاب وتخدم منقطة  قرى شرق أطسا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "840410644",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/382.mp3"
                ]
            },
            {
                "id": 1208,
                "gov": "الفيوم",
                "branch": "اطسا غرب",
                "description": null,
                "note": null,
                "address": "اطسا شارع عمر بن الخطاب وتخدم منقطة  قرى غرب اطسا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842401644",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/383.mp3"
                ]
            },
            {
                "id": 1209,
                "gov": "الفيوم",
                "branch": "دوان عام قطاع الفيوم",
                "description": null,
                "note": null,
                "address": "الفيوم كيمان فارس ميدان التريب وتخدم منقطة  ديوان عام القطاع",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842110027",
                "tel2": "842110028",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/384.mp3"
                ]
            },
            {
                "id": 1210,
                "gov": "الفيوم",
                "branch": "سنورس شرق",
                "description": null,
                "note": null,
                "address": "مدخل مدينة سنورس وتخدم منقطة  قرى سنورس شرق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842900500",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/385.mp3"
                ]
            },
            {
                "id": 1211,
                "gov": "الفيوم",
                "branch": "سنورس غرب",
                "description": null,
                "note": null,
                "address": "مدخل مدينة سنورس وتخدم منقطة  قرى سنورس غرب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "846901815",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/386.mp3"
                ]
            },
            {
                "id": 1212,
                "gov": "الفيوم",
                "branch": "طامية شرق",
                "description": null,
                "note": null,
                "address": "مدينة طمية شارع 23 يوليو وتخدم منقطة  قرى شرق طامية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842610879",
                "tel2": "846610876",
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/387.mp3"
                ]
            },
            {
                "id": 1213,
                "gov": "الفيوم",
                "branch": "طامية غرب",
                "description": null,
                "note": null,
                "address": "مدينة طامية شاعر 23 يوليو وتخدم منقطة قرى غرب طامية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842614811",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/388.mp3"
                ]
            },
            {
                "id": 1214,
                "gov": "الفيوم",
                "branch": "مدينة الفيوم شمال شرق",
                "description": null,
                "note": null,
                "address": "مساكن السد العالي خلف المدينة الصناعية  وتخدم منقطة قرى مدينة شمال شرق الفيوم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842367248",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/389.mp3"
                ]
            },
            {
                "id": 1215,
                "gov": "الفيوم",
                "branch": "مدينة الفيوم شمال غرب",
                "description": null,
                "note": null,
                "address": "مساكن السد العالي خلف المدينة الصناعية  وتخدم منقطة قرى مدينة شمال غرب الفيوم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842367248",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/390.mp3"
                ]
            },
            {
                "id": 1216,
                "gov": "الفيوم",
                "branch": "مدينة الفيوم جنوب",
                "description": null,
                "note": null,
                "address": "مساكن السد العالي خلف المدينة الصناعية  وتخدم منقطة قرى مدينة جنوب الفيوم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842367248",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/391.mp3"
                ]
            },
            {
                "id": 1217,
                "gov": "الفيوم",
                "branch": "مركز الفيوم شرق",
                "description": null,
                "note": null,
                "address": "مساكن الجون عمارة 5 وتخدم منقطة  قرى شرق الفيوم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842022366",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/392.mp3"
                ]
            },
            {
                "id": 1218,
                "gov": "الفيوم",
                "branch": "مركز الفيوم غرب",
                "description": null,
                "note": null,
                "address": "الحلافي بجوار الصالة الرياضية وتخدم منقطة  قرى غرب الفيوم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842153045",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/393.mp3"
                ]
            },
            {
                "id": 1219,
                "gov": "الأقصر",
                "branch": "يوسف الصديق",
                "description": null,
                "note": null,
                "address": "ابشواي شارع الجمهورية وتخدم منقطة  قرى يوسف الصديق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842710248",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/394.mp3"
                ]
            },
            {
                "id": 1220,
                "gov": "الأقصر",
                "branch": "اسنا شرق",
                "description": null,
                "note": null,
                "address": "شارع سيد الخضري وتخدم منقطة  قرى شرق اسنا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "9.5260440409527E+18",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/395.mp3"
                ]
            },
            {
                "id": 1221,
                "gov": "الأقصر",
                "branch": "اسنا غرب",
                "description": null,
                "note": null,
                "address": "شارع اصفون بجاور المجلس القروي وتخدم منقطة  قرى غرب اسنا",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "952313470",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/396.mp3"
                ]
            },
            {
                "id": 1222,
                "gov": "الأقصر",
                "branch": "الأقصر غرب",
                "description": null,
                "note": null,
                "address": "شارع الطريق السريع وتخدم منقطة  قرى غرب الأقصر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "952301415",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/397.mp3"
                ]
            },
            {
                "id": 1223,
                "gov": "الأقصر",
                "branch": "البياضية",
                "description": null,
                "note": null,
                "address": "شارع المستشفى البياضية وتخدم منقطة  مدينة البياضية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "952402821",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/398.mp3"
                ]
            },
            {
                "id": 1224,
                "gov": "الأقصر",
                "branch": "الزينية",
                "description": null,
                "note": null,
                "address": "بجوار الوحدة المحلية وتخدم منقطة مدينة الزينية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "952700546",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/399.mp3"
                ]
            },
            {
                "id": 1225,
                "gov": "الأقصر",
                "branch": "العديسات",
                "description": null,
                "note": null,
                "address": "طريق مصر أسوان وتخدم منقطة  مدينة العديسات",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "952626515",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/400.mp3"
                ]
            },
            {
                "id": 1226,
                "gov": "الأقصر",
                "branch": "أرمنت",
                "description": null,
                "note": null,
                "address": "شارع الشهيد عبد الرحمن وتخدم منقطة  قرى أرمنت",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "952280875",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/401.mp3"
                ]
            },
            {
                "id": 1227,
                "gov": "الأقصر",
                "branch": "جنوب الأقصر",
                "description": null,
                "note": null,
                "address": "شارع خالد بن الوليد الأقصر وتخدم منقطة  قرى جنوب الأقصر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "952371138",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/402.mp3"
                ]
            },
            {
                "id": 1228,
                "gov": "القاهرة",
                "branch": "شمال الأقصر",
                "description": null,
                "note": null,
                "address": "شرق السكة الحديد السواقي وتخدم منقطة  قرى شمال الأقصر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": null,
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/403.mp3"
                ]
            },
            {
                "id": 1229,
                "gov": "القاهرة",
                "branch": "التجمع الأول",
                "description": null,
                "note": null,
                "address": "ش التسعين الحي الثاني أمام المستشفى الجوي وتخدم منقطة  التجمع الأول بمدينة القاهرة الجديدة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "225644003",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/404.mp3"
                ]
            },
            {
                "id": 1230,
                "gov": "القاهرة",
                "branch": "التجمع الخامس",
                "description": null,
                "note": null,
                "address": "ش التسعين الحي الثاني أمام المستشفى الجوي وتخدم منقطة  التجمع الخامس بمدينة القاهرة الجديدة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "225644008",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/405.mp3"
                ]
            },
            {
                "id": 1231,
                "gov": "الجيزة",
                "branch": "الرحاب",
                "description": null,
                "note": null,
                "address": "المرحلة الراعبة خلف المدرسة الفرنسية الألمانية عمارة 32 سابقة التجهيز أمام مدرسة الحرمين وتخدم منطقة مدية الرحاب ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "226076684",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/406.mp3"
                ]
            },
            {
                "id": 1232,
                "gov": "الجيزة",
                "branch": " القطامية",
                "description": null,
                "note": null,
                "address": "المرحلة الراعبة خلف المدرسة الفرنسية الألمانية عمارة 32 سابقة التجهيز أمام مدرسة الحرمين وتخدم منقطة مدينة القطامية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "227586990",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/407.mp3"
                ]
            },
            {
                "id": 1233,
                "gov": "الجيزة",
                "branch": "أكتوبر 1",
                "description": null,
                "note": null,
                "address": "الحي 12 أمام المحاورة الرابعة وتخدم منقطة الاحياء من 1-6 المنطقة الصناعية غرب طريق الواحات والمنطقة بين طريق الواحات وطريق الفيوم",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238330476",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/408.mp3"
                ]
            },
            {
                "id": 1234,
                "gov": "القاهرة",
                "branch": "أكتوبر 12",
                "description": null,
                "note": null,
                "address": "الحي 12 أمام المحاورة الرابعة وتخدم منقطة شرق طريق الواحات وغرب المحور والاحياء من 7-12",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238330476",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/409.mp3"
                ]
            },
            {
                "id": 1235,
                "gov": "الأسكندرية",
                "branch": "الشيخ زايد",
                "description": null,
                "note": null,
                "address": "الشيخ زايد خلف المستشفى العام وتخدم منقطة  مدينة الشيخ زايد",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "238512004",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/410.mp3"
                ]
            },
            {
                "id": 1236,
                "gov": "المنوفية",
                "branch": "15 مايو",
                "description": null,
                "note": null,
                "address": "المشروع الأمريكي مجاورة 3 بجوار السنترال وتخدم منقطة  مدينة 15 مايو المشروع الأمريكي عرب غنيم وعرب راشد وحلوان البلد والمثلث والتبين وكفر علو ومنشية جمال عبد الناصر والحكر الحري والقبلي ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "225590865",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/411.mp3"
                ]
            },
            {
                "id": 1237,
                "gov": "القاهرة",
                "branch": "برج العب الجديد",
                "description": null,
                "note": null,
                "address": "طريق مطار برج العرب بجوار مستودع الأنابيب وتخدم منقطة  المناطق الصناعية ومساكن برج العرب الجديد وبهيج الهوارية والدفاع الجوي وأبو صويلح والقطعان",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "34620342",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/412.mp3"
                ]
            },
            {
                "id": 1238,
                "gov": "القاهرة",
                "branch": "مدينة السادات ",
                "description": null,
                "note": null,
                "address": "مدينة السادات وتخدم منقطة  مدينة السادات",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "482600273",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/413.mp3"
                ]
            },
            {
                "id": 1239,
                "gov": "القاهرة",
                "branch": "مدينة النوبارية الجديدة",
                "description": null,
                "note": null,
                "address": "مدينة النوبارية وتخدم منقطة  مدينة النوبارية الجديدة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "452632218",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/414.mp3"
                ]
            },
            {
                "id": 1240,
                "gov": "القاهرة",
                "branch": "قطاع المدن الجديدة",
                "description": null,
                "note": null,
                "address": "العاشر من رمضان المجاورة 42 منطقة البنوك وتخدم منقطة المدن الجديدة المركز الرئيسي ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "554502156",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/415.mp3"
                ]
            },
            {
                "id": 1241,
                "gov": "القاهرة",
                "branch": "هندسة شرق العاشر الجديدة",
                "description": null,
                "note": null,
                "address": "مركز حي السابع خلف حي الياسمين وتخدم منقطة  شرق العاشر الجديدة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "554384025",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/416.mp3"
                ]
            },
            {
                "id": 1242,
                "gov": "القاهرة",
                "branch": "هندسة هليوبليس",
                "description": null,
                "note": null,
                "address": "موزع الحي الأول خلف نادي جرين هيلز وتخدم منقطة  هليوبليس",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "22476501",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/417.mp3"
                ]
            },
            {
                "id": 1243,
                "gov": "القاهرة",
                "branch": "الشروق",
                "description": null,
                "note": null,
                "address": "القاهرة مدينة الشروق بجوار مشاتل الجهاز وتخدم منقطة  الشروق",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "226870015",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/418.mp3"
                ]
            },
            {
                "id": 1244,
                "gov": "القاهرة",
                "branch": "الصالحية",
                "description": null,
                "note": null,
                "address": "الشرقية مدينة الصالحية الجديدة المنطقة الصناعية 2 منطقةة الملثين وتخدم منقطة  الصالحية",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "553200391",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/419.mp3"
                ]
            },
            {
                "id": 1245,
                "gov": "القاهرة",
                "branch": "الهايكستب",
                "description": null,
                "note": null,
                "address": "مدينة المستقبل أمام نادي الياسمين الاجتماعي خلف المطافي قطاع T وتخدم منقطة  الهايكستب",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "224774483",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/420.mp3"
                ]
            },
            {
                "id": 1246,
                "gov": "القاهرة",
                "branch": "بدر",
                "description": null,
                "note": null,
                "address": "ك32 طريق القاهرة السويس الصحراوي أمام مصنع نوفال وتخدم منقطة  بدر",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "228640100",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/421.mp3"
                ]
            },
            {
                "id": 1247,
                "gov": "القاهرة",
                "branch": "جنوب العاشر",
                "description": null,
                "note": null,
                "address": "المنطقة 3  ك62 طريق مصر الإسماعيلية الصحراويوتخدم منقطة  جنوب العاشر من رمضان",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "554412452",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/422.mp3"
                ]
            },
            {
                "id": 1248,
                "gov": "القاهرة",
                "branch": "شرق العاشر القديمة",
                "description": null,
                "note": null,
                "address": "المنطقة 2 الحي 3 أمام مجاورة 20 بجوار مصنع ارما وتخدم منقطة  شرق العاشر من رمضان القديمة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "554360307",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/423.mp3"
                ]
            },
            {
                "id": 1249,
                "gov": "القاهرة",
                "branch": "شمال العاشر",
                "description": null,
                "note": null,
                "address": "المنطقة 3 بجوار مصر للطيران ك 59 طريق القاهرة الإسماعيلية وتخدم منقطة  شمال العاشر من رمضان",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "554121770",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/424.mp3"
                ]
            },
            {
                "id": 1250,
                "gov": "القاهرة",
                "branch": "غرب العاشر",
                "description": null,
                "note": null,
                "address": "المجاورة 46 الحي 6 المنطقة الصناعية 1 بجوار مصنع ماك وتخدم منقطة  غرب العاشر من رمضان",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "554384468",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/425.mp3"
                ]
            },
            {
                "id": 1251,
                "gov": "القاهرة",
                "branch": "وسط العاشر",
                "description": null,
                "note": null,
                "address": "مركز الحي الأول مبنى مجمع المصالح فوق بنك التعمير وتخدم منقطة  وسط العاشر من رمضان",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "554361424",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/426.mp3"
                ]
            },
            {
                "id": 1252,
                "gov": "القاهرة",
                "branch": "دمياط الجديدة",
                "description": null,
                "note": null,
                "address": "دمياط الجديدة حي أول المجاورة السادسة وتخدم منقطة  مدينة دمياط الجديدة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "572420600",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/427.mp3"
                ]
            },
            {
                "id": 1253,
                "gov": "القاهرة",
                "branch": "أسيوط الجديدة",
                "description": null,
                "note": null,
                "address": "بجوار جهاز أسيوط الجديدة وتخدم منقطة  مدينة أسيوط الجديدة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "882210895",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/428.mp3"
                ]
            },
            {
                "id": 1254,
                "gov": "القاهرة",
                "branch": "المنيا الجديدة",
                "description": null,
                "note": null,
                "address": "أول الحي الخامس المنيا الجديدة وتخدم منقطة  قرى المنيا الجديدة",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "869204008",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/429.mp3"
                ]
            },
            {
                "id": 1255,
                "gov": "القاهرة",
                "branch": "مدينة الفيوم الجديدة",
                "description": null,
                "note": null,
                "address": "طريق أسيوط الغربي وتخدم منقطة  مدينة الفيوم الجديدة ",
                "map": null,
                "mobile": null,
                "phone2": null,
                "tel1": "842116000",
                "tel2": null,
                "disability": 1,
                "email": null,
                "imgs": [],
                "vids": [],
                "sound": [
                    "branches/sounds/430.mp3"
                ]
            }
        ]
    }
}